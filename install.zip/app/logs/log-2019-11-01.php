<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-11-01 14:58:18 --> Config Class Initialized
INFO - 2019-11-01 14:58:18 --> Hooks Class Initialized
DEBUG - 2019-11-01 14:58:18 --> UTF-8 Support Enabled
INFO - 2019-11-01 14:58:18 --> Utf8 Class Initialized
INFO - 2019-11-01 14:58:18 --> URI Class Initialized
DEBUG - 2019-11-01 14:58:18 --> No URI present. Default controller set.
INFO - 2019-11-01 14:58:18 --> Router Class Initialized
INFO - 2019-11-01 14:58:18 --> Output Class Initialized
INFO - 2019-11-01 14:58:18 --> Security Class Initialized
DEBUG - 2019-11-01 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-11-01 14:58:18 --> CSRF cookie sent
INFO - 2019-11-01 14:58:18 --> Input Class Initialized
INFO - 2019-11-01 14:58:18 --> Language Class Initialized
INFO - 2019-11-01 14:58:18 --> Language Class Initialized
INFO - 2019-11-01 14:58:18 --> Config Class Initialized
INFO - 2019-11-01 14:58:18 --> Loader Class Initialized
INFO - 2019-11-01 14:58:18 --> Helper loaded: url_helper
INFO - 2019-11-01 14:58:18 --> Helper loaded: common_helper
INFO - 2019-11-01 14:58:18 --> Helper loaded: language_helper
INFO - 2019-11-01 14:58:18 --> Helper loaded: cookie_helper
INFO - 2019-11-01 14:58:18 --> Helper loaded: email_helper
INFO - 2019-11-01 14:58:18 --> Helper loaded: file_manager_helper
INFO - 2019-11-01 14:58:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-11-01 14:58:18 --> Parser Class Initialized
INFO - 2019-11-01 14:58:18 --> User Agent Class Initialized
INFO - 2019-11-01 14:58:18 --> Model Class Initialized
INFO - 2019-11-01 14:58:19 --> Database Driver Class Initialized
INFO - 2019-11-01 14:58:19 --> Model Class Initialized
DEBUG - 2019-11-01 14:58:19 --> Template Class Initialized
INFO - 2019-11-01 14:58:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-11-01 14:58:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-11-01 14:58:19 --> Pagination Class Initialized
DEBUG - 2019-11-01 14:58:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-11-01 14:58:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-11-01 14:58:19 --> Encryption Class Initialized
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-11-01 14:58:19 --> Controller Class Initialized
DEBUG - 2019-11-01 14:58:19 --> regular MX_Controller Initialized
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-11-01 14:58:19 --> Model Class Initialized
INFO - 2019-11-01 14:58:19 --> Helper loaded: inflector_helper
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-11-01 14:58:19 --> Could not find the language line "FAQs"
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-11-01 14:58:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-11-01 14:58:19 --> Final output sent to browser
DEBUG - 2019-11-01 14:58:19 --> Total execution time: 1.7811
