<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-10-31 15:36:26 --> Config Class Initialized
INFO - 2019-10-31 15:36:26 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:36:26 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:36:26 --> Utf8 Class Initialized
INFO - 2019-10-31 15:36:26 --> URI Class Initialized
INFO - 2019-10-31 15:36:26 --> Router Class Initialized
INFO - 2019-10-31 15:36:26 --> Output Class Initialized
INFO - 2019-10-31 15:36:27 --> Security Class Initialized
DEBUG - 2019-10-31 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:36:27 --> CSRF cookie sent
INFO - 2019-10-31 15:36:27 --> Input Class Initialized
INFO - 2019-10-31 15:36:27 --> Language Class Initialized
INFO - 2019-10-31 15:36:27 --> Language Class Initialized
INFO - 2019-10-31 15:36:27 --> Config Class Initialized
INFO - 2019-10-31 15:36:27 --> Loader Class Initialized
INFO - 2019-10-31 15:36:27 --> Helper loaded: url_helper
INFO - 2019-10-31 15:36:27 --> Helper loaded: common_helper
INFO - 2019-10-31 15:36:27 --> Helper loaded: language_helper
INFO - 2019-10-31 15:36:27 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:36:27 --> Helper loaded: email_helper
INFO - 2019-10-31 15:36:27 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:36:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:36:27 --> Parser Class Initialized
INFO - 2019-10-31 15:36:27 --> User Agent Class Initialized
INFO - 2019-10-31 15:36:27 --> Model Class Initialized
INFO - 2019-10-31 15:36:27 --> Database Driver Class Initialized
INFO - 2019-10-31 15:36:27 --> Model Class Initialized
DEBUG - 2019-10-31 15:36:27 --> Template Class Initialized
INFO - 2019-10-31 15:36:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:36:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:36:27 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:36:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:36:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:36:27 --> Encryption Class Initialized
INFO - 2019-10-31 15:36:27 --> Controller Class Initialized
DEBUG - 2019-10-31 15:36:27 --> order MX_Controller Initialized
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 15:36:27 --> Model Class Initialized
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "order_id"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "order_id"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 15:36:27 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Pending"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Pending"
ERROR - 2019-10-31 15:36:27 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:36:27 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:36:27 --> Model Class Initialized
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:36:27 --> Model Class Initialized
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 15:36:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 15:36:27 --> Final output sent to browser
DEBUG - 2019-10-31 15:36:27 --> Total execution time: 0.7416
INFO - 2019-10-31 15:38:21 --> Config Class Initialized
INFO - 2019-10-31 15:38:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:38:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:38:21 --> Utf8 Class Initialized
INFO - 2019-10-31 15:38:21 --> URI Class Initialized
DEBUG - 2019-10-31 15:38:21 --> No URI present. Default controller set.
INFO - 2019-10-31 15:38:21 --> Router Class Initialized
INFO - 2019-10-31 15:38:21 --> Output Class Initialized
INFO - 2019-10-31 15:38:21 --> Security Class Initialized
DEBUG - 2019-10-31 15:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:38:21 --> CSRF cookie sent
INFO - 2019-10-31 15:38:21 --> Input Class Initialized
INFO - 2019-10-31 15:38:21 --> Language Class Initialized
INFO - 2019-10-31 15:38:21 --> Language Class Initialized
INFO - 2019-10-31 15:38:21 --> Config Class Initialized
INFO - 2019-10-31 15:38:21 --> Loader Class Initialized
INFO - 2019-10-31 15:38:21 --> Helper loaded: url_helper
INFO - 2019-10-31 15:38:21 --> Helper loaded: common_helper
INFO - 2019-10-31 15:38:21 --> Helper loaded: language_helper
INFO - 2019-10-31 15:38:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:38:21 --> Helper loaded: email_helper
INFO - 2019-10-31 15:38:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:38:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:38:21 --> Parser Class Initialized
INFO - 2019-10-31 15:38:21 --> User Agent Class Initialized
INFO - 2019-10-31 15:38:21 --> Model Class Initialized
INFO - 2019-10-31 15:38:21 --> Database Driver Class Initialized
INFO - 2019-10-31 15:38:21 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:21 --> Template Class Initialized
INFO - 2019-10-31 15:38:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:38:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:38:21 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:38:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:38:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:38:21 --> Encryption Class Initialized
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 15:38:21 --> Controller Class Initialized
DEBUG - 2019-10-31 15:38:21 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 15:38:21 --> Model Class Initialized
INFO - 2019-10-31 15:38:21 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 15:38:21 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 15:38:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 15:38:21 --> Final output sent to browser
DEBUG - 2019-10-31 15:38:21 --> Total execution time: 0.5790
INFO - 2019-10-31 15:38:24 --> Config Class Initialized
INFO - 2019-10-31 15:38:24 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:38:24 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:38:24 --> Utf8 Class Initialized
INFO - 2019-10-31 15:38:24 --> URI Class Initialized
INFO - 2019-10-31 15:38:24 --> Router Class Initialized
INFO - 2019-10-31 15:38:24 --> Output Class Initialized
INFO - 2019-10-31 15:38:24 --> Security Class Initialized
DEBUG - 2019-10-31 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:38:24 --> CSRF cookie sent
INFO - 2019-10-31 15:38:24 --> Input Class Initialized
INFO - 2019-10-31 15:38:24 --> Language Class Initialized
INFO - 2019-10-31 15:38:24 --> Language Class Initialized
INFO - 2019-10-31 15:38:24 --> Config Class Initialized
INFO - 2019-10-31 15:38:24 --> Loader Class Initialized
INFO - 2019-10-31 15:38:24 --> Helper loaded: url_helper
INFO - 2019-10-31 15:38:24 --> Helper loaded: common_helper
INFO - 2019-10-31 15:38:24 --> Helper loaded: language_helper
INFO - 2019-10-31 15:38:24 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:38:24 --> Helper loaded: email_helper
INFO - 2019-10-31 15:38:24 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:38:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:38:24 --> Parser Class Initialized
INFO - 2019-10-31 15:38:24 --> User Agent Class Initialized
INFO - 2019-10-31 15:38:24 --> Model Class Initialized
INFO - 2019-10-31 15:38:24 --> Database Driver Class Initialized
INFO - 2019-10-31 15:38:24 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:24 --> Template Class Initialized
INFO - 2019-10-31 15:38:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:38:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:38:24 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:38:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:38:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:38:24 --> Encryption Class Initialized
INFO - 2019-10-31 15:38:24 --> Controller Class Initialized
DEBUG - 2019-10-31 15:38:24 --> package MX_Controller Initialized
DEBUG - 2019-10-31 15:38:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-10-31 15:38:24 --> Model Class Initialized
INFO - 2019-10-31 15:38:24 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 15:38:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:38:24 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:38:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:38:24 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:38:25 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-10-31 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-10-31 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 15:38:25 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 15:38:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 15:38:25 --> Final output sent to browser
DEBUG - 2019-10-31 15:38:25 --> Total execution time: 0.8811
INFO - 2019-10-31 15:38:30 --> Config Class Initialized
INFO - 2019-10-31 15:38:30 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:38:30 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:38:30 --> Utf8 Class Initialized
INFO - 2019-10-31 15:38:30 --> URI Class Initialized
INFO - 2019-10-31 15:38:30 --> Router Class Initialized
INFO - 2019-10-31 15:38:30 --> Output Class Initialized
INFO - 2019-10-31 15:38:30 --> Security Class Initialized
DEBUG - 2019-10-31 15:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:38:30 --> CSRF cookie sent
INFO - 2019-10-31 15:38:30 --> CSRF token verified
INFO - 2019-10-31 15:38:30 --> Input Class Initialized
INFO - 2019-10-31 15:38:30 --> Language Class Initialized
INFO - 2019-10-31 15:38:30 --> Language Class Initialized
INFO - 2019-10-31 15:38:30 --> Config Class Initialized
INFO - 2019-10-31 15:38:30 --> Loader Class Initialized
INFO - 2019-10-31 15:38:30 --> Helper loaded: url_helper
INFO - 2019-10-31 15:38:30 --> Helper loaded: common_helper
INFO - 2019-10-31 15:38:30 --> Helper loaded: language_helper
INFO - 2019-10-31 15:38:30 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:38:30 --> Helper loaded: email_helper
INFO - 2019-10-31 15:38:30 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:38:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:38:30 --> Parser Class Initialized
INFO - 2019-10-31 15:38:30 --> User Agent Class Initialized
INFO - 2019-10-31 15:38:30 --> Model Class Initialized
INFO - 2019-10-31 15:38:30 --> Database Driver Class Initialized
INFO - 2019-10-31 15:38:30 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:30 --> Template Class Initialized
INFO - 2019-10-31 15:38:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:38:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:38:30 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:38:30 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:38:30 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:38:30 --> Encryption Class Initialized
INFO - 2019-10-31 15:38:30 --> Controller Class Initialized
DEBUG - 2019-10-31 15:38:30 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 15:38:30 --> Model Class Initialized
INFO - 2019-10-31 15:38:30 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:38:30 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:38:30 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:38:30 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 15:38:30 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 15:38:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 15:38:30 --> Final output sent to browser
DEBUG - 2019-10-31 15:38:30 --> Total execution time: 0.5519
INFO - 2019-10-31 15:38:39 --> Config Class Initialized
INFO - 2019-10-31 15:38:39 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:38:39 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:38:39 --> Utf8 Class Initialized
INFO - 2019-10-31 15:38:39 --> URI Class Initialized
INFO - 2019-10-31 15:38:39 --> Router Class Initialized
INFO - 2019-10-31 15:38:39 --> Output Class Initialized
INFO - 2019-10-31 15:38:39 --> Security Class Initialized
DEBUG - 2019-10-31 15:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:38:39 --> CSRF cookie sent
INFO - 2019-10-31 15:38:39 --> CSRF token verified
INFO - 2019-10-31 15:38:39 --> Input Class Initialized
INFO - 2019-10-31 15:38:39 --> Language Class Initialized
INFO - 2019-10-31 15:38:39 --> Language Class Initialized
INFO - 2019-10-31 15:38:39 --> Config Class Initialized
INFO - 2019-10-31 15:38:39 --> Loader Class Initialized
INFO - 2019-10-31 15:38:39 --> Helper loaded: url_helper
INFO - 2019-10-31 15:38:39 --> Helper loaded: common_helper
INFO - 2019-10-31 15:38:39 --> Helper loaded: language_helper
INFO - 2019-10-31 15:38:39 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:38:39 --> Helper loaded: email_helper
INFO - 2019-10-31 15:38:39 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:38:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:38:39 --> Parser Class Initialized
INFO - 2019-10-31 15:38:39 --> User Agent Class Initialized
INFO - 2019-10-31 15:38:39 --> Model Class Initialized
INFO - 2019-10-31 15:38:39 --> Database Driver Class Initialized
INFO - 2019-10-31 15:38:39 --> Model Class Initialized
DEBUG - 2019-10-31 15:38:39 --> Template Class Initialized
INFO - 2019-10-31 15:38:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:38:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:38:39 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:38:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:38:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:38:39 --> Encryption Class Initialized
INFO - 2019-10-31 15:38:39 --> Controller Class Initialized
DEBUG - 2019-10-31 15:38:39 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 15:38:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 15:38:39 --> Model Class Initialized
ERROR - 2019-10-31 15:38:39 --> Could not find the language line "Your_name"
DEBUG - 2019-10-31 15:38:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/stripe/index.php
INFO - 2019-10-31 15:38:40 --> Final output sent to browser
DEBUG - 2019-10-31 15:38:40 --> Total execution time: 0.4839
INFO - 2019-10-31 15:39:20 --> Config Class Initialized
INFO - 2019-10-31 15:39:20 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:39:20 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:39:20 --> Utf8 Class Initialized
INFO - 2019-10-31 15:39:20 --> URI Class Initialized
INFO - 2019-10-31 15:39:20 --> Router Class Initialized
INFO - 2019-10-31 15:39:20 --> Output Class Initialized
INFO - 2019-10-31 15:39:20 --> Security Class Initialized
DEBUG - 2019-10-31 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:39:20 --> Input Class Initialized
INFO - 2019-10-31 15:39:20 --> Language Class Initialized
INFO - 2019-10-31 15:39:20 --> Language Class Initialized
INFO - 2019-10-31 15:39:20 --> Config Class Initialized
INFO - 2019-10-31 15:39:20 --> Loader Class Initialized
INFO - 2019-10-31 15:39:20 --> Helper loaded: url_helper
INFO - 2019-10-31 15:39:20 --> Helper loaded: common_helper
INFO - 2019-10-31 15:39:20 --> Helper loaded: language_helper
INFO - 2019-10-31 15:39:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:39:20 --> Helper loaded: email_helper
INFO - 2019-10-31 15:39:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:39:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:39:20 --> Parser Class Initialized
INFO - 2019-10-31 15:39:20 --> User Agent Class Initialized
INFO - 2019-10-31 15:39:20 --> Model Class Initialized
INFO - 2019-10-31 15:39:20 --> Database Driver Class Initialized
INFO - 2019-10-31 15:39:20 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:20 --> Template Class Initialized
INFO - 2019-10-31 15:39:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:39:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:39:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:39:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:39:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:39:20 --> Encryption Class Initialized
INFO - 2019-10-31 15:39:20 --> Controller Class Initialized
DEBUG - 2019-10-31 15:39:20 --> stripe MX_Controller Initialized
DEBUG - 2019-10-31 15:39:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/stripeapi.php
INFO - 2019-10-31 15:39:22 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:23 --> orders MX_Controller Initialized
INFO - 2019-10-31 15:39:23 --> Config Class Initialized
INFO - 2019-10-31 15:39:23 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:39:23 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:39:23 --> Utf8 Class Initialized
INFO - 2019-10-31 15:39:23 --> URI Class Initialized
INFO - 2019-10-31 15:39:23 --> Router Class Initialized
INFO - 2019-10-31 15:39:23 --> Output Class Initialized
INFO - 2019-10-31 15:39:23 --> Security Class Initialized
DEBUG - 2019-10-31 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:39:23 --> CSRF cookie sent
INFO - 2019-10-31 15:39:23 --> Input Class Initialized
INFO - 2019-10-31 15:39:23 --> Language Class Initialized
INFO - 2019-10-31 15:39:23 --> Language Class Initialized
INFO - 2019-10-31 15:39:23 --> Config Class Initialized
INFO - 2019-10-31 15:39:23 --> Loader Class Initialized
INFO - 2019-10-31 15:39:23 --> Helper loaded: url_helper
INFO - 2019-10-31 15:39:23 --> Helper loaded: common_helper
INFO - 2019-10-31 15:39:23 --> Helper loaded: language_helper
INFO - 2019-10-31 15:39:23 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:39:23 --> Helper loaded: email_helper
INFO - 2019-10-31 15:39:23 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:39:23 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:39:23 --> Parser Class Initialized
INFO - 2019-10-31 15:39:23 --> User Agent Class Initialized
INFO - 2019-10-31 15:39:23 --> Model Class Initialized
INFO - 2019-10-31 15:39:23 --> Database Driver Class Initialized
INFO - 2019-10-31 15:39:23 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:23 --> Template Class Initialized
INFO - 2019-10-31 15:39:23 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:39:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:39:23 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:39:23 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:39:23 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:39:23 --> Encryption Class Initialized
INFO - 2019-10-31 15:39:23 --> Controller Class Initialized
DEBUG - 2019-10-31 15:39:23 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 15:39:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 15:39:24 --> Model Class Initialized
INFO - 2019-10-31 15:39:24 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/payment_successfully.php
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:39:24 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:39:24 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:39:24 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 15:39:24 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 15:39:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 15:39:24 --> Final output sent to browser
DEBUG - 2019-10-31 15:39:24 --> Total execution time: 0.5257
INFO - 2019-10-31 15:39:38 --> Config Class Initialized
INFO - 2019-10-31 15:39:38 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:39:38 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:39:38 --> Utf8 Class Initialized
INFO - 2019-10-31 15:39:38 --> URI Class Initialized
INFO - 2019-10-31 15:39:38 --> Router Class Initialized
INFO - 2019-10-31 15:39:38 --> Output Class Initialized
INFO - 2019-10-31 15:39:38 --> Security Class Initialized
DEBUG - 2019-10-31 15:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:39:38 --> CSRF cookie sent
INFO - 2019-10-31 15:39:38 --> Input Class Initialized
INFO - 2019-10-31 15:39:38 --> Language Class Initialized
INFO - 2019-10-31 15:39:38 --> Language Class Initialized
INFO - 2019-10-31 15:39:38 --> Config Class Initialized
INFO - 2019-10-31 15:39:38 --> Loader Class Initialized
INFO - 2019-10-31 15:39:38 --> Helper loaded: url_helper
INFO - 2019-10-31 15:39:38 --> Helper loaded: common_helper
INFO - 2019-10-31 15:39:38 --> Helper loaded: language_helper
INFO - 2019-10-31 15:39:38 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:39:38 --> Helper loaded: email_helper
INFO - 2019-10-31 15:39:38 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:39:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:39:38 --> Parser Class Initialized
INFO - 2019-10-31 15:39:38 --> User Agent Class Initialized
INFO - 2019-10-31 15:39:38 --> Model Class Initialized
INFO - 2019-10-31 15:39:38 --> Database Driver Class Initialized
INFO - 2019-10-31 15:39:38 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:38 --> Template Class Initialized
INFO - 2019-10-31 15:39:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:39:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:39:38 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:39:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:39:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:39:39 --> Encryption Class Initialized
INFO - 2019-10-31 15:39:39 --> Controller Class Initialized
DEBUG - 2019-10-31 15:39:39 --> order MX_Controller Initialized
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 15:39:39 --> Model Class Initialized
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "order_id"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "order_id"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 15:39:39 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Pending"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Pending"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 15:39:39 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:39:39 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:39:39 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:39:39 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 15:39:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 15:39:39 --> Final output sent to browser
DEBUG - 2019-10-31 15:39:39 --> Total execution time: 0.7620
INFO - 2019-10-31 15:39:41 --> Config Class Initialized
INFO - 2019-10-31 15:39:41 --> Hooks Class Initialized
DEBUG - 2019-10-31 15:39:41 --> UTF-8 Support Enabled
INFO - 2019-10-31 15:39:41 --> Utf8 Class Initialized
INFO - 2019-10-31 15:39:41 --> URI Class Initialized
INFO - 2019-10-31 15:39:41 --> Router Class Initialized
INFO - 2019-10-31 15:39:41 --> Output Class Initialized
INFO - 2019-10-31 15:39:41 --> Security Class Initialized
DEBUG - 2019-10-31 15:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 15:39:41 --> CSRF cookie sent
INFO - 2019-10-31 15:39:41 --> Input Class Initialized
INFO - 2019-10-31 15:39:41 --> Language Class Initialized
INFO - 2019-10-31 15:39:41 --> Language Class Initialized
INFO - 2019-10-31 15:39:41 --> Config Class Initialized
INFO - 2019-10-31 15:39:41 --> Loader Class Initialized
INFO - 2019-10-31 15:39:41 --> Helper loaded: url_helper
INFO - 2019-10-31 15:39:41 --> Helper loaded: common_helper
INFO - 2019-10-31 15:39:41 --> Helper loaded: language_helper
INFO - 2019-10-31 15:39:41 --> Helper loaded: cookie_helper
INFO - 2019-10-31 15:39:41 --> Helper loaded: email_helper
INFO - 2019-10-31 15:39:41 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 15:39:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 15:39:41 --> Parser Class Initialized
INFO - 2019-10-31 15:39:41 --> User Agent Class Initialized
INFO - 2019-10-31 15:39:41 --> Model Class Initialized
INFO - 2019-10-31 15:39:41 --> Database Driver Class Initialized
INFO - 2019-10-31 15:39:41 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:41 --> Template Class Initialized
INFO - 2019-10-31 15:39:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 15:39:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 15:39:41 --> Pagination Class Initialized
DEBUG - 2019-10-31 15:39:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 15:39:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 15:39:41 --> Encryption Class Initialized
INFO - 2019-10-31 15:39:41 --> Controller Class Initialized
DEBUG - 2019-10-31 15:39:41 --> transactions MX_Controller Initialized
DEBUG - 2019-10-31 15:39:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-10-31 15:39:41 --> Model Class Initialized
ERROR - 2019-10-31 15:39:41 --> Could not find the language line "order_id"
INFO - 2019-10-31 15:39:41 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 15:39:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-10-31 15:39:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 15:39:41 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 15:39:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 15:39:41 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 15:39:41 --> Model Class Initialized
DEBUG - 2019-10-31 15:39:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 15:39:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 15:39:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 15:39:42 --> Final output sent to browser
DEBUG - 2019-10-31 15:39:42 --> Total execution time: 0.6231
INFO - 2019-10-31 16:07:28 --> Config Class Initialized
INFO - 2019-10-31 16:07:28 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:07:28 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:07:28 --> Utf8 Class Initialized
INFO - 2019-10-31 16:07:28 --> URI Class Initialized
INFO - 2019-10-31 16:07:28 --> Router Class Initialized
INFO - 2019-10-31 16:07:28 --> Output Class Initialized
INFO - 2019-10-31 16:07:28 --> Security Class Initialized
DEBUG - 2019-10-31 16:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:07:28 --> CSRF cookie sent
INFO - 2019-10-31 16:07:28 --> Input Class Initialized
INFO - 2019-10-31 16:07:28 --> Language Class Initialized
INFO - 2019-10-31 16:07:28 --> Language Class Initialized
INFO - 2019-10-31 16:07:28 --> Config Class Initialized
INFO - 2019-10-31 16:07:28 --> Loader Class Initialized
INFO - 2019-10-31 16:07:28 --> Helper loaded: url_helper
INFO - 2019-10-31 16:07:28 --> Helper loaded: common_helper
INFO - 2019-10-31 16:07:28 --> Helper loaded: language_helper
INFO - 2019-10-31 16:07:28 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:07:28 --> Helper loaded: email_helper
INFO - 2019-10-31 16:07:28 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:07:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:07:28 --> Parser Class Initialized
INFO - 2019-10-31 16:07:28 --> User Agent Class Initialized
INFO - 2019-10-31 16:07:28 --> Model Class Initialized
INFO - 2019-10-31 16:07:28 --> Database Driver Class Initialized
INFO - 2019-10-31 16:07:28 --> Model Class Initialized
DEBUG - 2019-10-31 16:07:28 --> Template Class Initialized
INFO - 2019-10-31 16:07:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:07:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:07:28 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:07:28 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:07:28 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:07:28 --> Encryption Class Initialized
INFO - 2019-10-31 16:07:28 --> Controller Class Initialized
DEBUG - 2019-10-31 16:07:28 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:07:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:07:28 --> Model Class Initialized
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:07:28 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:07:28 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:07:29 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:07:29 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:07:29 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:07:29 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:07:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:07:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:07:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:07:29 --> Final output sent to browser
DEBUG - 2019-10-31 16:07:29 --> Total execution time: 0.7807
INFO - 2019-10-31 16:08:20 --> Config Class Initialized
INFO - 2019-10-31 16:08:20 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:08:20 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:08:20 --> Utf8 Class Initialized
INFO - 2019-10-31 16:08:20 --> URI Class Initialized
INFO - 2019-10-31 16:08:20 --> Router Class Initialized
INFO - 2019-10-31 16:08:20 --> Output Class Initialized
INFO - 2019-10-31 16:08:20 --> Security Class Initialized
DEBUG - 2019-10-31 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:08:20 --> CSRF cookie sent
INFO - 2019-10-31 16:08:20 --> Input Class Initialized
INFO - 2019-10-31 16:08:20 --> Language Class Initialized
INFO - 2019-10-31 16:08:20 --> Language Class Initialized
INFO - 2019-10-31 16:08:20 --> Config Class Initialized
INFO - 2019-10-31 16:08:20 --> Loader Class Initialized
INFO - 2019-10-31 16:08:20 --> Helper loaded: url_helper
INFO - 2019-10-31 16:08:20 --> Helper loaded: common_helper
INFO - 2019-10-31 16:08:20 --> Helper loaded: language_helper
INFO - 2019-10-31 16:08:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:08:20 --> Helper loaded: email_helper
INFO - 2019-10-31 16:08:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:08:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:08:20 --> Parser Class Initialized
INFO - 2019-10-31 16:08:20 --> User Agent Class Initialized
INFO - 2019-10-31 16:08:20 --> Model Class Initialized
INFO - 2019-10-31 16:08:20 --> Database Driver Class Initialized
INFO - 2019-10-31 16:08:20 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:20 --> Template Class Initialized
INFO - 2019-10-31 16:08:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:08:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:08:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:08:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:08:20 --> Encryption Class Initialized
INFO - 2019-10-31 16:08:20 --> Controller Class Initialized
DEBUG - 2019-10-31 16:08:20 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:08:20 --> Model Class Initialized
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:08:20 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:20 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:08:20 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:08:20 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:08:20 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:08:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:08:20 --> Final output sent to browser
DEBUG - 2019-10-31 16:08:20 --> Total execution time: 0.7731
INFO - 2019-10-31 16:08:36 --> Config Class Initialized
INFO - 2019-10-31 16:08:36 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:08:36 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:08:36 --> Utf8 Class Initialized
INFO - 2019-10-31 16:08:36 --> URI Class Initialized
INFO - 2019-10-31 16:08:36 --> Router Class Initialized
INFO - 2019-10-31 16:08:36 --> Output Class Initialized
INFO - 2019-10-31 16:08:36 --> Security Class Initialized
DEBUG - 2019-10-31 16:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:08:36 --> CSRF cookie sent
INFO - 2019-10-31 16:08:36 --> Input Class Initialized
INFO - 2019-10-31 16:08:36 --> Language Class Initialized
INFO - 2019-10-31 16:08:36 --> Language Class Initialized
INFO - 2019-10-31 16:08:36 --> Config Class Initialized
INFO - 2019-10-31 16:08:36 --> Loader Class Initialized
INFO - 2019-10-31 16:08:36 --> Helper loaded: url_helper
INFO - 2019-10-31 16:08:36 --> Helper loaded: common_helper
INFO - 2019-10-31 16:08:36 --> Helper loaded: language_helper
INFO - 2019-10-31 16:08:36 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:08:36 --> Helper loaded: email_helper
INFO - 2019-10-31 16:08:36 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:08:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:08:36 --> Parser Class Initialized
INFO - 2019-10-31 16:08:36 --> User Agent Class Initialized
INFO - 2019-10-31 16:08:36 --> Model Class Initialized
INFO - 2019-10-31 16:08:36 --> Database Driver Class Initialized
INFO - 2019-10-31 16:08:36 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:36 --> Template Class Initialized
INFO - 2019-10-31 16:08:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:08:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:08:36 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:08:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:08:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:08:36 --> Encryption Class Initialized
INFO - 2019-10-31 16:08:36 --> Controller Class Initialized
DEBUG - 2019-10-31 16:08:36 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:08:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:08:36 --> Model Class Initialized
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:08:37 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:37 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:08:37 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:08:37 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:08:37 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:08:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:08:37 --> Final output sent to browser
DEBUG - 2019-10-31 16:08:37 --> Total execution time: 0.7183
INFO - 2019-10-31 16:08:46 --> Config Class Initialized
INFO - 2019-10-31 16:08:46 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:08:46 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:08:46 --> Utf8 Class Initialized
INFO - 2019-10-31 16:08:46 --> URI Class Initialized
INFO - 2019-10-31 16:08:46 --> Router Class Initialized
INFO - 2019-10-31 16:08:46 --> Output Class Initialized
INFO - 2019-10-31 16:08:46 --> Security Class Initialized
DEBUG - 2019-10-31 16:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:08:46 --> CSRF cookie sent
INFO - 2019-10-31 16:08:46 --> Input Class Initialized
INFO - 2019-10-31 16:08:46 --> Language Class Initialized
INFO - 2019-10-31 16:08:46 --> Language Class Initialized
INFO - 2019-10-31 16:08:46 --> Config Class Initialized
INFO - 2019-10-31 16:08:46 --> Loader Class Initialized
INFO - 2019-10-31 16:08:46 --> Helper loaded: url_helper
INFO - 2019-10-31 16:08:46 --> Helper loaded: common_helper
INFO - 2019-10-31 16:08:46 --> Helper loaded: language_helper
INFO - 2019-10-31 16:08:46 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:08:46 --> Helper loaded: email_helper
INFO - 2019-10-31 16:08:46 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:08:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:08:46 --> Parser Class Initialized
INFO - 2019-10-31 16:08:46 --> User Agent Class Initialized
INFO - 2019-10-31 16:08:46 --> Model Class Initialized
INFO - 2019-10-31 16:08:46 --> Database Driver Class Initialized
INFO - 2019-10-31 16:08:46 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:46 --> Template Class Initialized
INFO - 2019-10-31 16:08:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:08:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:08:46 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:08:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:08:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:08:47 --> Encryption Class Initialized
INFO - 2019-10-31 16:08:47 --> Controller Class Initialized
DEBUG - 2019-10-31 16:08:47 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:08:47 --> Model Class Initialized
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:47 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 16:08:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/update.php
INFO - 2019-10-31 16:08:47 --> Final output sent to browser
DEBUG - 2019-10-31 16:08:47 --> Total execution time: 0.4697
INFO - 2019-10-31 16:08:52 --> Config Class Initialized
INFO - 2019-10-31 16:08:52 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:08:52 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:08:52 --> Utf8 Class Initialized
INFO - 2019-10-31 16:08:52 --> URI Class Initialized
INFO - 2019-10-31 16:08:52 --> Router Class Initialized
INFO - 2019-10-31 16:08:52 --> Output Class Initialized
INFO - 2019-10-31 16:08:52 --> Security Class Initialized
DEBUG - 2019-10-31 16:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:08:53 --> CSRF cookie sent
INFO - 2019-10-31 16:08:53 --> CSRF token verified
INFO - 2019-10-31 16:08:53 --> Input Class Initialized
INFO - 2019-10-31 16:08:53 --> Language Class Initialized
INFO - 2019-10-31 16:08:53 --> Language Class Initialized
INFO - 2019-10-31 16:08:53 --> Config Class Initialized
INFO - 2019-10-31 16:08:53 --> Loader Class Initialized
INFO - 2019-10-31 16:08:53 --> Helper loaded: url_helper
INFO - 2019-10-31 16:08:53 --> Helper loaded: common_helper
INFO - 2019-10-31 16:08:53 --> Helper loaded: language_helper
INFO - 2019-10-31 16:08:53 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:08:53 --> Helper loaded: email_helper
INFO - 2019-10-31 16:08:53 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:08:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:08:53 --> Parser Class Initialized
INFO - 2019-10-31 16:08:53 --> User Agent Class Initialized
INFO - 2019-10-31 16:08:53 --> Model Class Initialized
INFO - 2019-10-31 16:08:53 --> Database Driver Class Initialized
INFO - 2019-10-31 16:08:53 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:53 --> Template Class Initialized
INFO - 2019-10-31 16:08:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:08:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:08:53 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:08:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:08:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:08:53 --> Encryption Class Initialized
INFO - 2019-10-31 16:08:53 --> Controller Class Initialized
DEBUG - 2019-10-31 16:08:53 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:08:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:08:53 --> Model Class Initialized
ERROR - 2019-10-31 16:08:53 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:53 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:53 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:53 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:08:58 --> Config Class Initialized
INFO - 2019-10-31 16:08:58 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:08:58 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:08:58 --> Utf8 Class Initialized
INFO - 2019-10-31 16:08:58 --> URI Class Initialized
INFO - 2019-10-31 16:08:58 --> Router Class Initialized
INFO - 2019-10-31 16:08:58 --> Output Class Initialized
INFO - 2019-10-31 16:08:58 --> Security Class Initialized
DEBUG - 2019-10-31 16:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:08:58 --> CSRF cookie sent
INFO - 2019-10-31 16:08:58 --> Input Class Initialized
INFO - 2019-10-31 16:08:58 --> Language Class Initialized
INFO - 2019-10-31 16:08:58 --> Language Class Initialized
INFO - 2019-10-31 16:08:58 --> Config Class Initialized
INFO - 2019-10-31 16:08:58 --> Loader Class Initialized
INFO - 2019-10-31 16:08:58 --> Helper loaded: url_helper
INFO - 2019-10-31 16:08:58 --> Helper loaded: common_helper
INFO - 2019-10-31 16:08:58 --> Helper loaded: language_helper
INFO - 2019-10-31 16:08:58 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:08:58 --> Helper loaded: email_helper
INFO - 2019-10-31 16:08:58 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:08:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:08:58 --> Parser Class Initialized
INFO - 2019-10-31 16:08:58 --> User Agent Class Initialized
INFO - 2019-10-31 16:08:58 --> Model Class Initialized
INFO - 2019-10-31 16:08:58 --> Database Driver Class Initialized
INFO - 2019-10-31 16:08:58 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:58 --> Template Class Initialized
INFO - 2019-10-31 16:08:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:08:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:08:58 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:08:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:08:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:08:58 --> Encryption Class Initialized
INFO - 2019-10-31 16:08:58 --> Controller Class Initialized
DEBUG - 2019-10-31 16:08:58 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:08:58 --> Model Class Initialized
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:08:58 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:08:58 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:08:58 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:08:58 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:08:58 --> Model Class Initialized
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:08:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:08:58 --> Final output sent to browser
DEBUG - 2019-10-31 16:08:58 --> Total execution time: 0.8147
INFO - 2019-10-31 16:09:49 --> Config Class Initialized
INFO - 2019-10-31 16:09:49 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:09:49 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:09:49 --> Utf8 Class Initialized
INFO - 2019-10-31 16:09:49 --> URI Class Initialized
INFO - 2019-10-31 16:09:49 --> Router Class Initialized
INFO - 2019-10-31 16:09:49 --> Output Class Initialized
INFO - 2019-10-31 16:09:49 --> Security Class Initialized
DEBUG - 2019-10-31 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:09:49 --> CSRF cookie sent
INFO - 2019-10-31 16:09:49 --> Input Class Initialized
INFO - 2019-10-31 16:09:49 --> Language Class Initialized
INFO - 2019-10-31 16:09:49 --> Language Class Initialized
INFO - 2019-10-31 16:09:49 --> Config Class Initialized
INFO - 2019-10-31 16:09:49 --> Loader Class Initialized
INFO - 2019-10-31 16:09:49 --> Helper loaded: url_helper
INFO - 2019-10-31 16:09:49 --> Helper loaded: common_helper
INFO - 2019-10-31 16:09:49 --> Helper loaded: language_helper
INFO - 2019-10-31 16:09:49 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:09:49 --> Helper loaded: email_helper
INFO - 2019-10-31 16:09:49 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:09:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:09:49 --> Parser Class Initialized
INFO - 2019-10-31 16:09:49 --> User Agent Class Initialized
INFO - 2019-10-31 16:09:49 --> Model Class Initialized
INFO - 2019-10-31 16:09:49 --> Database Driver Class Initialized
INFO - 2019-10-31 16:09:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:09:49 --> Template Class Initialized
INFO - 2019-10-31 16:09:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:09:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:09:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:09:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:09:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:09:49 --> Encryption Class Initialized
INFO - 2019-10-31 16:09:49 --> Controller Class Initialized
DEBUG - 2019-10-31 16:09:49 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:09:49 --> Model Class Initialized
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:09:49 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:09:49 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:09:49 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:09:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:09:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:09:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:09:49 --> Final output sent to browser
DEBUG - 2019-10-31 16:09:49 --> Total execution time: 0.6999
INFO - 2019-10-31 16:13:28 --> Config Class Initialized
INFO - 2019-10-31 16:13:28 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:13:28 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:13:28 --> Utf8 Class Initialized
INFO - 2019-10-31 16:13:28 --> URI Class Initialized
INFO - 2019-10-31 16:13:28 --> Router Class Initialized
INFO - 2019-10-31 16:13:28 --> Output Class Initialized
INFO - 2019-10-31 16:13:28 --> Security Class Initialized
DEBUG - 2019-10-31 16:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:13:29 --> CSRF cookie sent
INFO - 2019-10-31 16:13:29 --> Input Class Initialized
INFO - 2019-10-31 16:13:29 --> Language Class Initialized
INFO - 2019-10-31 16:13:29 --> Language Class Initialized
INFO - 2019-10-31 16:13:29 --> Config Class Initialized
INFO - 2019-10-31 16:13:29 --> Loader Class Initialized
INFO - 2019-10-31 16:13:29 --> Helper loaded: url_helper
INFO - 2019-10-31 16:13:29 --> Helper loaded: common_helper
INFO - 2019-10-31 16:13:29 --> Helper loaded: language_helper
INFO - 2019-10-31 16:13:29 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:13:29 --> Helper loaded: email_helper
INFO - 2019-10-31 16:13:29 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:13:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:13:29 --> Parser Class Initialized
INFO - 2019-10-31 16:13:29 --> User Agent Class Initialized
INFO - 2019-10-31 16:13:29 --> Model Class Initialized
INFO - 2019-10-31 16:13:29 --> Database Driver Class Initialized
INFO - 2019-10-31 16:13:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:13:29 --> Template Class Initialized
INFO - 2019-10-31 16:13:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:13:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:13:29 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:13:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:13:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:13:29 --> Encryption Class Initialized
INFO - 2019-10-31 16:13:29 --> Controller Class Initialized
DEBUG - 2019-10-31 16:13:29 --> order MX_Controller Initialized
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 16:13:29 --> Model Class Initialized
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "order_id"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 16:13:29 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "Pending"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 16:13:29 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:13:29 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:13:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:13:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:13:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:13:29 --> Final output sent to browser
DEBUG - 2019-10-31 16:13:29 --> Total execution time: 0.6732
INFO - 2019-10-31 16:47:26 --> Config Class Initialized
INFO - 2019-10-31 16:47:26 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:47:26 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:47:26 --> Utf8 Class Initialized
INFO - 2019-10-31 16:47:26 --> URI Class Initialized
INFO - 2019-10-31 16:47:26 --> Router Class Initialized
INFO - 2019-10-31 16:47:26 --> Output Class Initialized
INFO - 2019-10-31 16:47:26 --> Security Class Initialized
DEBUG - 2019-10-31 16:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:47:26 --> CSRF cookie sent
INFO - 2019-10-31 16:47:26 --> Input Class Initialized
INFO - 2019-10-31 16:47:26 --> Language Class Initialized
INFO - 2019-10-31 16:47:26 --> Language Class Initialized
INFO - 2019-10-31 16:47:26 --> Config Class Initialized
INFO - 2019-10-31 16:47:26 --> Loader Class Initialized
INFO - 2019-10-31 16:47:26 --> Helper loaded: url_helper
INFO - 2019-10-31 16:47:26 --> Helper loaded: common_helper
INFO - 2019-10-31 16:47:26 --> Helper loaded: language_helper
INFO - 2019-10-31 16:47:26 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:47:26 --> Helper loaded: email_helper
INFO - 2019-10-31 16:47:26 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:47:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:47:26 --> Parser Class Initialized
INFO - 2019-10-31 16:47:26 --> User Agent Class Initialized
INFO - 2019-10-31 16:47:26 --> Model Class Initialized
INFO - 2019-10-31 16:47:26 --> Database Driver Class Initialized
INFO - 2019-10-31 16:47:26 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:26 --> Template Class Initialized
INFO - 2019-10-31 16:47:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:47:26 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:47:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:47:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:47:26 --> Encryption Class Initialized
INFO - 2019-10-31 16:47:26 --> Controller Class Initialized
DEBUG - 2019-10-31 16:47:26 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:47:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:47:26 --> Model Class Initialized
INFO - 2019-10-31 16:47:27 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:47:27 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:47:27 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:47:27 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:47:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:47:27 --> Final output sent to browser
DEBUG - 2019-10-31 16:47:27 --> Total execution time: 0.6609
INFO - 2019-10-31 16:47:28 --> Config Class Initialized
INFO - 2019-10-31 16:47:28 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:47:29 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:47:29 --> Utf8 Class Initialized
INFO - 2019-10-31 16:47:29 --> URI Class Initialized
INFO - 2019-10-31 16:47:29 --> Router Class Initialized
INFO - 2019-10-31 16:47:29 --> Output Class Initialized
INFO - 2019-10-31 16:47:29 --> Security Class Initialized
DEBUG - 2019-10-31 16:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:47:29 --> CSRF cookie sent
INFO - 2019-10-31 16:47:29 --> Input Class Initialized
INFO - 2019-10-31 16:47:29 --> Language Class Initialized
INFO - 2019-10-31 16:47:29 --> Language Class Initialized
INFO - 2019-10-31 16:47:29 --> Config Class Initialized
INFO - 2019-10-31 16:47:29 --> Loader Class Initialized
INFO - 2019-10-31 16:47:29 --> Helper loaded: url_helper
INFO - 2019-10-31 16:47:29 --> Helper loaded: common_helper
INFO - 2019-10-31 16:47:29 --> Helper loaded: language_helper
INFO - 2019-10-31 16:47:29 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:47:29 --> Helper loaded: email_helper
INFO - 2019-10-31 16:47:29 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:47:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:47:29 --> Parser Class Initialized
INFO - 2019-10-31 16:47:29 --> User Agent Class Initialized
INFO - 2019-10-31 16:47:29 --> Model Class Initialized
INFO - 2019-10-31 16:47:29 --> Database Driver Class Initialized
INFO - 2019-10-31 16:47:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:29 --> Template Class Initialized
INFO - 2019-10-31 16:47:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:47:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:47:29 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:47:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:47:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:47:29 --> Encryption Class Initialized
INFO - 2019-10-31 16:47:29 --> Controller Class Initialized
DEBUG - 2019-10-31 16:47:29 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:47:29 --> Model Class Initialized
INFO - 2019-10-31 16:47:29 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:47:29 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:47:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:47:29 --> Model Class Initialized
DEBUG - 2019-10-31 16:47:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:47:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:47:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:47:30 --> Final output sent to browser
DEBUG - 2019-10-31 16:47:30 --> Total execution time: 1.0656
INFO - 2019-10-31 16:56:37 --> Config Class Initialized
INFO - 2019-10-31 16:56:37 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:56:37 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:56:37 --> Utf8 Class Initialized
INFO - 2019-10-31 16:56:37 --> URI Class Initialized
INFO - 2019-10-31 16:56:37 --> Router Class Initialized
INFO - 2019-10-31 16:56:37 --> Output Class Initialized
INFO - 2019-10-31 16:56:37 --> Security Class Initialized
DEBUG - 2019-10-31 16:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:56:37 --> CSRF cookie sent
INFO - 2019-10-31 16:56:37 --> Input Class Initialized
INFO - 2019-10-31 16:56:37 --> Language Class Initialized
INFO - 2019-10-31 16:56:37 --> Language Class Initialized
INFO - 2019-10-31 16:56:37 --> Config Class Initialized
INFO - 2019-10-31 16:56:37 --> Loader Class Initialized
INFO - 2019-10-31 16:56:37 --> Helper loaded: url_helper
INFO - 2019-10-31 16:56:37 --> Helper loaded: common_helper
INFO - 2019-10-31 16:56:37 --> Helper loaded: language_helper
INFO - 2019-10-31 16:56:37 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:56:37 --> Helper loaded: email_helper
INFO - 2019-10-31 16:56:37 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:56:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:56:38 --> Parser Class Initialized
INFO - 2019-10-31 16:56:38 --> User Agent Class Initialized
INFO - 2019-10-31 16:56:38 --> Model Class Initialized
INFO - 2019-10-31 16:56:38 --> Database Driver Class Initialized
INFO - 2019-10-31 16:56:38 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:38 --> Template Class Initialized
INFO - 2019-10-31 16:56:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:56:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:56:38 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:56:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:56:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:56:38 --> Encryption Class Initialized
INFO - 2019-10-31 16:56:38 --> Controller Class Initialized
DEBUG - 2019-10-31 16:56:38 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 16:56:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 16:56:39 --> Model Class Initialized
INFO - 2019-10-31 16:56:39 --> Config Class Initialized
INFO - 2019-10-31 16:56:39 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:56:39 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:56:39 --> Utf8 Class Initialized
INFO - 2019-10-31 16:56:39 --> URI Class Initialized
DEBUG - 2019-10-31 16:56:39 --> No URI present. Default controller set.
INFO - 2019-10-31 16:56:39 --> Router Class Initialized
INFO - 2019-10-31 16:56:39 --> Output Class Initialized
INFO - 2019-10-31 16:56:39 --> Security Class Initialized
DEBUG - 2019-10-31 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:56:39 --> CSRF cookie sent
INFO - 2019-10-31 16:56:39 --> Input Class Initialized
INFO - 2019-10-31 16:56:39 --> Language Class Initialized
INFO - 2019-10-31 16:56:39 --> Language Class Initialized
INFO - 2019-10-31 16:56:39 --> Config Class Initialized
INFO - 2019-10-31 16:56:39 --> Loader Class Initialized
INFO - 2019-10-31 16:56:39 --> Helper loaded: url_helper
INFO - 2019-10-31 16:56:39 --> Helper loaded: common_helper
INFO - 2019-10-31 16:56:39 --> Helper loaded: language_helper
INFO - 2019-10-31 16:56:39 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:56:39 --> Helper loaded: email_helper
INFO - 2019-10-31 16:56:39 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:56:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:56:39 --> Parser Class Initialized
INFO - 2019-10-31 16:56:39 --> User Agent Class Initialized
INFO - 2019-10-31 16:56:39 --> Model Class Initialized
INFO - 2019-10-31 16:56:39 --> Database Driver Class Initialized
INFO - 2019-10-31 16:56:39 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:39 --> Template Class Initialized
INFO - 2019-10-31 16:56:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:56:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:56:39 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:56:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:56:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:56:40 --> Encryption Class Initialized
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 16:56:40 --> Controller Class Initialized
DEBUG - 2019-10-31 16:56:40 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 16:56:40 --> Model Class Initialized
INFO - 2019-10-31 16:56:40 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 16:56:40 --> Could not find the language line "Contact"
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 16:56:40 --> Could not find the language line "FAQs"
ERROR - 2019-10-31 16:56:40 --> Could not find the language line "Contact"
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 16:56:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 16:56:40 --> Final output sent to browser
DEBUG - 2019-10-31 16:56:40 --> Total execution time: 0.6583
INFO - 2019-10-31 16:56:48 --> Config Class Initialized
INFO - 2019-10-31 16:56:48 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:56:48 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:56:48 --> Utf8 Class Initialized
INFO - 2019-10-31 16:56:48 --> URI Class Initialized
INFO - 2019-10-31 16:56:48 --> Router Class Initialized
INFO - 2019-10-31 16:56:48 --> Output Class Initialized
INFO - 2019-10-31 16:56:48 --> Security Class Initialized
DEBUG - 2019-10-31 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:56:48 --> CSRF cookie sent
INFO - 2019-10-31 16:56:48 --> Input Class Initialized
INFO - 2019-10-31 16:56:48 --> Language Class Initialized
INFO - 2019-10-31 16:56:48 --> Language Class Initialized
INFO - 2019-10-31 16:56:48 --> Config Class Initialized
INFO - 2019-10-31 16:56:48 --> Loader Class Initialized
INFO - 2019-10-31 16:56:48 --> Helper loaded: url_helper
INFO - 2019-10-31 16:56:48 --> Helper loaded: common_helper
INFO - 2019-10-31 16:56:48 --> Helper loaded: language_helper
INFO - 2019-10-31 16:56:48 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:56:48 --> Helper loaded: email_helper
INFO - 2019-10-31 16:56:48 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:56:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:56:48 --> Parser Class Initialized
INFO - 2019-10-31 16:56:48 --> User Agent Class Initialized
INFO - 2019-10-31 16:56:49 --> Model Class Initialized
INFO - 2019-10-31 16:56:49 --> Database Driver Class Initialized
INFO - 2019-10-31 16:56:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:49 --> Template Class Initialized
INFO - 2019-10-31 16:56:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:56:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:56:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:56:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:56:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:56:49 --> Encryption Class Initialized
INFO - 2019-10-31 16:56:49 --> Controller Class Initialized
DEBUG - 2019-10-31 16:56:49 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:56:49 --> Model Class Initialized
INFO - 2019-10-31 16:56:49 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:56:49 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:56:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:56:49 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:56:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:56:49 --> Final output sent to browser
DEBUG - 2019-10-31 16:56:49 --> Total execution time: 0.6632
INFO - 2019-10-31 16:56:51 --> Config Class Initialized
INFO - 2019-10-31 16:56:51 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:56:51 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:56:51 --> Utf8 Class Initialized
INFO - 2019-10-31 16:56:51 --> URI Class Initialized
INFO - 2019-10-31 16:56:51 --> Router Class Initialized
INFO - 2019-10-31 16:56:51 --> Output Class Initialized
INFO - 2019-10-31 16:56:51 --> Security Class Initialized
DEBUG - 2019-10-31 16:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:56:51 --> CSRF cookie sent
INFO - 2019-10-31 16:56:51 --> Input Class Initialized
INFO - 2019-10-31 16:56:51 --> Language Class Initialized
INFO - 2019-10-31 16:56:51 --> Language Class Initialized
INFO - 2019-10-31 16:56:51 --> Config Class Initialized
INFO - 2019-10-31 16:56:51 --> Loader Class Initialized
INFO - 2019-10-31 16:56:51 --> Helper loaded: url_helper
INFO - 2019-10-31 16:56:51 --> Helper loaded: common_helper
INFO - 2019-10-31 16:56:51 --> Helper loaded: language_helper
INFO - 2019-10-31 16:56:51 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:56:51 --> Helper loaded: email_helper
INFO - 2019-10-31 16:56:51 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:56:51 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:56:51 --> Parser Class Initialized
INFO - 2019-10-31 16:56:51 --> User Agent Class Initialized
INFO - 2019-10-31 16:56:51 --> Model Class Initialized
INFO - 2019-10-31 16:56:51 --> Database Driver Class Initialized
INFO - 2019-10-31 16:56:51 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:51 --> Template Class Initialized
INFO - 2019-10-31 16:56:51 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:56:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:56:51 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:56:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:56:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:56:51 --> Encryption Class Initialized
INFO - 2019-10-31 16:56:51 --> Controller Class Initialized
DEBUG - 2019-10-31 16:56:51 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:56:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:56:51 --> Model Class Initialized
INFO - 2019-10-31 16:56:53 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:56:53 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:56:53 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:56:53 --> Model Class Initialized
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:56:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:56:53 --> Final output sent to browser
DEBUG - 2019-10-31 16:56:53 --> Total execution time: 1.8614
INFO - 2019-10-31 16:57:56 --> Config Class Initialized
INFO - 2019-10-31 16:57:56 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:57:56 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:57:56 --> Utf8 Class Initialized
INFO - 2019-10-31 16:57:56 --> URI Class Initialized
INFO - 2019-10-31 16:57:56 --> Router Class Initialized
INFO - 2019-10-31 16:57:56 --> Output Class Initialized
INFO - 2019-10-31 16:57:56 --> Security Class Initialized
DEBUG - 2019-10-31 16:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:57:56 --> CSRF cookie sent
INFO - 2019-10-31 16:57:56 --> CSRF token verified
INFO - 2019-10-31 16:57:56 --> Input Class Initialized
INFO - 2019-10-31 16:57:56 --> Language Class Initialized
INFO - 2019-10-31 16:57:56 --> Language Class Initialized
INFO - 2019-10-31 16:57:56 --> Config Class Initialized
INFO - 2019-10-31 16:57:56 --> Loader Class Initialized
INFO - 2019-10-31 16:57:56 --> Helper loaded: url_helper
INFO - 2019-10-31 16:57:56 --> Helper loaded: common_helper
INFO - 2019-10-31 16:57:56 --> Helper loaded: language_helper
INFO - 2019-10-31 16:57:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:57:56 --> Helper loaded: email_helper
INFO - 2019-10-31 16:57:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:57:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:57:56 --> Parser Class Initialized
INFO - 2019-10-31 16:57:56 --> User Agent Class Initialized
INFO - 2019-10-31 16:57:56 --> Model Class Initialized
INFO - 2019-10-31 16:57:56 --> Database Driver Class Initialized
INFO - 2019-10-31 16:57:56 --> Model Class Initialized
DEBUG - 2019-10-31 16:57:56 --> Template Class Initialized
INFO - 2019-10-31 16:57:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:57:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:57:56 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:57:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:57:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:57:56 --> Encryption Class Initialized
INFO - 2019-10-31 16:57:56 --> Controller Class Initialized
DEBUG - 2019-10-31 16:57:56 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:57:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:57:56 --> Model Class Initialized
INFO - 2019-10-31 16:58:02 --> Config Class Initialized
INFO - 2019-10-31 16:58:02 --> Hooks Class Initialized
DEBUG - 2019-10-31 16:58:02 --> UTF-8 Support Enabled
INFO - 2019-10-31 16:58:02 --> Utf8 Class Initialized
INFO - 2019-10-31 16:58:02 --> URI Class Initialized
INFO - 2019-10-31 16:58:02 --> Router Class Initialized
INFO - 2019-10-31 16:58:02 --> Output Class Initialized
INFO - 2019-10-31 16:58:02 --> Security Class Initialized
DEBUG - 2019-10-31 16:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 16:58:02 --> CSRF cookie sent
INFO - 2019-10-31 16:58:02 --> Input Class Initialized
INFO - 2019-10-31 16:58:02 --> Language Class Initialized
INFO - 2019-10-31 16:58:02 --> Language Class Initialized
INFO - 2019-10-31 16:58:02 --> Config Class Initialized
INFO - 2019-10-31 16:58:02 --> Loader Class Initialized
INFO - 2019-10-31 16:58:02 --> Helper loaded: url_helper
INFO - 2019-10-31 16:58:02 --> Helper loaded: common_helper
INFO - 2019-10-31 16:58:02 --> Helper loaded: language_helper
INFO - 2019-10-31 16:58:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 16:58:02 --> Helper loaded: email_helper
INFO - 2019-10-31 16:58:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 16:58:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 16:58:02 --> Parser Class Initialized
INFO - 2019-10-31 16:58:02 --> User Agent Class Initialized
INFO - 2019-10-31 16:58:02 --> Model Class Initialized
INFO - 2019-10-31 16:58:02 --> Database Driver Class Initialized
INFO - 2019-10-31 16:58:02 --> Model Class Initialized
DEBUG - 2019-10-31 16:58:02 --> Template Class Initialized
INFO - 2019-10-31 16:58:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 16:58:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 16:58:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 16:58:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 16:58:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 16:58:02 --> Encryption Class Initialized
INFO - 2019-10-31 16:58:02 --> Controller Class Initialized
DEBUG - 2019-10-31 16:58:02 --> language MX_Controller Initialized
DEBUG - 2019-10-31 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 16:58:02 --> Model Class Initialized
INFO - 2019-10-31 16:58:02 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-10-31 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 16:58:02 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 16:58:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 16:58:02 --> Model Class Initialized
DEBUG - 2019-10-31 16:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 16:58:03 --> Model Class Initialized
DEBUG - 2019-10-31 16:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 16:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 16:58:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 16:58:03 --> Final output sent to browser
DEBUG - 2019-10-31 16:58:03 --> Total execution time: 0.8385
INFO - 2019-10-31 21:19:11 --> Config Class Initialized
INFO - 2019-10-31 21:19:11 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:19:11 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:19:11 --> Utf8 Class Initialized
INFO - 2019-10-31 21:19:11 --> URI Class Initialized
INFO - 2019-10-31 21:19:11 --> Router Class Initialized
INFO - 2019-10-31 21:19:11 --> Output Class Initialized
INFO - 2019-10-31 21:19:11 --> Security Class Initialized
DEBUG - 2019-10-31 21:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:19:11 --> CSRF cookie sent
INFO - 2019-10-31 21:19:11 --> Input Class Initialized
INFO - 2019-10-31 21:19:11 --> Language Class Initialized
INFO - 2019-10-31 21:19:11 --> Language Class Initialized
INFO - 2019-10-31 21:19:11 --> Config Class Initialized
INFO - 2019-10-31 21:19:11 --> Loader Class Initialized
INFO - 2019-10-31 21:19:11 --> Helper loaded: url_helper
INFO - 2019-10-31 21:19:11 --> Helper loaded: common_helper
INFO - 2019-10-31 21:19:11 --> Helper loaded: language_helper
INFO - 2019-10-31 21:19:11 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:19:11 --> Helper loaded: email_helper
INFO - 2019-10-31 21:19:11 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:19:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:19:12 --> Parser Class Initialized
INFO - 2019-10-31 21:19:12 --> User Agent Class Initialized
INFO - 2019-10-31 21:19:12 --> Model Class Initialized
INFO - 2019-10-31 21:19:12 --> Database Driver Class Initialized
INFO - 2019-10-31 21:19:16 --> Model Class Initialized
DEBUG - 2019-10-31 21:19:16 --> Template Class Initialized
INFO - 2019-10-31 21:19:16 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:19:16 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:19:16 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:19:16 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:19:16 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:19:16 --> Encryption Class Initialized
INFO - 2019-10-31 21:19:16 --> Controller Class Initialized
DEBUG - 2019-10-31 21:19:16 --> language MX_Controller Initialized
DEBUG - 2019-10-31 21:19:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 21:19:16 --> Model Class Initialized
INFO - 2019-10-31 21:19:16 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:19:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-10-31 21:19:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:19:16 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:19:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:19:16 --> Model Class Initialized
DEBUG - 2019-10-31 21:19:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:19:17 --> Model Class Initialized
DEBUG - 2019-10-31 21:19:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:19:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:19:17 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:19:17 --> Final output sent to browser
DEBUG - 2019-10-31 21:19:17 --> Total execution time: 6.0877
INFO - 2019-10-31 21:25:02 --> Config Class Initialized
INFO - 2019-10-31 21:25:02 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:25:02 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:25:02 --> Utf8 Class Initialized
INFO - 2019-10-31 21:25:02 --> URI Class Initialized
INFO - 2019-10-31 21:25:02 --> Router Class Initialized
INFO - 2019-10-31 21:25:02 --> Output Class Initialized
INFO - 2019-10-31 21:25:02 --> Security Class Initialized
DEBUG - 2019-10-31 21:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:25:02 --> CSRF cookie sent
INFO - 2019-10-31 21:25:02 --> Input Class Initialized
INFO - 2019-10-31 21:25:02 --> Language Class Initialized
INFO - 2019-10-31 21:25:02 --> Language Class Initialized
INFO - 2019-10-31 21:25:02 --> Config Class Initialized
INFO - 2019-10-31 21:25:02 --> Loader Class Initialized
INFO - 2019-10-31 21:25:02 --> Helper loaded: url_helper
INFO - 2019-10-31 21:25:02 --> Helper loaded: common_helper
INFO - 2019-10-31 21:25:02 --> Helper loaded: language_helper
INFO - 2019-10-31 21:25:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:25:02 --> Helper loaded: email_helper
INFO - 2019-10-31 21:25:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:25:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:25:02 --> Parser Class Initialized
INFO - 2019-10-31 21:25:02 --> User Agent Class Initialized
INFO - 2019-10-31 21:25:02 --> Model Class Initialized
INFO - 2019-10-31 21:25:02 --> Database Driver Class Initialized
INFO - 2019-10-31 21:25:02 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:02 --> Template Class Initialized
INFO - 2019-10-31 21:25:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:25:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:25:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:25:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:25:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:25:02 --> Encryption Class Initialized
INFO - 2019-10-31 21:25:02 --> Controller Class Initialized
DEBUG - 2019-10-31 21:25:02 --> order MX_Controller Initialized
DEBUG - 2019-10-31 21:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 21:25:02 --> Model Class Initialized
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 21:25:02 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:02 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 21:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 21:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:25:02 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:25:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:25:03 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:25:03 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:25:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:25:03 --> Final output sent to browser
DEBUG - 2019-10-31 21:25:03 --> Total execution time: 0.9175
INFO - 2019-10-31 21:25:12 --> Config Class Initialized
INFO - 2019-10-31 21:25:12 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:25:12 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:25:12 --> Utf8 Class Initialized
INFO - 2019-10-31 21:25:12 --> URI Class Initialized
INFO - 2019-10-31 21:25:12 --> Router Class Initialized
INFO - 2019-10-31 21:25:12 --> Output Class Initialized
INFO - 2019-10-31 21:25:12 --> Security Class Initialized
DEBUG - 2019-10-31 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:25:12 --> CSRF cookie sent
INFO - 2019-10-31 21:25:12 --> Input Class Initialized
INFO - 2019-10-31 21:25:12 --> Language Class Initialized
INFO - 2019-10-31 21:25:12 --> Language Class Initialized
INFO - 2019-10-31 21:25:12 --> Config Class Initialized
INFO - 2019-10-31 21:25:12 --> Loader Class Initialized
INFO - 2019-10-31 21:25:12 --> Helper loaded: url_helper
INFO - 2019-10-31 21:25:12 --> Helper loaded: common_helper
INFO - 2019-10-31 21:25:12 --> Helper loaded: language_helper
INFO - 2019-10-31 21:25:12 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:25:12 --> Helper loaded: email_helper
INFO - 2019-10-31 21:25:12 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:25:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:25:12 --> Parser Class Initialized
INFO - 2019-10-31 21:25:12 --> User Agent Class Initialized
DEBUG - 2019-10-31 21:25:12 --> Template Class Initialized
INFO - 2019-10-31 21:25:12 --> Database Driver Class Initialized
INFO - 2019-10-31 21:25:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:25:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:25:12 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:25:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:25:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:25:12 --> Encryption Class Initialized
INFO - 2019-10-31 21:25:12 --> Controller Class Initialized
DEBUG - 2019-10-31 21:25:12 --> coinpayments MX_Controller Initialized
INFO - 2019-10-31 21:25:12 --> Model Class Initialized
INFO - 2019-10-31 21:25:12 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinpayments_api.php
INFO - 2019-10-31 21:25:12 --> Model Class Initialized
INFO - 2019-10-31 21:25:14 --> Final output sent to browser
DEBUG - 2019-10-31 21:25:14 --> Total execution time: 2.4864
ERROR - 2019-10-31 21:25:14 --> Severity: Warning --> session_write_close(): Session callback expects true/false return value Unknown 0
ERROR - 2019-10-31 21:25:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: D:\xampp\tmp) Unknown 0
INFO - 2019-10-31 21:25:18 --> Config Class Initialized
INFO - 2019-10-31 21:25:18 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:25:18 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:25:18 --> Utf8 Class Initialized
INFO - 2019-10-31 21:25:18 --> URI Class Initialized
INFO - 2019-10-31 21:25:18 --> Router Class Initialized
INFO - 2019-10-31 21:25:18 --> Output Class Initialized
INFO - 2019-10-31 21:25:18 --> Security Class Initialized
DEBUG - 2019-10-31 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:25:18 --> CSRF cookie sent
INFO - 2019-10-31 21:25:18 --> Input Class Initialized
INFO - 2019-10-31 21:25:18 --> Language Class Initialized
INFO - 2019-10-31 21:25:18 --> Language Class Initialized
INFO - 2019-10-31 21:25:18 --> Config Class Initialized
INFO - 2019-10-31 21:25:18 --> Loader Class Initialized
INFO - 2019-10-31 21:25:18 --> Helper loaded: url_helper
INFO - 2019-10-31 21:25:18 --> Helper loaded: common_helper
INFO - 2019-10-31 21:25:18 --> Helper loaded: language_helper
INFO - 2019-10-31 21:25:18 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:25:18 --> Helper loaded: email_helper
INFO - 2019-10-31 21:25:18 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:25:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:25:18 --> Parser Class Initialized
INFO - 2019-10-31 21:25:18 --> User Agent Class Initialized
INFO - 2019-10-31 21:25:19 --> Model Class Initialized
INFO - 2019-10-31 21:25:19 --> Database Driver Class Initialized
INFO - 2019-10-31 21:25:19 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:19 --> Template Class Initialized
INFO - 2019-10-31 21:25:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:25:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:25:19 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:25:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:25:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:25:19 --> Encryption Class Initialized
INFO - 2019-10-31 21:25:19 --> Controller Class Initialized
DEBUG - 2019-10-31 21:25:19 --> order MX_Controller Initialized
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 21:25:19 --> Model Class Initialized
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 21:25:19 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:19 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:25:19 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:25:19 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:25:19 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:25:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:25:19 --> Final output sent to browser
DEBUG - 2019-10-31 21:25:19 --> Total execution time: 0.8235
INFO - 2019-10-31 21:25:21 --> Config Class Initialized
INFO - 2019-10-31 21:25:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:25:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:25:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:25:21 --> URI Class Initialized
INFO - 2019-10-31 21:25:22 --> Router Class Initialized
INFO - 2019-10-31 21:25:22 --> Output Class Initialized
INFO - 2019-10-31 21:25:22 --> Security Class Initialized
DEBUG - 2019-10-31 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:25:22 --> CSRF cookie sent
INFO - 2019-10-31 21:25:22 --> Input Class Initialized
INFO - 2019-10-31 21:25:22 --> Language Class Initialized
INFO - 2019-10-31 21:25:22 --> Language Class Initialized
INFO - 2019-10-31 21:25:22 --> Config Class Initialized
INFO - 2019-10-31 21:25:22 --> Loader Class Initialized
INFO - 2019-10-31 21:25:22 --> Helper loaded: url_helper
INFO - 2019-10-31 21:25:22 --> Helper loaded: common_helper
INFO - 2019-10-31 21:25:22 --> Helper loaded: language_helper
INFO - 2019-10-31 21:25:22 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:25:22 --> Helper loaded: email_helper
INFO - 2019-10-31 21:25:22 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:25:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:25:22 --> Parser Class Initialized
INFO - 2019-10-31 21:25:22 --> User Agent Class Initialized
INFO - 2019-10-31 21:25:22 --> Model Class Initialized
INFO - 2019-10-31 21:25:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:25:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:22 --> Template Class Initialized
INFO - 2019-10-31 21:25:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:25:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:25:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:25:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:25:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:25:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:25:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:25:22 --> order MX_Controller Initialized
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 21:25:22 --> Model Class Initialized
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "order_id"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 21:25:22 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "Pending"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 21:25:22 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:25:22 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:25:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:25:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:25:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:25:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:25:22 --> Total execution time: 0.8148
INFO - 2019-10-31 21:26:08 --> Config Class Initialized
INFO - 2019-10-31 21:26:08 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:26:08 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:26:08 --> Utf8 Class Initialized
INFO - 2019-10-31 21:26:08 --> URI Class Initialized
INFO - 2019-10-31 21:26:08 --> Router Class Initialized
INFO - 2019-10-31 21:26:08 --> Output Class Initialized
INFO - 2019-10-31 21:26:08 --> Security Class Initialized
DEBUG - 2019-10-31 21:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:26:08 --> CSRF cookie sent
INFO - 2019-10-31 21:26:08 --> Input Class Initialized
INFO - 2019-10-31 21:26:08 --> Language Class Initialized
INFO - 2019-10-31 21:26:09 --> Language Class Initialized
INFO - 2019-10-31 21:26:09 --> Config Class Initialized
INFO - 2019-10-31 21:26:09 --> Loader Class Initialized
INFO - 2019-10-31 21:26:09 --> Helper loaded: url_helper
INFO - 2019-10-31 21:26:09 --> Helper loaded: common_helper
INFO - 2019-10-31 21:26:09 --> Helper loaded: language_helper
INFO - 2019-10-31 21:26:09 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:26:09 --> Helper loaded: email_helper
INFO - 2019-10-31 21:26:09 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:26:09 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:26:09 --> Parser Class Initialized
INFO - 2019-10-31 21:26:09 --> User Agent Class Initialized
INFO - 2019-10-31 21:26:09 --> Model Class Initialized
INFO - 2019-10-31 21:26:09 --> Database Driver Class Initialized
INFO - 2019-10-31 21:26:09 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:09 --> Template Class Initialized
INFO - 2019-10-31 21:26:09 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:26:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:26:09 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:26:09 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:26:09 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:26:09 --> Encryption Class Initialized
INFO - 2019-10-31 21:26:09 --> Controller Class Initialized
DEBUG - 2019-10-31 21:26:09 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:26:09 --> Model Class Initialized
INFO - 2019-10-31 21:26:09 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:26:09 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:26:09 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:26:09 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:26:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:26:09 --> Final output sent to browser
DEBUG - 2019-10-31 21:26:09 --> Total execution time: 0.8393
INFO - 2019-10-31 21:26:15 --> Config Class Initialized
INFO - 2019-10-31 21:26:15 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:26:15 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:26:15 --> Utf8 Class Initialized
INFO - 2019-10-31 21:26:15 --> URI Class Initialized
INFO - 2019-10-31 21:26:15 --> Router Class Initialized
INFO - 2019-10-31 21:26:15 --> Output Class Initialized
INFO - 2019-10-31 21:26:15 --> Security Class Initialized
DEBUG - 2019-10-31 21:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:26:15 --> CSRF cookie sent
INFO - 2019-10-31 21:26:15 --> Input Class Initialized
INFO - 2019-10-31 21:26:15 --> Language Class Initialized
INFO - 2019-10-31 21:26:15 --> Language Class Initialized
INFO - 2019-10-31 21:26:15 --> Config Class Initialized
INFO - 2019-10-31 21:26:15 --> Loader Class Initialized
INFO - 2019-10-31 21:26:15 --> Helper loaded: url_helper
INFO - 2019-10-31 21:26:15 --> Helper loaded: common_helper
INFO - 2019-10-31 21:26:15 --> Helper loaded: language_helper
INFO - 2019-10-31 21:26:15 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:26:15 --> Helper loaded: email_helper
INFO - 2019-10-31 21:26:15 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:26:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:26:15 --> Parser Class Initialized
INFO - 2019-10-31 21:26:15 --> User Agent Class Initialized
INFO - 2019-10-31 21:26:15 --> Model Class Initialized
INFO - 2019-10-31 21:26:15 --> Database Driver Class Initialized
INFO - 2019-10-31 21:26:15 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:15 --> Template Class Initialized
INFO - 2019-10-31 21:26:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:26:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:26:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:26:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:26:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:26:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:26:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:26:16 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:26:16 --> Model Class Initialized
INFO - 2019-10-31 21:26:16 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:26:16 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:26:16 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:26:16 --> Model Class Initialized
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:26:16 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:26:16 --> Final output sent to browser
DEBUG - 2019-10-31 21:26:16 --> Total execution time: 0.6836
INFO - 2019-10-31 21:36:49 --> Config Class Initialized
INFO - 2019-10-31 21:36:49 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:36:49 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:36:49 --> Utf8 Class Initialized
INFO - 2019-10-31 21:36:50 --> URI Class Initialized
INFO - 2019-10-31 21:36:50 --> Router Class Initialized
INFO - 2019-10-31 21:36:50 --> Output Class Initialized
INFO - 2019-10-31 21:36:50 --> Security Class Initialized
DEBUG - 2019-10-31 21:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:36:50 --> CSRF cookie sent
INFO - 2019-10-31 21:36:50 --> Input Class Initialized
INFO - 2019-10-31 21:36:50 --> Language Class Initialized
INFO - 2019-10-31 21:36:50 --> Language Class Initialized
INFO - 2019-10-31 21:36:50 --> Config Class Initialized
INFO - 2019-10-31 21:36:50 --> Loader Class Initialized
INFO - 2019-10-31 21:36:50 --> Helper loaded: url_helper
INFO - 2019-10-31 21:36:50 --> Helper loaded: common_helper
INFO - 2019-10-31 21:36:50 --> Helper loaded: language_helper
INFO - 2019-10-31 21:36:50 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:36:50 --> Helper loaded: email_helper
INFO - 2019-10-31 21:36:50 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:36:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:36:50 --> Parser Class Initialized
INFO - 2019-10-31 21:36:50 --> User Agent Class Initialized
INFO - 2019-10-31 21:36:50 --> Model Class Initialized
INFO - 2019-10-31 21:36:50 --> Database Driver Class Initialized
INFO - 2019-10-31 21:36:50 --> Model Class Initialized
DEBUG - 2019-10-31 21:36:50 --> Template Class Initialized
INFO - 2019-10-31 21:36:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:36:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:36:50 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:36:51 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:36:51 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:36:51 --> Encryption Class Initialized
INFO - 2019-10-31 21:36:51 --> Controller Class Initialized
DEBUG - 2019-10-31 21:36:51 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:36:51 --> Model Class Initialized
INFO - 2019-10-31 21:36:51 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:36:51 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:36:51 --> Model Class Initialized
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:36:51 --> Model Class Initialized
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:36:51 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:36:51 --> Final output sent to browser
DEBUG - 2019-10-31 21:36:51 --> Total execution time: 1.5373
INFO - 2019-10-31 21:37:49 --> Config Class Initialized
INFO - 2019-10-31 21:37:49 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:37:49 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:37:49 --> Utf8 Class Initialized
INFO - 2019-10-31 21:37:49 --> URI Class Initialized
INFO - 2019-10-31 21:37:49 --> Router Class Initialized
INFO - 2019-10-31 21:37:49 --> Output Class Initialized
INFO - 2019-10-31 21:37:49 --> Security Class Initialized
DEBUG - 2019-10-31 21:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:37:49 --> CSRF cookie sent
INFO - 2019-10-31 21:37:49 --> Input Class Initialized
INFO - 2019-10-31 21:37:49 --> Language Class Initialized
INFO - 2019-10-31 21:37:49 --> Language Class Initialized
INFO - 2019-10-31 21:37:49 --> Config Class Initialized
INFO - 2019-10-31 21:37:49 --> Loader Class Initialized
INFO - 2019-10-31 21:37:49 --> Helper loaded: url_helper
INFO - 2019-10-31 21:37:49 --> Helper loaded: common_helper
INFO - 2019-10-31 21:37:49 --> Helper loaded: language_helper
INFO - 2019-10-31 21:37:49 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:37:49 --> Helper loaded: email_helper
INFO - 2019-10-31 21:37:49 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:37:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:37:49 --> Parser Class Initialized
INFO - 2019-10-31 21:37:49 --> User Agent Class Initialized
INFO - 2019-10-31 21:37:49 --> Model Class Initialized
INFO - 2019-10-31 21:37:49 --> Database Driver Class Initialized
INFO - 2019-10-31 21:37:49 --> Model Class Initialized
DEBUG - 2019-10-31 21:37:49 --> Template Class Initialized
INFO - 2019-10-31 21:37:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:37:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:37:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:37:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:37:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:37:49 --> Encryption Class Initialized
INFO - 2019-10-31 21:37:49 --> Controller Class Initialized
DEBUG - 2019-10-31 21:37:49 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:37:49 --> Model Class Initialized
INFO - 2019-10-31 21:37:49 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:37:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:37:50 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:37:50 --> Model Class Initialized
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:37:50 --> Model Class Initialized
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:37:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:37:50 --> Final output sent to browser
DEBUG - 2019-10-31 21:37:50 --> Total execution time: 0.7004
INFO - 2019-10-31 21:38:21 --> Config Class Initialized
INFO - 2019-10-31 21:38:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:38:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:38:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:38:21 --> URI Class Initialized
INFO - 2019-10-31 21:38:21 --> Router Class Initialized
INFO - 2019-10-31 21:38:21 --> Output Class Initialized
INFO - 2019-10-31 21:38:21 --> Security Class Initialized
DEBUG - 2019-10-31 21:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:38:21 --> CSRF cookie sent
INFO - 2019-10-31 21:38:21 --> Input Class Initialized
INFO - 2019-10-31 21:38:21 --> Language Class Initialized
INFO - 2019-10-31 21:38:21 --> Language Class Initialized
INFO - 2019-10-31 21:38:21 --> Config Class Initialized
INFO - 2019-10-31 21:38:21 --> Loader Class Initialized
INFO - 2019-10-31 21:38:21 --> Helper loaded: url_helper
INFO - 2019-10-31 21:38:21 --> Helper loaded: common_helper
INFO - 2019-10-31 21:38:21 --> Helper loaded: language_helper
INFO - 2019-10-31 21:38:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:38:22 --> Helper loaded: email_helper
INFO - 2019-10-31 21:38:22 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:38:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:38:22 --> Parser Class Initialized
INFO - 2019-10-31 21:38:22 --> User Agent Class Initialized
INFO - 2019-10-31 21:38:22 --> Model Class Initialized
INFO - 2019-10-31 21:38:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:38:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:22 --> Template Class Initialized
INFO - 2019-10-31 21:38:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:38:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:38:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:38:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:38:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:38:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:38:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:38:22 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:38:22 --> Model Class Initialized
INFO - 2019-10-31 21:38:22 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:38:22 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:38:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:38:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:38:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:38:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:38:22 --> Total execution time: 0.6652
INFO - 2019-10-31 21:38:36 --> Config Class Initialized
INFO - 2019-10-31 21:38:36 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:38:36 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:38:36 --> Utf8 Class Initialized
INFO - 2019-10-31 21:38:36 --> URI Class Initialized
INFO - 2019-10-31 21:38:36 --> Router Class Initialized
INFO - 2019-10-31 21:38:36 --> Output Class Initialized
INFO - 2019-10-31 21:38:36 --> Security Class Initialized
DEBUG - 2019-10-31 21:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:38:36 --> CSRF cookie sent
INFO - 2019-10-31 21:38:36 --> Input Class Initialized
INFO - 2019-10-31 21:38:36 --> Language Class Initialized
INFO - 2019-10-31 21:38:36 --> Language Class Initialized
INFO - 2019-10-31 21:38:36 --> Config Class Initialized
INFO - 2019-10-31 21:38:36 --> Loader Class Initialized
INFO - 2019-10-31 21:38:36 --> Helper loaded: url_helper
INFO - 2019-10-31 21:38:36 --> Helper loaded: common_helper
INFO - 2019-10-31 21:38:36 --> Helper loaded: language_helper
INFO - 2019-10-31 21:38:36 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:38:36 --> Helper loaded: email_helper
INFO - 2019-10-31 21:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:38:36 --> Parser Class Initialized
INFO - 2019-10-31 21:38:36 --> User Agent Class Initialized
INFO - 2019-10-31 21:38:36 --> Model Class Initialized
INFO - 2019-10-31 21:38:36 --> Database Driver Class Initialized
INFO - 2019-10-31 21:38:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:36 --> Template Class Initialized
INFO - 2019-10-31 21:38:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:38:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:38:36 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:38:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:38:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:38:36 --> Encryption Class Initialized
INFO - 2019-10-31 21:38:36 --> Controller Class Initialized
DEBUG - 2019-10-31 21:38:36 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:38:36 --> Model Class Initialized
INFO - 2019-10-31 21:38:36 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:38:36 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:38:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:38:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:38:37 --> Final output sent to browser
DEBUG - 2019-10-31 21:38:37 --> Total execution time: 0.7181
INFO - 2019-10-31 21:38:43 --> Config Class Initialized
INFO - 2019-10-31 21:38:43 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:38:43 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:38:43 --> Utf8 Class Initialized
INFO - 2019-10-31 21:38:43 --> URI Class Initialized
INFO - 2019-10-31 21:38:43 --> Router Class Initialized
INFO - 2019-10-31 21:38:43 --> Output Class Initialized
INFO - 2019-10-31 21:38:43 --> Security Class Initialized
DEBUG - 2019-10-31 21:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:38:43 --> CSRF cookie sent
INFO - 2019-10-31 21:38:43 --> Input Class Initialized
INFO - 2019-10-31 21:38:43 --> Language Class Initialized
INFO - 2019-10-31 21:38:43 --> Language Class Initialized
INFO - 2019-10-31 21:38:43 --> Config Class Initialized
INFO - 2019-10-31 21:38:43 --> Loader Class Initialized
INFO - 2019-10-31 21:38:43 --> Helper loaded: url_helper
INFO - 2019-10-31 21:38:43 --> Helper loaded: common_helper
INFO - 2019-10-31 21:38:43 --> Helper loaded: language_helper
INFO - 2019-10-31 21:38:43 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:38:43 --> Helper loaded: email_helper
INFO - 2019-10-31 21:38:43 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:38:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:38:43 --> Parser Class Initialized
INFO - 2019-10-31 21:38:43 --> User Agent Class Initialized
INFO - 2019-10-31 21:38:43 --> Model Class Initialized
INFO - 2019-10-31 21:38:43 --> Database Driver Class Initialized
INFO - 2019-10-31 21:38:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:43 --> Template Class Initialized
INFO - 2019-10-31 21:38:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:38:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:38:43 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:38:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:38:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:38:43 --> Encryption Class Initialized
INFO - 2019-10-31 21:38:43 --> Controller Class Initialized
DEBUG - 2019-10-31 21:38:43 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:38:43 --> Model Class Initialized
INFO - 2019-10-31 21:38:43 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:38:43 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:38:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:38:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:38:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:38:43 --> Final output sent to browser
DEBUG - 2019-10-31 21:38:43 --> Total execution time: 0.7046
INFO - 2019-10-31 21:39:35 --> Config Class Initialized
INFO - 2019-10-31 21:39:35 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:39:36 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:39:36 --> Utf8 Class Initialized
INFO - 2019-10-31 21:39:36 --> URI Class Initialized
INFO - 2019-10-31 21:39:36 --> Router Class Initialized
INFO - 2019-10-31 21:39:36 --> Output Class Initialized
INFO - 2019-10-31 21:39:36 --> Security Class Initialized
DEBUG - 2019-10-31 21:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:39:36 --> CSRF cookie sent
INFO - 2019-10-31 21:39:36 --> Input Class Initialized
INFO - 2019-10-31 21:39:36 --> Language Class Initialized
INFO - 2019-10-31 21:39:36 --> Language Class Initialized
INFO - 2019-10-31 21:39:36 --> Config Class Initialized
INFO - 2019-10-31 21:39:36 --> Loader Class Initialized
INFO - 2019-10-31 21:39:36 --> Helper loaded: url_helper
INFO - 2019-10-31 21:39:36 --> Helper loaded: common_helper
INFO - 2019-10-31 21:39:36 --> Helper loaded: language_helper
INFO - 2019-10-31 21:39:36 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:39:36 --> Helper loaded: email_helper
INFO - 2019-10-31 21:39:36 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:39:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:39:36 --> Parser Class Initialized
INFO - 2019-10-31 21:39:36 --> User Agent Class Initialized
INFO - 2019-10-31 21:39:36 --> Model Class Initialized
INFO - 2019-10-31 21:39:36 --> Database Driver Class Initialized
INFO - 2019-10-31 21:39:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:39:36 --> Template Class Initialized
INFO - 2019-10-31 21:39:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:39:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:39:36 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:39:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:39:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:39:36 --> Encryption Class Initialized
INFO - 2019-10-31 21:39:36 --> Controller Class Initialized
DEBUG - 2019-10-31 21:39:36 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:39:36 --> Model Class Initialized
INFO - 2019-10-31 21:39:36 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:39:36 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:39:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:39:36 --> Model Class Initialized
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:39:36 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:39:36 --> Final output sent to browser
DEBUG - 2019-10-31 21:39:36 --> Total execution time: 0.6843
INFO - 2019-10-31 21:40:11 --> Config Class Initialized
INFO - 2019-10-31 21:40:11 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:40:11 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:40:11 --> Utf8 Class Initialized
INFO - 2019-10-31 21:40:11 --> URI Class Initialized
INFO - 2019-10-31 21:40:11 --> Router Class Initialized
INFO - 2019-10-31 21:40:11 --> Output Class Initialized
INFO - 2019-10-31 21:40:11 --> Security Class Initialized
DEBUG - 2019-10-31 21:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:40:11 --> CSRF cookie sent
INFO - 2019-10-31 21:40:11 --> Input Class Initialized
INFO - 2019-10-31 21:40:11 --> Language Class Initialized
INFO - 2019-10-31 21:40:11 --> Language Class Initialized
INFO - 2019-10-31 21:40:11 --> Config Class Initialized
INFO - 2019-10-31 21:40:11 --> Loader Class Initialized
INFO - 2019-10-31 21:40:11 --> Helper loaded: url_helper
INFO - 2019-10-31 21:40:11 --> Helper loaded: common_helper
INFO - 2019-10-31 21:40:11 --> Helper loaded: language_helper
INFO - 2019-10-31 21:40:11 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:40:11 --> Helper loaded: email_helper
INFO - 2019-10-31 21:40:11 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:40:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:40:11 --> Parser Class Initialized
INFO - 2019-10-31 21:40:11 --> User Agent Class Initialized
INFO - 2019-10-31 21:40:11 --> Model Class Initialized
INFO - 2019-10-31 21:40:11 --> Database Driver Class Initialized
INFO - 2019-10-31 21:40:11 --> Model Class Initialized
DEBUG - 2019-10-31 21:40:11 --> Template Class Initialized
INFO - 2019-10-31 21:40:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:40:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:40:11 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:40:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:40:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:40:11 --> Encryption Class Initialized
INFO - 2019-10-31 21:40:11 --> Controller Class Initialized
DEBUG - 2019-10-31 21:40:11 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:40:11 --> Model Class Initialized
INFO - 2019-10-31 21:40:11 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:40:11 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:40:11 --> Model Class Initialized
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:40:11 --> Model Class Initialized
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:40:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:40:11 --> Final output sent to browser
DEBUG - 2019-10-31 21:40:11 --> Total execution time: 0.6831
INFO - 2019-10-31 21:41:03 --> Config Class Initialized
INFO - 2019-10-31 21:41:03 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:41:03 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:41:03 --> Utf8 Class Initialized
INFO - 2019-10-31 21:41:03 --> URI Class Initialized
INFO - 2019-10-31 21:41:03 --> Router Class Initialized
INFO - 2019-10-31 21:41:03 --> Output Class Initialized
INFO - 2019-10-31 21:41:03 --> Security Class Initialized
DEBUG - 2019-10-31 21:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:41:03 --> CSRF cookie sent
INFO - 2019-10-31 21:41:03 --> Input Class Initialized
INFO - 2019-10-31 21:41:03 --> Language Class Initialized
INFO - 2019-10-31 21:41:03 --> Language Class Initialized
INFO - 2019-10-31 21:41:03 --> Config Class Initialized
INFO - 2019-10-31 21:41:03 --> Loader Class Initialized
INFO - 2019-10-31 21:41:03 --> Helper loaded: url_helper
INFO - 2019-10-31 21:41:03 --> Helper loaded: common_helper
INFO - 2019-10-31 21:41:03 --> Helper loaded: language_helper
INFO - 2019-10-31 21:41:03 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:41:03 --> Helper loaded: email_helper
INFO - 2019-10-31 21:41:03 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:41:03 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:41:03 --> Parser Class Initialized
INFO - 2019-10-31 21:41:03 --> User Agent Class Initialized
INFO - 2019-10-31 21:41:03 --> Model Class Initialized
INFO - 2019-10-31 21:41:03 --> Database Driver Class Initialized
INFO - 2019-10-31 21:41:03 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:03 --> Template Class Initialized
INFO - 2019-10-31 21:41:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:41:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:41:03 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:41:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:41:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:41:03 --> Encryption Class Initialized
INFO - 2019-10-31 21:41:03 --> Controller Class Initialized
DEBUG - 2019-10-31 21:41:03 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:41:03 --> Model Class Initialized
INFO - 2019-10-31 21:41:03 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:41:03 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:41:03 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:41:03 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:41:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:41:03 --> Final output sent to browser
DEBUG - 2019-10-31 21:41:03 --> Total execution time: 0.7041
INFO - 2019-10-31 21:41:20 --> Config Class Initialized
INFO - 2019-10-31 21:41:20 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:41:20 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:41:20 --> Utf8 Class Initialized
INFO - 2019-10-31 21:41:20 --> URI Class Initialized
INFO - 2019-10-31 21:41:20 --> Router Class Initialized
INFO - 2019-10-31 21:41:20 --> Output Class Initialized
INFO - 2019-10-31 21:41:20 --> Security Class Initialized
DEBUG - 2019-10-31 21:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:41:20 --> CSRF cookie sent
INFO - 2019-10-31 21:41:20 --> Input Class Initialized
INFO - 2019-10-31 21:41:20 --> Language Class Initialized
INFO - 2019-10-31 21:41:20 --> Language Class Initialized
INFO - 2019-10-31 21:41:20 --> Config Class Initialized
INFO - 2019-10-31 21:41:20 --> Loader Class Initialized
INFO - 2019-10-31 21:41:20 --> Helper loaded: url_helper
INFO - 2019-10-31 21:41:20 --> Helper loaded: common_helper
INFO - 2019-10-31 21:41:20 --> Helper loaded: language_helper
INFO - 2019-10-31 21:41:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:41:20 --> Helper loaded: email_helper
INFO - 2019-10-31 21:41:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:41:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:41:20 --> Parser Class Initialized
INFO - 2019-10-31 21:41:20 --> User Agent Class Initialized
INFO - 2019-10-31 21:41:20 --> Model Class Initialized
INFO - 2019-10-31 21:41:20 --> Database Driver Class Initialized
INFO - 2019-10-31 21:41:20 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:20 --> Template Class Initialized
INFO - 2019-10-31 21:41:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:41:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:41:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:41:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:41:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:41:20 --> Encryption Class Initialized
INFO - 2019-10-31 21:41:20 --> Controller Class Initialized
DEBUG - 2019-10-31 21:41:20 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:41:20 --> Model Class Initialized
INFO - 2019-10-31 21:41:20 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:41:20 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:41:20 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:41:20 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:41:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:41:20 --> Final output sent to browser
DEBUG - 2019-10-31 21:41:20 --> Total execution time: 0.6803
INFO - 2019-10-31 21:41:27 --> Config Class Initialized
INFO - 2019-10-31 21:41:27 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:41:27 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:41:27 --> Utf8 Class Initialized
INFO - 2019-10-31 21:41:27 --> URI Class Initialized
INFO - 2019-10-31 21:41:27 --> Router Class Initialized
INFO - 2019-10-31 21:41:27 --> Output Class Initialized
INFO - 2019-10-31 21:41:27 --> Security Class Initialized
DEBUG - 2019-10-31 21:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:41:27 --> CSRF cookie sent
INFO - 2019-10-31 21:41:27 --> Input Class Initialized
INFO - 2019-10-31 21:41:27 --> Language Class Initialized
INFO - 2019-10-31 21:41:27 --> Language Class Initialized
INFO - 2019-10-31 21:41:27 --> Config Class Initialized
INFO - 2019-10-31 21:41:27 --> Loader Class Initialized
INFO - 2019-10-31 21:41:27 --> Helper loaded: url_helper
INFO - 2019-10-31 21:41:27 --> Helper loaded: common_helper
INFO - 2019-10-31 21:41:27 --> Helper loaded: language_helper
INFO - 2019-10-31 21:41:27 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:41:27 --> Helper loaded: email_helper
INFO - 2019-10-31 21:41:27 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:41:27 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:41:27 --> Parser Class Initialized
INFO - 2019-10-31 21:41:27 --> User Agent Class Initialized
INFO - 2019-10-31 21:41:27 --> Model Class Initialized
INFO - 2019-10-31 21:41:27 --> Database Driver Class Initialized
INFO - 2019-10-31 21:41:27 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:27 --> Template Class Initialized
INFO - 2019-10-31 21:41:27 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:41:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:41:27 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:41:27 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:41:27 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:41:27 --> Encryption Class Initialized
INFO - 2019-10-31 21:41:27 --> Controller Class Initialized
DEBUG - 2019-10-31 21:41:27 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:41:27 --> Model Class Initialized
INFO - 2019-10-31 21:41:27 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:41:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:41:28 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:41:28 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:41:28 --> Model Class Initialized
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:41:28 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:41:28 --> Final output sent to browser
DEBUG - 2019-10-31 21:41:28 --> Total execution time: 0.7138
INFO - 2019-10-31 21:42:31 --> Config Class Initialized
INFO - 2019-10-31 21:42:31 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:42:31 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:42:31 --> Utf8 Class Initialized
INFO - 2019-10-31 21:42:31 --> URI Class Initialized
INFO - 2019-10-31 21:42:31 --> Router Class Initialized
INFO - 2019-10-31 21:42:31 --> Output Class Initialized
INFO - 2019-10-31 21:42:31 --> Security Class Initialized
DEBUG - 2019-10-31 21:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:42:31 --> CSRF cookie sent
INFO - 2019-10-31 21:42:31 --> Input Class Initialized
INFO - 2019-10-31 21:42:31 --> Language Class Initialized
INFO - 2019-10-31 21:42:31 --> Language Class Initialized
INFO - 2019-10-31 21:42:31 --> Config Class Initialized
INFO - 2019-10-31 21:42:31 --> Loader Class Initialized
INFO - 2019-10-31 21:42:31 --> Helper loaded: url_helper
INFO - 2019-10-31 21:42:31 --> Helper loaded: common_helper
INFO - 2019-10-31 21:42:31 --> Helper loaded: language_helper
INFO - 2019-10-31 21:42:31 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:42:31 --> Helper loaded: email_helper
INFO - 2019-10-31 21:42:31 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:42:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:42:31 --> Parser Class Initialized
INFO - 2019-10-31 21:42:31 --> User Agent Class Initialized
INFO - 2019-10-31 21:42:31 --> Model Class Initialized
INFO - 2019-10-31 21:42:31 --> Database Driver Class Initialized
INFO - 2019-10-31 21:42:31 --> Model Class Initialized
DEBUG - 2019-10-31 21:42:31 --> Template Class Initialized
INFO - 2019-10-31 21:42:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:42:31 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:42:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:42:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:42:31 --> Encryption Class Initialized
INFO - 2019-10-31 21:42:31 --> Controller Class Initialized
DEBUG - 2019-10-31 21:42:31 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:42:31 --> Model Class Initialized
INFO - 2019-10-31 21:42:31 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:42:31 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:42:31 --> Model Class Initialized
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:42:31 --> Model Class Initialized
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:42:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:42:31 --> Final output sent to browser
DEBUG - 2019-10-31 21:42:31 --> Total execution time: 0.7166
INFO - 2019-10-31 21:50:35 --> Config Class Initialized
INFO - 2019-10-31 21:50:35 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:50:35 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:50:35 --> Utf8 Class Initialized
INFO - 2019-10-31 21:50:35 --> URI Class Initialized
INFO - 2019-10-31 21:50:35 --> Router Class Initialized
INFO - 2019-10-31 21:50:35 --> Output Class Initialized
INFO - 2019-10-31 21:50:35 --> Security Class Initialized
DEBUG - 2019-10-31 21:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:50:35 --> CSRF cookie sent
INFO - 2019-10-31 21:50:35 --> CSRF token verified
INFO - 2019-10-31 21:50:35 --> Input Class Initialized
INFO - 2019-10-31 21:50:35 --> Language Class Initialized
INFO - 2019-10-31 21:50:35 --> Language Class Initialized
INFO - 2019-10-31 21:50:35 --> Config Class Initialized
INFO - 2019-10-31 21:50:35 --> Loader Class Initialized
INFO - 2019-10-31 21:50:35 --> Helper loaded: url_helper
INFO - 2019-10-31 21:50:35 --> Helper loaded: common_helper
INFO - 2019-10-31 21:50:35 --> Helper loaded: language_helper
INFO - 2019-10-31 21:50:35 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:50:35 --> Helper loaded: email_helper
INFO - 2019-10-31 21:50:35 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:50:35 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:50:35 --> Parser Class Initialized
INFO - 2019-10-31 21:50:35 --> User Agent Class Initialized
INFO - 2019-10-31 21:50:35 --> Model Class Initialized
INFO - 2019-10-31 21:50:35 --> Database Driver Class Initialized
INFO - 2019-10-31 21:50:35 --> Model Class Initialized
DEBUG - 2019-10-31 21:50:35 --> Template Class Initialized
INFO - 2019-10-31 21:50:35 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:50:35 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:50:35 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:50:35 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:50:35 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:50:35 --> Encryption Class Initialized
INFO - 2019-10-31 21:50:35 --> Controller Class Initialized
DEBUG - 2019-10-31 21:50:35 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:50:35 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:50:35 --> Model Class Initialized
INFO - 2019-10-31 21:50:40 --> Config Class Initialized
INFO - 2019-10-31 21:50:40 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:50:40 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:50:40 --> Utf8 Class Initialized
INFO - 2019-10-31 21:50:40 --> URI Class Initialized
INFO - 2019-10-31 21:50:40 --> Router Class Initialized
INFO - 2019-10-31 21:50:40 --> Output Class Initialized
INFO - 2019-10-31 21:50:40 --> Security Class Initialized
DEBUG - 2019-10-31 21:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:50:40 --> CSRF cookie sent
INFO - 2019-10-31 21:50:40 --> Input Class Initialized
INFO - 2019-10-31 21:50:40 --> Language Class Initialized
INFO - 2019-10-31 21:50:40 --> Language Class Initialized
INFO - 2019-10-31 21:50:40 --> Config Class Initialized
INFO - 2019-10-31 21:50:40 --> Loader Class Initialized
INFO - 2019-10-31 21:50:40 --> Helper loaded: url_helper
INFO - 2019-10-31 21:50:40 --> Helper loaded: common_helper
INFO - 2019-10-31 21:50:40 --> Helper loaded: language_helper
INFO - 2019-10-31 21:50:40 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:50:40 --> Helper loaded: email_helper
INFO - 2019-10-31 21:50:40 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:50:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:50:40 --> Parser Class Initialized
INFO - 2019-10-31 21:50:40 --> User Agent Class Initialized
INFO - 2019-10-31 21:50:40 --> Model Class Initialized
INFO - 2019-10-31 21:50:40 --> Database Driver Class Initialized
INFO - 2019-10-31 21:50:40 --> Model Class Initialized
DEBUG - 2019-10-31 21:50:40 --> Template Class Initialized
INFO - 2019-10-31 21:50:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:50:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:50:40 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:50:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:50:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:50:40 --> Encryption Class Initialized
INFO - 2019-10-31 21:50:40 --> Controller Class Initialized
DEBUG - 2019-10-31 21:50:40 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:50:40 --> Model Class Initialized
INFO - 2019-10-31 21:50:40 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:50:40 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:50:40 --> Model Class Initialized
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:50:40 --> Model Class Initialized
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:50:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:50:40 --> Final output sent to browser
DEBUG - 2019-10-31 21:50:40 --> Total execution time: 0.7601
INFO - 2019-10-31 21:51:10 --> Config Class Initialized
INFO - 2019-10-31 21:51:10 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:51:10 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:51:10 --> Utf8 Class Initialized
INFO - 2019-10-31 21:51:10 --> URI Class Initialized
INFO - 2019-10-31 21:51:10 --> Router Class Initialized
INFO - 2019-10-31 21:51:10 --> Output Class Initialized
INFO - 2019-10-31 21:51:10 --> Security Class Initialized
DEBUG - 2019-10-31 21:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:51:10 --> CSRF cookie sent
INFO - 2019-10-31 21:51:10 --> Input Class Initialized
INFO - 2019-10-31 21:51:10 --> Language Class Initialized
INFO - 2019-10-31 21:51:10 --> Language Class Initialized
INFO - 2019-10-31 21:51:10 --> Config Class Initialized
INFO - 2019-10-31 21:51:10 --> Loader Class Initialized
INFO - 2019-10-31 21:51:10 --> Helper loaded: url_helper
INFO - 2019-10-31 21:51:10 --> Helper loaded: common_helper
INFO - 2019-10-31 21:51:10 --> Helper loaded: language_helper
INFO - 2019-10-31 21:51:10 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:51:10 --> Helper loaded: email_helper
INFO - 2019-10-31 21:51:10 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:51:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:51:10 --> Parser Class Initialized
INFO - 2019-10-31 21:51:10 --> User Agent Class Initialized
INFO - 2019-10-31 21:51:10 --> Model Class Initialized
INFO - 2019-10-31 21:51:10 --> Database Driver Class Initialized
INFO - 2019-10-31 21:51:10 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:10 --> Template Class Initialized
INFO - 2019-10-31 21:51:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:51:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:51:10 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:51:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:51:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:51:10 --> Encryption Class Initialized
INFO - 2019-10-31 21:51:10 --> Controller Class Initialized
DEBUG - 2019-10-31 21:51:10 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:51:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:51:11 --> Model Class Initialized
INFO - 2019-10-31 21:51:11 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:51:11 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:51:11 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:51:11 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:51:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:51:11 --> Final output sent to browser
DEBUG - 2019-10-31 21:51:11 --> Total execution time: 0.7240
INFO - 2019-10-31 21:51:26 --> Config Class Initialized
INFO - 2019-10-31 21:51:26 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:51:26 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:51:26 --> Utf8 Class Initialized
INFO - 2019-10-31 21:51:26 --> URI Class Initialized
INFO - 2019-10-31 21:51:26 --> Router Class Initialized
INFO - 2019-10-31 21:51:26 --> Output Class Initialized
INFO - 2019-10-31 21:51:26 --> Security Class Initialized
DEBUG - 2019-10-31 21:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:51:26 --> CSRF cookie sent
INFO - 2019-10-31 21:51:26 --> Input Class Initialized
INFO - 2019-10-31 21:51:26 --> Language Class Initialized
INFO - 2019-10-31 21:51:26 --> Language Class Initialized
INFO - 2019-10-31 21:51:26 --> Config Class Initialized
INFO - 2019-10-31 21:51:26 --> Loader Class Initialized
INFO - 2019-10-31 21:51:26 --> Helper loaded: url_helper
INFO - 2019-10-31 21:51:26 --> Helper loaded: common_helper
INFO - 2019-10-31 21:51:26 --> Helper loaded: language_helper
INFO - 2019-10-31 21:51:26 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:51:26 --> Helper loaded: email_helper
INFO - 2019-10-31 21:51:26 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:51:26 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:51:26 --> Parser Class Initialized
INFO - 2019-10-31 21:51:26 --> User Agent Class Initialized
INFO - 2019-10-31 21:51:26 --> Model Class Initialized
INFO - 2019-10-31 21:51:26 --> Database Driver Class Initialized
INFO - 2019-10-31 21:51:26 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:26 --> Template Class Initialized
INFO - 2019-10-31 21:51:26 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:51:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:51:26 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:51:26 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:51:26 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:51:26 --> Encryption Class Initialized
INFO - 2019-10-31 21:51:26 --> Controller Class Initialized
DEBUG - 2019-10-31 21:51:26 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:51:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:51:26 --> Model Class Initialized
INFO - 2019-10-31 21:51:26 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:51:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:51:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:51:26 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:51:27 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:51:27 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:51:27 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:51:27 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:51:27 --> Final output sent to browser
DEBUG - 2019-10-31 21:51:27 --> Total execution time: 0.6877
INFO - 2019-10-31 21:51:47 --> Config Class Initialized
INFO - 2019-10-31 21:51:47 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:51:47 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:51:47 --> Utf8 Class Initialized
INFO - 2019-10-31 21:51:47 --> URI Class Initialized
DEBUG - 2019-10-31 21:51:47 --> No URI present. Default controller set.
INFO - 2019-10-31 21:51:47 --> Router Class Initialized
INFO - 2019-10-31 21:51:47 --> Output Class Initialized
INFO - 2019-10-31 21:51:47 --> Security Class Initialized
DEBUG - 2019-10-31 21:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:51:47 --> CSRF cookie sent
INFO - 2019-10-31 21:51:47 --> Input Class Initialized
INFO - 2019-10-31 21:51:47 --> Language Class Initialized
INFO - 2019-10-31 21:51:47 --> Language Class Initialized
INFO - 2019-10-31 21:51:47 --> Config Class Initialized
INFO - 2019-10-31 21:51:47 --> Loader Class Initialized
INFO - 2019-10-31 21:51:47 --> Helper loaded: url_helper
INFO - 2019-10-31 21:51:47 --> Helper loaded: common_helper
INFO - 2019-10-31 21:51:47 --> Helper loaded: language_helper
INFO - 2019-10-31 21:51:47 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:51:47 --> Helper loaded: email_helper
INFO - 2019-10-31 21:51:47 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:51:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:51:47 --> Parser Class Initialized
INFO - 2019-10-31 21:51:47 --> User Agent Class Initialized
INFO - 2019-10-31 21:51:47 --> Model Class Initialized
INFO - 2019-10-31 21:51:47 --> Database Driver Class Initialized
INFO - 2019-10-31 21:51:47 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:47 --> Template Class Initialized
INFO - 2019-10-31 21:51:47 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:51:47 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:51:47 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:51:47 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:51:47 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:51:47 --> Encryption Class Initialized
DEBUG - 2019-10-31 21:51:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 21:51:47 --> Controller Class Initialized
DEBUG - 2019-10-31 21:51:47 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 21:51:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 21:51:48 --> Model Class Initialized
INFO - 2019-10-31 21:51:48 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:51:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 21:51:48 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 21:51:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 21:51:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 21:51:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 21:51:48 --> Final output sent to browser
INFO - 2019-10-31 21:51:48 --> Config Class Initialized
INFO - 2019-10-31 21:51:48 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:51:48 --> Total execution time: 1.2988
DEBUG - 2019-10-31 21:51:48 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:51:48 --> Utf8 Class Initialized
INFO - 2019-10-31 21:51:48 --> URI Class Initialized
DEBUG - 2019-10-31 21:51:48 --> No URI present. Default controller set.
INFO - 2019-10-31 21:51:48 --> Router Class Initialized
INFO - 2019-10-31 21:51:48 --> Output Class Initialized
INFO - 2019-10-31 21:51:48 --> Security Class Initialized
DEBUG - 2019-10-31 21:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:51:48 --> CSRF cookie sent
INFO - 2019-10-31 21:51:48 --> Input Class Initialized
INFO - 2019-10-31 21:51:48 --> Language Class Initialized
INFO - 2019-10-31 21:51:48 --> Language Class Initialized
INFO - 2019-10-31 21:51:48 --> Config Class Initialized
INFO - 2019-10-31 21:51:48 --> Loader Class Initialized
INFO - 2019-10-31 21:51:49 --> Helper loaded: url_helper
INFO - 2019-10-31 21:51:49 --> Helper loaded: common_helper
INFO - 2019-10-31 21:51:49 --> Helper loaded: language_helper
INFO - 2019-10-31 21:51:49 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:51:49 --> Helper loaded: email_helper
INFO - 2019-10-31 21:51:49 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:51:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:51:49 --> Parser Class Initialized
INFO - 2019-10-31 21:51:49 --> User Agent Class Initialized
INFO - 2019-10-31 21:51:49 --> Model Class Initialized
INFO - 2019-10-31 21:51:49 --> Database Driver Class Initialized
INFO - 2019-10-31 21:51:49 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:49 --> Template Class Initialized
INFO - 2019-10-31 21:51:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:51:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:51:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:51:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:51:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:51:49 --> Encryption Class Initialized
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 21:51:49 --> Controller Class Initialized
DEBUG - 2019-10-31 21:51:49 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 21:51:49 --> Model Class Initialized
INFO - 2019-10-31 21:51:49 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 21:51:49 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 21:51:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 21:51:49 --> Final output sent to browser
DEBUG - 2019-10-31 21:51:49 --> Total execution time: 1.0451
INFO - 2019-10-31 21:51:53 --> Config Class Initialized
INFO - 2019-10-31 21:51:53 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:51:53 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:51:53 --> Utf8 Class Initialized
INFO - 2019-10-31 21:51:53 --> URI Class Initialized
DEBUG - 2019-10-31 21:51:53 --> No URI present. Default controller set.
INFO - 2019-10-31 21:51:53 --> Router Class Initialized
INFO - 2019-10-31 21:51:53 --> Output Class Initialized
INFO - 2019-10-31 21:51:53 --> Security Class Initialized
DEBUG - 2019-10-31 21:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:51:53 --> CSRF cookie sent
INFO - 2019-10-31 21:51:53 --> Input Class Initialized
INFO - 2019-10-31 21:51:53 --> Language Class Initialized
INFO - 2019-10-31 21:51:53 --> Language Class Initialized
INFO - 2019-10-31 21:51:53 --> Config Class Initialized
INFO - 2019-10-31 21:51:53 --> Loader Class Initialized
INFO - 2019-10-31 21:51:53 --> Helper loaded: url_helper
INFO - 2019-10-31 21:51:53 --> Helper loaded: common_helper
INFO - 2019-10-31 21:51:53 --> Helper loaded: language_helper
INFO - 2019-10-31 21:51:53 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:51:53 --> Helper loaded: email_helper
INFO - 2019-10-31 21:51:53 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:51:53 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:51:53 --> Parser Class Initialized
INFO - 2019-10-31 21:51:53 --> User Agent Class Initialized
INFO - 2019-10-31 21:51:53 --> Model Class Initialized
INFO - 2019-10-31 21:51:53 --> Database Driver Class Initialized
INFO - 2019-10-31 21:51:53 --> Model Class Initialized
DEBUG - 2019-10-31 21:51:53 --> Template Class Initialized
INFO - 2019-10-31 21:51:53 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:51:53 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:51:53 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:51:53 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:51:53 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:51:53 --> Encryption Class Initialized
DEBUG - 2019-10-31 21:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 21:51:53 --> Controller Class Initialized
DEBUG - 2019-10-31 21:51:53 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 21:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 21:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 21:51:53 --> Model Class Initialized
INFO - 2019-10-31 21:51:53 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:51:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 21:51:53 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 21:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 21:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 21:51:54 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 21:51:54 --> Final output sent to browser
DEBUG - 2019-10-31 21:51:54 --> Total execution time: 1.0626
INFO - 2019-10-31 21:52:37 --> Config Class Initialized
INFO - 2019-10-31 21:52:37 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:52:37 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:52:37 --> Utf8 Class Initialized
INFO - 2019-10-31 21:52:37 --> URI Class Initialized
INFO - 2019-10-31 21:52:37 --> Router Class Initialized
INFO - 2019-10-31 21:52:37 --> Output Class Initialized
INFO - 2019-10-31 21:52:37 --> Security Class Initialized
DEBUG - 2019-10-31 21:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:52:37 --> CSRF cookie sent
INFO - 2019-10-31 21:52:37 --> CSRF token verified
INFO - 2019-10-31 21:52:37 --> Input Class Initialized
INFO - 2019-10-31 21:52:37 --> Language Class Initialized
INFO - 2019-10-31 21:52:37 --> Language Class Initialized
INFO - 2019-10-31 21:52:37 --> Config Class Initialized
INFO - 2019-10-31 21:52:37 --> Loader Class Initialized
INFO - 2019-10-31 21:52:37 --> Helper loaded: url_helper
INFO - 2019-10-31 21:52:37 --> Helper loaded: common_helper
INFO - 2019-10-31 21:52:37 --> Helper loaded: language_helper
INFO - 2019-10-31 21:52:37 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:52:37 --> Helper loaded: email_helper
INFO - 2019-10-31 21:52:37 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:52:37 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:52:37 --> Parser Class Initialized
INFO - 2019-10-31 21:52:37 --> User Agent Class Initialized
INFO - 2019-10-31 21:52:37 --> Model Class Initialized
INFO - 2019-10-31 21:52:37 --> Database Driver Class Initialized
INFO - 2019-10-31 21:52:37 --> Model Class Initialized
DEBUG - 2019-10-31 21:52:37 --> Template Class Initialized
INFO - 2019-10-31 21:52:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:52:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:52:37 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:52:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:52:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:52:37 --> Encryption Class Initialized
INFO - 2019-10-31 21:52:37 --> Controller Class Initialized
DEBUG - 2019-10-31 21:52:37 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:52:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:52:37 --> Model Class Initialized
INFO - 2019-10-31 21:52:42 --> Config Class Initialized
INFO - 2019-10-31 21:52:42 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:52:42 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:52:42 --> Utf8 Class Initialized
INFO - 2019-10-31 21:52:42 --> URI Class Initialized
INFO - 2019-10-31 21:52:42 --> Router Class Initialized
INFO - 2019-10-31 21:52:42 --> Output Class Initialized
INFO - 2019-10-31 21:52:42 --> Security Class Initialized
DEBUG - 2019-10-31 21:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:52:42 --> CSRF cookie sent
INFO - 2019-10-31 21:52:42 --> Input Class Initialized
INFO - 2019-10-31 21:52:42 --> Language Class Initialized
INFO - 2019-10-31 21:52:42 --> Language Class Initialized
INFO - 2019-10-31 21:52:42 --> Config Class Initialized
INFO - 2019-10-31 21:52:42 --> Loader Class Initialized
INFO - 2019-10-31 21:52:42 --> Helper loaded: url_helper
INFO - 2019-10-31 21:52:42 --> Helper loaded: common_helper
INFO - 2019-10-31 21:52:42 --> Helper loaded: language_helper
INFO - 2019-10-31 21:52:42 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:52:42 --> Helper loaded: email_helper
INFO - 2019-10-31 21:52:43 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:52:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:52:43 --> Parser Class Initialized
INFO - 2019-10-31 21:52:43 --> User Agent Class Initialized
INFO - 2019-10-31 21:52:43 --> Model Class Initialized
INFO - 2019-10-31 21:52:43 --> Database Driver Class Initialized
INFO - 2019-10-31 21:52:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:52:43 --> Template Class Initialized
INFO - 2019-10-31 21:52:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:52:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:52:43 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:52:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:52:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:52:43 --> Encryption Class Initialized
INFO - 2019-10-31 21:52:43 --> Controller Class Initialized
DEBUG - 2019-10-31 21:52:43 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 21:52:43 --> Model Class Initialized
INFO - 2019-10-31 21:52:43 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:52:43 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:52:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:52:43 --> Model Class Initialized
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:52:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:52:43 --> Final output sent to browser
DEBUG - 2019-10-31 21:52:43 --> Total execution time: 0.9199
INFO - 2019-10-31 21:53:54 --> Config Class Initialized
INFO - 2019-10-31 21:53:54 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:53:54 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:53:54 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:54 --> URI Class Initialized
INFO - 2019-10-31 21:53:54 --> Router Class Initialized
INFO - 2019-10-31 21:53:55 --> Output Class Initialized
INFO - 2019-10-31 21:53:55 --> Security Class Initialized
DEBUG - 2019-10-31 21:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:53:55 --> CSRF cookie sent
INFO - 2019-10-31 21:53:55 --> Input Class Initialized
INFO - 2019-10-31 21:53:55 --> Language Class Initialized
INFO - 2019-10-31 21:53:55 --> Language Class Initialized
INFO - 2019-10-31 21:53:55 --> Config Class Initialized
INFO - 2019-10-31 21:53:55 --> Loader Class Initialized
INFO - 2019-10-31 21:53:55 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:55 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:55 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:55 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:55 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:55 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:55 --> Parser Class Initialized
INFO - 2019-10-31 21:53:55 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:55 --> Model Class Initialized
INFO - 2019-10-31 21:53:55 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:55 --> Model Class Initialized
DEBUG - 2019-10-31 21:53:55 --> Template Class Initialized
INFO - 2019-10-31 21:53:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:55 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:55 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:55 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:55 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:55 --> Model Class Initialized
ERROR - 2019-10-31 21:53:55 --> Could not find the language line "Sorting"
INFO - 2019-10-31 21:53:55 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:53:55 --> Could not find the language line "Delele"
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:53:55 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:53:55 --> Model Class Initialized
DEBUG - 2019-10-31 21:53:55 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:55 --> Model Class Initialized
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:53:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:53:55 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:55 --> Total execution time: 0.8627
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Hooks Class Initialized
INFO - 2019-10-31 21:53:56 --> Hooks Class Initialized
INFO - 2019-10-31 21:53:56 --> Hooks Class Initialized
INFO - 2019-10-31 21:53:56 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:53:56 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:53:56 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:53:56 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:56 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:56 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:56 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:56 --> URI Class Initialized
INFO - 2019-10-31 21:53:56 --> URI Class Initialized
INFO - 2019-10-31 21:53:56 --> URI Class Initialized
INFO - 2019-10-31 21:53:56 --> URI Class Initialized
INFO - 2019-10-31 21:53:56 --> Router Class Initialized
INFO - 2019-10-31 21:53:56 --> Router Class Initialized
INFO - 2019-10-31 21:53:56 --> Router Class Initialized
INFO - 2019-10-31 21:53:56 --> Router Class Initialized
INFO - 2019-10-31 21:53:56 --> Output Class Initialized
INFO - 2019-10-31 21:53:56 --> Output Class Initialized
INFO - 2019-10-31 21:53:56 --> Output Class Initialized
INFO - 2019-10-31 21:53:56 --> Output Class Initialized
INFO - 2019-10-31 21:53:56 --> Security Class Initialized
INFO - 2019-10-31 21:53:56 --> Security Class Initialized
INFO - 2019-10-31 21:53:56 --> Security Class Initialized
INFO - 2019-10-31 21:53:56 --> Security Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:53:56 --> CSRF cookie sent
INFO - 2019-10-31 21:53:56 --> CSRF cookie sent
INFO - 2019-10-31 21:53:56 --> CSRF cookie sent
INFO - 2019-10-31 21:53:56 --> CSRF cookie sent
INFO - 2019-10-31 21:53:56 --> CSRF token verified
INFO - 2019-10-31 21:53:56 --> CSRF token verified
INFO - 2019-10-31 21:53:56 --> CSRF token verified
INFO - 2019-10-31 21:53:56 --> CSRF token verified
INFO - 2019-10-31 21:53:56 --> Input Class Initialized
INFO - 2019-10-31 21:53:56 --> Input Class Initialized
INFO - 2019-10-31 21:53:56 --> Input Class Initialized
INFO - 2019-10-31 21:53:56 --> Input Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Language Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Config Class Initialized
INFO - 2019-10-31 21:53:56 --> Loader Class Initialized
INFO - 2019-10-31 21:53:56 --> Loader Class Initialized
INFO - 2019-10-31 21:53:56 --> Loader Class Initialized
INFO - 2019-10-31 21:53:56 --> Loader Class Initialized
INFO - 2019-10-31 21:53:56 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:56 --> Parser Class Initialized
INFO - 2019-10-31 21:53:56 --> Parser Class Initialized
INFO - 2019-10-31 21:53:56 --> Parser Class Initialized
INFO - 2019-10-31 21:53:56 --> Parser Class Initialized
INFO - 2019-10-31 21:53:56 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:56 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:56 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:56 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:56 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:56 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:56 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Template Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Template Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Template Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Template Class Initialized
INFO - 2019-10-31 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:56 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:56 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:56 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:56 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:56 --> Model Class Initialized
ERROR - 2019-10-31 21:53:56 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:53:56 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:53:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:53:56 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:56 --> Total execution time: 0.6968
INFO - 2019-10-31 21:53:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:57 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:57 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:57 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:57 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:57 --> Model Class Initialized
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:53:57 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:57 --> Total execution time: 0.9378
INFO - 2019-10-31 21:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:57 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:57 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:57 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:57 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:57 --> Model Class Initialized
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:53:57 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:57 --> Total execution time: 1.2038
INFO - 2019-10-31 21:53:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:57 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:57 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:57 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:57 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:57 --> Model Class Initialized
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
ERROR - 2019-10-31 21:53:57 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:53:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:53:57 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:57 --> Total execution time: 1.4313
INFO - 2019-10-31 21:53:58 --> Config Class Initialized
INFO - 2019-10-31 21:53:58 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:53:58 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:53:58 --> Utf8 Class Initialized
INFO - 2019-10-31 21:53:58 --> URI Class Initialized
INFO - 2019-10-31 21:53:58 --> Router Class Initialized
INFO - 2019-10-31 21:53:59 --> Output Class Initialized
INFO - 2019-10-31 21:53:59 --> Security Class Initialized
DEBUG - 2019-10-31 21:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:53:59 --> CSRF cookie sent
INFO - 2019-10-31 21:53:59 --> Input Class Initialized
INFO - 2019-10-31 21:53:59 --> Language Class Initialized
INFO - 2019-10-31 21:53:59 --> Language Class Initialized
INFO - 2019-10-31 21:53:59 --> Config Class Initialized
INFO - 2019-10-31 21:53:59 --> Loader Class Initialized
INFO - 2019-10-31 21:53:59 --> Helper loaded: url_helper
INFO - 2019-10-31 21:53:59 --> Helper loaded: common_helper
INFO - 2019-10-31 21:53:59 --> Helper loaded: language_helper
INFO - 2019-10-31 21:53:59 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:53:59 --> Helper loaded: email_helper
INFO - 2019-10-31 21:53:59 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:53:59 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:53:59 --> Parser Class Initialized
INFO - 2019-10-31 21:53:59 --> User Agent Class Initialized
INFO - 2019-10-31 21:53:59 --> Model Class Initialized
INFO - 2019-10-31 21:53:59 --> Database Driver Class Initialized
INFO - 2019-10-31 21:53:59 --> Model Class Initialized
DEBUG - 2019-10-31 21:53:59 --> Template Class Initialized
INFO - 2019-10-31 21:53:59 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:53:59 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:53:59 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:53:59 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:53:59 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:53:59 --> Encryption Class Initialized
INFO - 2019-10-31 21:53:59 --> Controller Class Initialized
DEBUG - 2019-10-31 21:53:59 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:53:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:53:59 --> Model Class Initialized
ERROR - 2019-10-31 21:53:59 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:53:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:53:59 --> Final output sent to browser
DEBUG - 2019-10-31 21:53:59 --> Total execution time: 0.6669
INFO - 2019-10-31 21:54:07 --> Config Class Initialized
INFO - 2019-10-31 21:54:07 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:54:07 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:54:07 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:07 --> URI Class Initialized
INFO - 2019-10-31 21:54:07 --> Router Class Initialized
INFO - 2019-10-31 21:54:07 --> Output Class Initialized
INFO - 2019-10-31 21:54:08 --> Security Class Initialized
DEBUG - 2019-10-31 21:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:54:08 --> CSRF cookie sent
INFO - 2019-10-31 21:54:08 --> CSRF token verified
INFO - 2019-10-31 21:54:08 --> Input Class Initialized
INFO - 2019-10-31 21:54:08 --> Language Class Initialized
INFO - 2019-10-31 21:54:08 --> Language Class Initialized
INFO - 2019-10-31 21:54:08 --> Config Class Initialized
INFO - 2019-10-31 21:54:08 --> Loader Class Initialized
INFO - 2019-10-31 21:54:08 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:08 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:08 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:08 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:08 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:08 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:08 --> Parser Class Initialized
INFO - 2019-10-31 21:54:08 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:08 --> Model Class Initialized
INFO - 2019-10-31 21:54:08 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:08 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:08 --> Template Class Initialized
INFO - 2019-10-31 21:54:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:08 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:08 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:08 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:08 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:08 --> Model Class Initialized
ERROR - 2019-10-31 21:54:08 --> Could not find the language line "Sorting"
INFO - 2019-10-31 21:54:13 --> Config Class Initialized
INFO - 2019-10-31 21:54:13 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:54:13 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:54:13 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:13 --> URI Class Initialized
INFO - 2019-10-31 21:54:13 --> Router Class Initialized
INFO - 2019-10-31 21:54:13 --> Output Class Initialized
INFO - 2019-10-31 21:54:13 --> Security Class Initialized
DEBUG - 2019-10-31 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:54:13 --> CSRF cookie sent
INFO - 2019-10-31 21:54:13 --> Input Class Initialized
INFO - 2019-10-31 21:54:13 --> Language Class Initialized
INFO - 2019-10-31 21:54:13 --> Language Class Initialized
INFO - 2019-10-31 21:54:13 --> Config Class Initialized
INFO - 2019-10-31 21:54:13 --> Loader Class Initialized
INFO - 2019-10-31 21:54:13 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:13 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:13 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:13 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:13 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:13 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:13 --> Parser Class Initialized
INFO - 2019-10-31 21:54:13 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:13 --> Model Class Initialized
INFO - 2019-10-31 21:54:13 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:13 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:13 --> Template Class Initialized
INFO - 2019-10-31 21:54:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:13 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:13 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:13 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:13 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:13 --> Model Class Initialized
ERROR - 2019-10-31 21:54:13 --> Could not find the language line "Sorting"
INFO - 2019-10-31 21:54:13 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:54:13 --> Could not find the language line "Delele"
DEBUG - 2019-10-31 21:54:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-10-31 21:54:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:54:13 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:54:13 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:54:13 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:13 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:13 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:54:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:54:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:54:14 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:14 --> Total execution time: 0.8506
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Hooks Class Initialized
INFO - 2019-10-31 21:54:14 --> Hooks Class Initialized
INFO - 2019-10-31 21:54:14 --> Hooks Class Initialized
INFO - 2019-10-31 21:54:14 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:54:14 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:54:14 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:54:14 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:14 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:14 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:14 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:14 --> URI Class Initialized
INFO - 2019-10-31 21:54:14 --> URI Class Initialized
INFO - 2019-10-31 21:54:14 --> URI Class Initialized
INFO - 2019-10-31 21:54:14 --> URI Class Initialized
INFO - 2019-10-31 21:54:14 --> Router Class Initialized
INFO - 2019-10-31 21:54:14 --> Router Class Initialized
INFO - 2019-10-31 21:54:14 --> Router Class Initialized
INFO - 2019-10-31 21:54:14 --> Router Class Initialized
INFO - 2019-10-31 21:54:14 --> Output Class Initialized
INFO - 2019-10-31 21:54:14 --> Output Class Initialized
INFO - 2019-10-31 21:54:14 --> Output Class Initialized
INFO - 2019-10-31 21:54:14 --> Output Class Initialized
INFO - 2019-10-31 21:54:14 --> Security Class Initialized
INFO - 2019-10-31 21:54:14 --> Security Class Initialized
INFO - 2019-10-31 21:54:14 --> Security Class Initialized
INFO - 2019-10-31 21:54:14 --> Security Class Initialized
DEBUG - 2019-10-31 21:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:54:14 --> CSRF cookie sent
INFO - 2019-10-31 21:54:14 --> CSRF cookie sent
INFO - 2019-10-31 21:54:14 --> CSRF cookie sent
INFO - 2019-10-31 21:54:14 --> CSRF cookie sent
INFO - 2019-10-31 21:54:14 --> CSRF token verified
INFO - 2019-10-31 21:54:14 --> CSRF token verified
INFO - 2019-10-31 21:54:14 --> CSRF token verified
INFO - 2019-10-31 21:54:14 --> CSRF token verified
INFO - 2019-10-31 21:54:14 --> Input Class Initialized
INFO - 2019-10-31 21:54:14 --> Input Class Initialized
INFO - 2019-10-31 21:54:14 --> Input Class Initialized
INFO - 2019-10-31 21:54:14 --> Input Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Language Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Config Class Initialized
INFO - 2019-10-31 21:54:14 --> Loader Class Initialized
INFO - 2019-10-31 21:54:14 --> Loader Class Initialized
INFO - 2019-10-31 21:54:14 --> Loader Class Initialized
INFO - 2019-10-31 21:54:14 --> Loader Class Initialized
INFO - 2019-10-31 21:54:14 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:14 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:14 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:14 --> Parser Class Initialized
INFO - 2019-10-31 21:54:14 --> Parser Class Initialized
INFO - 2019-10-31 21:54:14 --> Parser Class Initialized
INFO - 2019-10-31 21:54:14 --> Parser Class Initialized
INFO - 2019-10-31 21:54:14 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:14 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:14 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:14 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:14 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:14 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:14 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
INFO - 2019-10-31 21:54:14 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:14 --> Template Class Initialized
DEBUG - 2019-10-31 21:54:14 --> Template Class Initialized
DEBUG - 2019-10-31 21:54:14 --> Template Class Initialized
DEBUG - 2019-10-31 21:54:14 --> Template Class Initialized
INFO - 2019-10-31 21:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:15 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:15 --> Model Class Initialized
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:54:15 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:15 --> Total execution time: 0.6193
INFO - 2019-10-31 21:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:15 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:15 --> Model Class Initialized
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:54:15 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:15 --> Total execution time: 0.8330
INFO - 2019-10-31 21:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:15 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:15 --> Model Class Initialized
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:54:15 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:15 --> Total execution time: 1.0516
INFO - 2019-10-31 21:54:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:15 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:54:15 --> Model Class Initialized
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
ERROR - 2019-10-31 21:54:15 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:54:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:54:15 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:15 --> Total execution time: 1.2840
INFO - 2019-10-31 21:54:17 --> Config Class Initialized
INFO - 2019-10-31 21:54:17 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:54:17 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:54:17 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:17 --> URI Class Initialized
INFO - 2019-10-31 21:54:17 --> Router Class Initialized
INFO - 2019-10-31 21:54:17 --> Output Class Initialized
INFO - 2019-10-31 21:54:17 --> Security Class Initialized
DEBUG - 2019-10-31 21:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:54:17 --> CSRF cookie sent
INFO - 2019-10-31 21:54:17 --> Input Class Initialized
INFO - 2019-10-31 21:54:17 --> Language Class Initialized
INFO - 2019-10-31 21:54:17 --> Language Class Initialized
INFO - 2019-10-31 21:54:17 --> Config Class Initialized
INFO - 2019-10-31 21:54:17 --> Loader Class Initialized
INFO - 2019-10-31 21:54:17 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:17 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:17 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:18 --> Parser Class Initialized
INFO - 2019-10-31 21:54:18 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:18 --> Model Class Initialized
INFO - 2019-10-31 21:54:18 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:18 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:18 --> Template Class Initialized
INFO - 2019-10-31 21:54:18 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:18 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:18 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:18 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:18 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:18 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:18 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:18 --> custom_page MX_Controller Initialized
DEBUG - 2019-10-31 21:54:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-10-31 21:54:18 --> Model Class Initialized
INFO - 2019-10-31 21:54:18 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:54:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-10-31 21:54:18 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-10-31 21:54:18 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:18 --> Total execution time: 0.8497
INFO - 2019-10-31 21:54:18 --> Config Class Initialized
INFO - 2019-10-31 21:54:18 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:54:18 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:54:18 --> Utf8 Class Initialized
INFO - 2019-10-31 21:54:18 --> URI Class Initialized
INFO - 2019-10-31 21:54:18 --> Router Class Initialized
INFO - 2019-10-31 21:54:18 --> Output Class Initialized
INFO - 2019-10-31 21:54:18 --> Security Class Initialized
DEBUG - 2019-10-31 21:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:54:18 --> CSRF cookie sent
INFO - 2019-10-31 21:54:18 --> Input Class Initialized
INFO - 2019-10-31 21:54:18 --> Language Class Initialized
INFO - 2019-10-31 21:54:18 --> Language Class Initialized
INFO - 2019-10-31 21:54:18 --> Config Class Initialized
INFO - 2019-10-31 21:54:18 --> Loader Class Initialized
INFO - 2019-10-31 21:54:18 --> Helper loaded: url_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: common_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: language_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: email_helper
INFO - 2019-10-31 21:54:18 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:54:18 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:54:19 --> Parser Class Initialized
INFO - 2019-10-31 21:54:19 --> User Agent Class Initialized
INFO - 2019-10-31 21:54:19 --> Model Class Initialized
INFO - 2019-10-31 21:54:19 --> Database Driver Class Initialized
INFO - 2019-10-31 21:54:19 --> Model Class Initialized
DEBUG - 2019-10-31 21:54:19 --> Template Class Initialized
INFO - 2019-10-31 21:54:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:54:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:54:19 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:54:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:54:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:54:19 --> Encryption Class Initialized
INFO - 2019-10-31 21:54:19 --> Controller Class Initialized
DEBUG - 2019-10-31 21:54:19 --> custom_page MX_Controller Initialized
DEBUG - 2019-10-31 21:54:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-10-31 21:54:19 --> Model Class Initialized
INFO - 2019-10-31 21:54:19 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 21:54:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-10-31 21:54:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-10-31 21:54:19 --> Final output sent to browser
DEBUG - 2019-10-31 21:54:19 --> Total execution time: 0.8898
INFO - 2019-10-31 21:58:31 --> Config Class Initialized
INFO - 2019-10-31 21:58:31 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:58:31 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:58:31 --> Utf8 Class Initialized
INFO - 2019-10-31 21:58:31 --> URI Class Initialized
INFO - 2019-10-31 21:58:31 --> Router Class Initialized
INFO - 2019-10-31 21:58:31 --> Output Class Initialized
INFO - 2019-10-31 21:58:31 --> Security Class Initialized
DEBUG - 2019-10-31 21:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:58:31 --> CSRF cookie sent
INFO - 2019-10-31 21:58:31 --> Input Class Initialized
INFO - 2019-10-31 21:58:32 --> Language Class Initialized
INFO - 2019-10-31 21:58:32 --> Language Class Initialized
INFO - 2019-10-31 21:58:32 --> Config Class Initialized
INFO - 2019-10-31 21:58:32 --> Loader Class Initialized
INFO - 2019-10-31 21:58:32 --> Helper loaded: url_helper
INFO - 2019-10-31 21:58:32 --> Helper loaded: common_helper
INFO - 2019-10-31 21:58:32 --> Helper loaded: language_helper
INFO - 2019-10-31 21:58:32 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:58:32 --> Helper loaded: email_helper
INFO - 2019-10-31 21:58:32 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:58:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:58:32 --> Parser Class Initialized
INFO - 2019-10-31 21:58:32 --> User Agent Class Initialized
INFO - 2019-10-31 21:58:32 --> Model Class Initialized
INFO - 2019-10-31 21:58:32 --> Database Driver Class Initialized
INFO - 2019-10-31 21:58:32 --> Model Class Initialized
DEBUG - 2019-10-31 21:58:32 --> Template Class Initialized
INFO - 2019-10-31 21:58:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:58:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:58:32 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:58:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:58:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:58:32 --> Encryption Class Initialized
INFO - 2019-10-31 21:58:32 --> Controller Class Initialized
DEBUG - 2019-10-31 21:58:32 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:58:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:58:32 --> Model Class Initialized
ERROR - 2019-10-31 21:58:32 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:58:32 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 75
DEBUG - 2019-10-31 21:58:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:58:32 --> Final output sent to browser
DEBUG - 2019-10-31 21:58:32 --> Total execution time: 0.6111
INFO - 2019-10-31 21:58:49 --> Config Class Initialized
INFO - 2019-10-31 21:58:49 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:58:49 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:58:49 --> Utf8 Class Initialized
INFO - 2019-10-31 21:58:49 --> URI Class Initialized
INFO - 2019-10-31 21:58:49 --> Router Class Initialized
INFO - 2019-10-31 21:58:49 --> Output Class Initialized
INFO - 2019-10-31 21:58:49 --> Security Class Initialized
DEBUG - 2019-10-31 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:58:49 --> CSRF cookie sent
INFO - 2019-10-31 21:58:49 --> Input Class Initialized
INFO - 2019-10-31 21:58:49 --> Language Class Initialized
INFO - 2019-10-31 21:58:49 --> Language Class Initialized
INFO - 2019-10-31 21:58:49 --> Config Class Initialized
INFO - 2019-10-31 21:58:49 --> Loader Class Initialized
INFO - 2019-10-31 21:58:49 --> Helper loaded: url_helper
INFO - 2019-10-31 21:58:49 --> Helper loaded: common_helper
INFO - 2019-10-31 21:58:49 --> Helper loaded: language_helper
INFO - 2019-10-31 21:58:49 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:58:49 --> Helper loaded: email_helper
INFO - 2019-10-31 21:58:49 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:58:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:58:49 --> Parser Class Initialized
INFO - 2019-10-31 21:58:49 --> User Agent Class Initialized
INFO - 2019-10-31 21:58:49 --> Model Class Initialized
INFO - 2019-10-31 21:58:49 --> Database Driver Class Initialized
INFO - 2019-10-31 21:58:49 --> Model Class Initialized
DEBUG - 2019-10-31 21:58:49 --> Template Class Initialized
INFO - 2019-10-31 21:58:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:58:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:58:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:58:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:58:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:58:49 --> Encryption Class Initialized
INFO - 2019-10-31 21:58:49 --> Controller Class Initialized
DEBUG - 2019-10-31 21:58:49 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:58:49 --> Model Class Initialized
ERROR - 2019-10-31 21:58:49 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:58:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:58:49 --> Final output sent to browser
DEBUG - 2019-10-31 21:58:49 --> Total execution time: 0.5692
INFO - 2019-10-31 21:59:04 --> Config Class Initialized
INFO - 2019-10-31 21:59:04 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:04 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:04 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:04 --> URI Class Initialized
INFO - 2019-10-31 21:59:04 --> Router Class Initialized
INFO - 2019-10-31 21:59:04 --> Output Class Initialized
INFO - 2019-10-31 21:59:04 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:04 --> CSRF cookie sent
INFO - 2019-10-31 21:59:04 --> Input Class Initialized
INFO - 2019-10-31 21:59:04 --> Language Class Initialized
INFO - 2019-10-31 21:59:04 --> Language Class Initialized
INFO - 2019-10-31 21:59:04 --> Config Class Initialized
INFO - 2019-10-31 21:59:04 --> Loader Class Initialized
INFO - 2019-10-31 21:59:04 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:04 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:04 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:04 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:04 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:04 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:04 --> Parser Class Initialized
INFO - 2019-10-31 21:59:04 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:04 --> Model Class Initialized
INFO - 2019-10-31 21:59:04 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:04 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:04 --> Template Class Initialized
INFO - 2019-10-31 21:59:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:04 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:04 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:04 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:05 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:05 --> Model Class Initialized
ERROR - 2019-10-31 21:59:05 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:59:05 --> Severity: Notice --> Undefined offset: 1 D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\category\views\update.php 75
DEBUG - 2019-10-31 21:59:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:59:05 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:05 --> Total execution time: 0.5493
INFO - 2019-10-31 21:59:14 --> Config Class Initialized
INFO - 2019-10-31 21:59:14 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:14 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:14 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:14 --> URI Class Initialized
INFO - 2019-10-31 21:59:14 --> Router Class Initialized
INFO - 2019-10-31 21:59:14 --> Output Class Initialized
INFO - 2019-10-31 21:59:14 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:14 --> CSRF cookie sent
INFO - 2019-10-31 21:59:15 --> CSRF token verified
INFO - 2019-10-31 21:59:15 --> Input Class Initialized
INFO - 2019-10-31 21:59:15 --> Language Class Initialized
INFO - 2019-10-31 21:59:15 --> Language Class Initialized
INFO - 2019-10-31 21:59:15 --> Config Class Initialized
INFO - 2019-10-31 21:59:15 --> Loader Class Initialized
INFO - 2019-10-31 21:59:15 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:15 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:15 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:15 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:15 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:15 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:15 --> Parser Class Initialized
INFO - 2019-10-31 21:59:15 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:15 --> Model Class Initialized
INFO - 2019-10-31 21:59:15 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:15 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:15 --> Template Class Initialized
INFO - 2019-10-31 21:59:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:15 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:15 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:15 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:15 --> Model Class Initialized
ERROR - 2019-10-31 21:59:15 --> Could not find the language line "Sorting"
INFO - 2019-10-31 21:59:20 --> Config Class Initialized
INFO - 2019-10-31 21:59:20 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:20 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:20 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:20 --> URI Class Initialized
INFO - 2019-10-31 21:59:20 --> Router Class Initialized
INFO - 2019-10-31 21:59:20 --> Output Class Initialized
INFO - 2019-10-31 21:59:20 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:20 --> CSRF cookie sent
INFO - 2019-10-31 21:59:20 --> Input Class Initialized
INFO - 2019-10-31 21:59:20 --> Language Class Initialized
INFO - 2019-10-31 21:59:20 --> Language Class Initialized
INFO - 2019-10-31 21:59:20 --> Config Class Initialized
INFO - 2019-10-31 21:59:20 --> Loader Class Initialized
INFO - 2019-10-31 21:59:20 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:20 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:20 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:20 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:20 --> Parser Class Initialized
INFO - 2019-10-31 21:59:20 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:20 --> Model Class Initialized
INFO - 2019-10-31 21:59:20 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:20 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:20 --> Template Class Initialized
INFO - 2019-10-31 21:59:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:20 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:20 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:20 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:20 --> Model Class Initialized
ERROR - 2019-10-31 21:59:20 --> Could not find the language line "Sorting"
INFO - 2019-10-31 21:59:20 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 21:59:20 --> Could not find the language line "Delele"
DEBUG - 2019-10-31 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-10-31 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 21:59:20 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 21:59:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 21:59:20 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:20 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:21 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 21:59:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 21:59:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 21:59:21 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:21 --> Total execution time: 0.9290
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Hooks Class Initialized
INFO - 2019-10-31 21:59:21 --> Hooks Class Initialized
INFO - 2019-10-31 21:59:21 --> Hooks Class Initialized
INFO - 2019-10-31 21:59:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:59:21 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 21:59:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:21 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:21 --> URI Class Initialized
INFO - 2019-10-31 21:59:21 --> URI Class Initialized
INFO - 2019-10-31 21:59:21 --> URI Class Initialized
INFO - 2019-10-31 21:59:21 --> URI Class Initialized
INFO - 2019-10-31 21:59:21 --> Router Class Initialized
INFO - 2019-10-31 21:59:21 --> Router Class Initialized
INFO - 2019-10-31 21:59:21 --> Router Class Initialized
INFO - 2019-10-31 21:59:21 --> Router Class Initialized
INFO - 2019-10-31 21:59:21 --> Output Class Initialized
INFO - 2019-10-31 21:59:21 --> Output Class Initialized
INFO - 2019-10-31 21:59:21 --> Output Class Initialized
INFO - 2019-10-31 21:59:21 --> Output Class Initialized
INFO - 2019-10-31 21:59:21 --> Security Class Initialized
INFO - 2019-10-31 21:59:21 --> Security Class Initialized
INFO - 2019-10-31 21:59:21 --> Security Class Initialized
INFO - 2019-10-31 21:59:21 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 21:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:21 --> CSRF cookie sent
INFO - 2019-10-31 21:59:21 --> CSRF cookie sent
INFO - 2019-10-31 21:59:21 --> CSRF cookie sent
INFO - 2019-10-31 21:59:21 --> CSRF cookie sent
INFO - 2019-10-31 21:59:21 --> CSRF token verified
INFO - 2019-10-31 21:59:21 --> CSRF token verified
INFO - 2019-10-31 21:59:21 --> CSRF token verified
INFO - 2019-10-31 21:59:21 --> CSRF token verified
INFO - 2019-10-31 21:59:21 --> Input Class Initialized
INFO - 2019-10-31 21:59:21 --> Input Class Initialized
INFO - 2019-10-31 21:59:21 --> Input Class Initialized
INFO - 2019-10-31 21:59:21 --> Input Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Language Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Config Class Initialized
INFO - 2019-10-31 21:59:21 --> Loader Class Initialized
INFO - 2019-10-31 21:59:21 --> Loader Class Initialized
INFO - 2019-10-31 21:59:21 --> Loader Class Initialized
INFO - 2019-10-31 21:59:21 --> Loader Class Initialized
INFO - 2019-10-31 21:59:21 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:21 --> Parser Class Initialized
INFO - 2019-10-31 21:59:21 --> Parser Class Initialized
INFO - 2019-10-31 21:59:21 --> Parser Class Initialized
INFO - 2019-10-31 21:59:21 --> Parser Class Initialized
INFO - 2019-10-31 21:59:21 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:21 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:21 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:21 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:22 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Template Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Template Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Template Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Template Class Initialized
INFO - 2019-10-31 21:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:22 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:59:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:22 --> Total execution time: 0.6800
INFO - 2019-10-31 21:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:22 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:59:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:22 --> Total execution time: 0.9062
INFO - 2019-10-31 21:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:22 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:59:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:22 --> Total execution time: 1.1723
INFO - 2019-10-31 21:59:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:22 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:22 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:22 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:22 --> Model Class Initialized
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
ERROR - 2019-10-31 21:59:22 --> Could not find the language line "View"
DEBUG - 2019-10-31 21:59:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 21:59:22 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:23 --> Total execution time: 1.4186
INFO - 2019-10-31 21:59:24 --> Config Class Initialized
INFO - 2019-10-31 21:59:24 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:24 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:24 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:24 --> URI Class Initialized
INFO - 2019-10-31 21:59:24 --> Router Class Initialized
INFO - 2019-10-31 21:59:24 --> Output Class Initialized
INFO - 2019-10-31 21:59:24 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:24 --> CSRF cookie sent
INFO - 2019-10-31 21:59:24 --> Input Class Initialized
INFO - 2019-10-31 21:59:24 --> Language Class Initialized
INFO - 2019-10-31 21:59:24 --> Language Class Initialized
INFO - 2019-10-31 21:59:24 --> Config Class Initialized
INFO - 2019-10-31 21:59:24 --> Loader Class Initialized
INFO - 2019-10-31 21:59:24 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:24 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:24 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:24 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:24 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:24 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:24 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:24 --> Parser Class Initialized
INFO - 2019-10-31 21:59:24 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:24 --> Model Class Initialized
INFO - 2019-10-31 21:59:24 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:24 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:24 --> Template Class Initialized
INFO - 2019-10-31 21:59:24 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:24 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:24 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:24 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:24 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:24 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:24 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:24 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:24 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:24 --> Model Class Initialized
ERROR - 2019-10-31 21:59:25 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:59:25 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:59:25 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:25 --> Total execution time: 0.5720
INFO - 2019-10-31 21:59:30 --> Config Class Initialized
INFO - 2019-10-31 21:59:30 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:30 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:30 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:30 --> URI Class Initialized
INFO - 2019-10-31 21:59:30 --> Router Class Initialized
INFO - 2019-10-31 21:59:30 --> Output Class Initialized
INFO - 2019-10-31 21:59:30 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:30 --> CSRF cookie sent
INFO - 2019-10-31 21:59:30 --> Input Class Initialized
INFO - 2019-10-31 21:59:30 --> Language Class Initialized
INFO - 2019-10-31 21:59:30 --> Language Class Initialized
INFO - 2019-10-31 21:59:30 --> Config Class Initialized
INFO - 2019-10-31 21:59:30 --> Loader Class Initialized
INFO - 2019-10-31 21:59:30 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:30 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:30 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:30 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:30 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:30 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:30 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:30 --> Parser Class Initialized
INFO - 2019-10-31 21:59:30 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:30 --> Model Class Initialized
INFO - 2019-10-31 21:59:30 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:30 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:30 --> Template Class Initialized
INFO - 2019-10-31 21:59:30 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:31 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:31 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:31 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:31 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:31 --> Model Class Initialized
ERROR - 2019-10-31 21:59:31 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:59:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:59:31 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:31 --> Total execution time: 0.6236
INFO - 2019-10-31 21:59:31 --> Config Class Initialized
INFO - 2019-10-31 21:59:31 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:31 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:31 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:31 --> URI Class Initialized
INFO - 2019-10-31 21:59:31 --> Router Class Initialized
INFO - 2019-10-31 21:59:31 --> Output Class Initialized
INFO - 2019-10-31 21:59:31 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:31 --> CSRF cookie sent
INFO - 2019-10-31 21:59:31 --> Input Class Initialized
INFO - 2019-10-31 21:59:31 --> Language Class Initialized
INFO - 2019-10-31 21:59:31 --> Language Class Initialized
INFO - 2019-10-31 21:59:31 --> Config Class Initialized
INFO - 2019-10-31 21:59:31 --> Loader Class Initialized
INFO - 2019-10-31 21:59:31 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:31 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:31 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:31 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:31 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:31 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:31 --> Parser Class Initialized
INFO - 2019-10-31 21:59:31 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:31 --> Model Class Initialized
INFO - 2019-10-31 21:59:31 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:31 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:31 --> Template Class Initialized
INFO - 2019-10-31 21:59:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:31 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:31 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:31 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:31 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:31 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:31 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:31 --> Model Class Initialized
ERROR - 2019-10-31 21:59:31 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:59:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:59:32 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:32 --> Total execution time: 0.8486
INFO - 2019-10-31 21:59:32 --> Config Class Initialized
INFO - 2019-10-31 21:59:32 --> Hooks Class Initialized
DEBUG - 2019-10-31 21:59:32 --> UTF-8 Support Enabled
INFO - 2019-10-31 21:59:32 --> Utf8 Class Initialized
INFO - 2019-10-31 21:59:32 --> URI Class Initialized
INFO - 2019-10-31 21:59:32 --> Router Class Initialized
INFO - 2019-10-31 21:59:32 --> Output Class Initialized
INFO - 2019-10-31 21:59:32 --> Security Class Initialized
DEBUG - 2019-10-31 21:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 21:59:32 --> CSRF cookie sent
INFO - 2019-10-31 21:59:32 --> Input Class Initialized
INFO - 2019-10-31 21:59:32 --> Language Class Initialized
INFO - 2019-10-31 21:59:32 --> Language Class Initialized
INFO - 2019-10-31 21:59:32 --> Config Class Initialized
INFO - 2019-10-31 21:59:32 --> Loader Class Initialized
INFO - 2019-10-31 21:59:32 --> Helper loaded: url_helper
INFO - 2019-10-31 21:59:32 --> Helper loaded: common_helper
INFO - 2019-10-31 21:59:32 --> Helper loaded: language_helper
INFO - 2019-10-31 21:59:32 --> Helper loaded: cookie_helper
INFO - 2019-10-31 21:59:32 --> Helper loaded: email_helper
INFO - 2019-10-31 21:59:32 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 21:59:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 21:59:32 --> Parser Class Initialized
INFO - 2019-10-31 21:59:32 --> User Agent Class Initialized
INFO - 2019-10-31 21:59:32 --> Model Class Initialized
INFO - 2019-10-31 21:59:32 --> Database Driver Class Initialized
INFO - 2019-10-31 21:59:32 --> Model Class Initialized
DEBUG - 2019-10-31 21:59:32 --> Template Class Initialized
INFO - 2019-10-31 21:59:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 21:59:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 21:59:32 --> Pagination Class Initialized
DEBUG - 2019-10-31 21:59:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 21:59:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 21:59:32 --> Encryption Class Initialized
INFO - 2019-10-31 21:59:32 --> Controller Class Initialized
DEBUG - 2019-10-31 21:59:32 --> category MX_Controller Initialized
DEBUG - 2019-10-31 21:59:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 21:59:32 --> Model Class Initialized
ERROR - 2019-10-31 21:59:32 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 21:59:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 21:59:32 --> Final output sent to browser
DEBUG - 2019-10-31 21:59:32 --> Total execution time: 0.6330
INFO - 2019-10-31 22:00:21 --> Config Class Initialized
INFO - 2019-10-31 22:00:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:00:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:00:21 --> Utf8 Class Initialized
INFO - 2019-10-31 22:00:21 --> URI Class Initialized
INFO - 2019-10-31 22:00:21 --> Router Class Initialized
INFO - 2019-10-31 22:00:21 --> Output Class Initialized
INFO - 2019-10-31 22:00:21 --> Security Class Initialized
DEBUG - 2019-10-31 22:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:00:21 --> CSRF cookie sent
INFO - 2019-10-31 22:00:21 --> Input Class Initialized
INFO - 2019-10-31 22:00:21 --> Language Class Initialized
INFO - 2019-10-31 22:00:21 --> Language Class Initialized
INFO - 2019-10-31 22:00:21 --> Config Class Initialized
INFO - 2019-10-31 22:00:21 --> Loader Class Initialized
INFO - 2019-10-31 22:00:21 --> Helper loaded: url_helper
INFO - 2019-10-31 22:00:21 --> Helper loaded: common_helper
INFO - 2019-10-31 22:00:21 --> Helper loaded: language_helper
INFO - 2019-10-31 22:00:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:00:22 --> Helper loaded: email_helper
INFO - 2019-10-31 22:00:22 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:00:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:00:22 --> Parser Class Initialized
INFO - 2019-10-31 22:00:22 --> User Agent Class Initialized
INFO - 2019-10-31 22:00:22 --> Model Class Initialized
INFO - 2019-10-31 22:00:22 --> Database Driver Class Initialized
INFO - 2019-10-31 22:00:22 --> Model Class Initialized
DEBUG - 2019-10-31 22:00:22 --> Template Class Initialized
INFO - 2019-10-31 22:00:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:00:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:00:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:00:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:00:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:00:22 --> Encryption Class Initialized
INFO - 2019-10-31 22:00:22 --> Controller Class Initialized
DEBUG - 2019-10-31 22:00:22 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:00:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:00:22 --> Model Class Initialized
ERROR - 2019-10-31 22:00:22 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 22:00:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 22:00:22 --> Final output sent to browser
DEBUG - 2019-10-31 22:00:22 --> Total execution time: 0.6020
INFO - 2019-10-31 22:00:43 --> Config Class Initialized
INFO - 2019-10-31 22:00:43 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:00:43 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:00:43 --> Utf8 Class Initialized
INFO - 2019-10-31 22:00:43 --> URI Class Initialized
INFO - 2019-10-31 22:00:43 --> Router Class Initialized
INFO - 2019-10-31 22:00:43 --> Output Class Initialized
INFO - 2019-10-31 22:00:43 --> Security Class Initialized
DEBUG - 2019-10-31 22:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:00:43 --> CSRF cookie sent
INFO - 2019-10-31 22:00:43 --> CSRF token verified
INFO - 2019-10-31 22:00:43 --> Input Class Initialized
INFO - 2019-10-31 22:00:43 --> Language Class Initialized
INFO - 2019-10-31 22:00:43 --> Language Class Initialized
INFO - 2019-10-31 22:00:43 --> Config Class Initialized
INFO - 2019-10-31 22:00:43 --> Loader Class Initialized
INFO - 2019-10-31 22:00:43 --> Helper loaded: url_helper
INFO - 2019-10-31 22:00:43 --> Helper loaded: common_helper
INFO - 2019-10-31 22:00:43 --> Helper loaded: language_helper
INFO - 2019-10-31 22:00:43 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:00:43 --> Helper loaded: email_helper
INFO - 2019-10-31 22:00:43 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:00:43 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:00:43 --> Parser Class Initialized
INFO - 2019-10-31 22:00:43 --> User Agent Class Initialized
INFO - 2019-10-31 22:00:43 --> Model Class Initialized
INFO - 2019-10-31 22:00:43 --> Database Driver Class Initialized
INFO - 2019-10-31 22:00:43 --> Model Class Initialized
DEBUG - 2019-10-31 22:00:43 --> Template Class Initialized
INFO - 2019-10-31 22:00:43 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:00:43 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:00:43 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:00:43 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:00:43 --> Encryption Class Initialized
INFO - 2019-10-31 22:00:43 --> Controller Class Initialized
DEBUG - 2019-10-31 22:00:43 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:00:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:00:43 --> Model Class Initialized
ERROR - 2019-10-31 22:00:43 --> Could not find the language line "Sorting"
INFO - 2019-10-31 22:00:55 --> Config Class Initialized
INFO - 2019-10-31 22:00:55 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:00:55 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:00:55 --> Utf8 Class Initialized
INFO - 2019-10-31 22:00:55 --> URI Class Initialized
INFO - 2019-10-31 22:00:55 --> Router Class Initialized
INFO - 2019-10-31 22:00:55 --> Output Class Initialized
INFO - 2019-10-31 22:00:55 --> Security Class Initialized
DEBUG - 2019-10-31 22:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:00:55 --> CSRF cookie sent
INFO - 2019-10-31 22:00:55 --> CSRF token verified
INFO - 2019-10-31 22:00:55 --> Input Class Initialized
INFO - 2019-10-31 22:00:55 --> Language Class Initialized
INFO - 2019-10-31 22:00:55 --> Language Class Initialized
INFO - 2019-10-31 22:00:55 --> Config Class Initialized
INFO - 2019-10-31 22:00:55 --> Loader Class Initialized
INFO - 2019-10-31 22:00:55 --> Helper loaded: url_helper
INFO - 2019-10-31 22:00:55 --> Helper loaded: common_helper
INFO - 2019-10-31 22:00:55 --> Helper loaded: language_helper
INFO - 2019-10-31 22:00:55 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:00:55 --> Helper loaded: email_helper
INFO - 2019-10-31 22:00:55 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:00:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:00:55 --> Parser Class Initialized
INFO - 2019-10-31 22:00:55 --> User Agent Class Initialized
INFO - 2019-10-31 22:00:55 --> Model Class Initialized
INFO - 2019-10-31 22:00:55 --> Database Driver Class Initialized
INFO - 2019-10-31 22:00:55 --> Model Class Initialized
DEBUG - 2019-10-31 22:00:55 --> Template Class Initialized
INFO - 2019-10-31 22:00:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:00:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:00:55 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:00:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:00:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:00:55 --> Encryption Class Initialized
INFO - 2019-10-31 22:00:55 --> Controller Class Initialized
DEBUG - 2019-10-31 22:00:55 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:00:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:00:55 --> Model Class Initialized
ERROR - 2019-10-31 22:00:55 --> Could not find the language line "Sorting"
INFO - 2019-10-31 22:01:00 --> Config Class Initialized
INFO - 2019-10-31 22:01:00 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:00 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:00 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:00 --> URI Class Initialized
INFO - 2019-10-31 22:01:00 --> Router Class Initialized
INFO - 2019-10-31 22:01:00 --> Output Class Initialized
INFO - 2019-10-31 22:01:00 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:00 --> CSRF cookie sent
INFO - 2019-10-31 22:01:00 --> Input Class Initialized
INFO - 2019-10-31 22:01:00 --> Language Class Initialized
INFO - 2019-10-31 22:01:00 --> Language Class Initialized
INFO - 2019-10-31 22:01:00 --> Config Class Initialized
INFO - 2019-10-31 22:01:00 --> Loader Class Initialized
INFO - 2019-10-31 22:01:00 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:00 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:00 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:00 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:00 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:00 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:00 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:00 --> Parser Class Initialized
INFO - 2019-10-31 22:01:00 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:00 --> Model Class Initialized
INFO - 2019-10-31 22:01:00 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:00 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:00 --> Template Class Initialized
INFO - 2019-10-31 22:01:00 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:01 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:01 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:01 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:01 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:01 --> Model Class Initialized
ERROR - 2019-10-31 22:01:01 --> Could not find the language line "Sorting"
INFO - 2019-10-31 22:01:01 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:01:01 --> Could not find the language line "Delele"
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:01:01 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:01:01 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:01 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:01 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:01:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:01:01 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:01 --> Total execution time: 0.9279
INFO - 2019-10-31 22:01:01 --> Config Class Initialized
INFO - 2019-10-31 22:01:01 --> Config Class Initialized
INFO - 2019-10-31 22:01:01 --> Config Class Initialized
INFO - 2019-10-31 22:01:01 --> Config Class Initialized
INFO - 2019-10-31 22:01:01 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:01 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:01 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:01 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:01 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:01 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:01 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:01 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:01 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:01 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:02 --> URI Class Initialized
INFO - 2019-10-31 22:01:02 --> URI Class Initialized
INFO - 2019-10-31 22:01:02 --> URI Class Initialized
INFO - 2019-10-31 22:01:02 --> URI Class Initialized
INFO - 2019-10-31 22:01:02 --> Router Class Initialized
INFO - 2019-10-31 22:01:02 --> Router Class Initialized
INFO - 2019-10-31 22:01:02 --> Router Class Initialized
INFO - 2019-10-31 22:01:02 --> Router Class Initialized
INFO - 2019-10-31 22:01:02 --> Output Class Initialized
INFO - 2019-10-31 22:01:02 --> Output Class Initialized
INFO - 2019-10-31 22:01:02 --> Output Class Initialized
INFO - 2019-10-31 22:01:02 --> Output Class Initialized
INFO - 2019-10-31 22:01:02 --> Security Class Initialized
INFO - 2019-10-31 22:01:02 --> Security Class Initialized
INFO - 2019-10-31 22:01:02 --> Security Class Initialized
INFO - 2019-10-31 22:01:02 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:02 --> CSRF cookie sent
INFO - 2019-10-31 22:01:02 --> CSRF cookie sent
INFO - 2019-10-31 22:01:02 --> CSRF cookie sent
INFO - 2019-10-31 22:01:02 --> CSRF cookie sent
INFO - 2019-10-31 22:01:02 --> CSRF token verified
INFO - 2019-10-31 22:01:02 --> CSRF token verified
INFO - 2019-10-31 22:01:02 --> CSRF token verified
INFO - 2019-10-31 22:01:02 --> CSRF token verified
INFO - 2019-10-31 22:01:02 --> Input Class Initialized
INFO - 2019-10-31 22:01:02 --> Input Class Initialized
INFO - 2019-10-31 22:01:02 --> Input Class Initialized
INFO - 2019-10-31 22:01:02 --> Input Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Language Class Initialized
INFO - 2019-10-31 22:01:02 --> Config Class Initialized
INFO - 2019-10-31 22:01:02 --> Config Class Initialized
INFO - 2019-10-31 22:01:02 --> Config Class Initialized
INFO - 2019-10-31 22:01:02 --> Config Class Initialized
INFO - 2019-10-31 22:01:02 --> Loader Class Initialized
INFO - 2019-10-31 22:01:02 --> Loader Class Initialized
INFO - 2019-10-31 22:01:02 --> Loader Class Initialized
INFO - 2019-10-31 22:01:02 --> Loader Class Initialized
INFO - 2019-10-31 22:01:02 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:02 --> Parser Class Initialized
INFO - 2019-10-31 22:01:02 --> Parser Class Initialized
INFO - 2019-10-31 22:01:02 --> Parser Class Initialized
INFO - 2019-10-31 22:01:02 --> Parser Class Initialized
INFO - 2019-10-31 22:01:02 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:02 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:02 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:02 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:02 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:02 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:02 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Template Class Initialized
INFO - 2019-10-31 22:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:02 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:02 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:02 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:02 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:02 --> Total execution time: 0.7091
INFO - 2019-10-31 22:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:02 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:02 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:02 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:02 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:02 --> Total execution time: 0.9214
INFO - 2019-10-31 22:01:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:02 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:02 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:02 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:02 --> Model Class Initialized
ERROR - 2019-10-31 22:01:02 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:03 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:03 --> Total execution time: 1.1937
INFO - 2019-10-31 22:01:03 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:03 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:03 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:03 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:03 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:03 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:03 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:03 --> Model Class Initialized
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:03 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:03 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:03 --> Total execution time: 1.4408
INFO - 2019-10-31 22:01:04 --> Config Class Initialized
INFO - 2019-10-31 22:01:04 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:05 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:05 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:05 --> URI Class Initialized
INFO - 2019-10-31 22:01:05 --> Router Class Initialized
INFO - 2019-10-31 22:01:05 --> Output Class Initialized
INFO - 2019-10-31 22:01:05 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:05 --> CSRF cookie sent
INFO - 2019-10-31 22:01:05 --> Input Class Initialized
INFO - 2019-10-31 22:01:05 --> Language Class Initialized
INFO - 2019-10-31 22:01:05 --> Language Class Initialized
INFO - 2019-10-31 22:01:05 --> Config Class Initialized
INFO - 2019-10-31 22:01:05 --> Loader Class Initialized
INFO - 2019-10-31 22:01:05 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:05 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:05 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:05 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:05 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:05 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:05 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:05 --> Parser Class Initialized
INFO - 2019-10-31 22:01:05 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:05 --> Model Class Initialized
INFO - 2019-10-31 22:01:05 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:05 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:05 --> Template Class Initialized
INFO - 2019-10-31 22:01:05 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:05 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:05 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:05 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:05 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:05 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:05 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:05 --> Model Class Initialized
ERROR - 2019-10-31 22:01:05 --> Could not find the language line "Sorting"
DEBUG - 2019-10-31 22:01:05 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/update.php
INFO - 2019-10-31 22:01:05 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:05 --> Total execution time: 0.7129
INFO - 2019-10-31 22:01:13 --> Config Class Initialized
INFO - 2019-10-31 22:01:13 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:13 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:13 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:13 --> URI Class Initialized
INFO - 2019-10-31 22:01:13 --> Router Class Initialized
INFO - 2019-10-31 22:01:13 --> Output Class Initialized
INFO - 2019-10-31 22:01:13 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:13 --> CSRF cookie sent
INFO - 2019-10-31 22:01:13 --> CSRF token verified
INFO - 2019-10-31 22:01:13 --> Input Class Initialized
INFO - 2019-10-31 22:01:13 --> Language Class Initialized
INFO - 2019-10-31 22:01:13 --> Language Class Initialized
INFO - 2019-10-31 22:01:13 --> Config Class Initialized
INFO - 2019-10-31 22:01:13 --> Loader Class Initialized
INFO - 2019-10-31 22:01:13 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:13 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:13 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:13 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:13 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:13 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:13 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:13 --> Parser Class Initialized
INFO - 2019-10-31 22:01:13 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:13 --> Model Class Initialized
INFO - 2019-10-31 22:01:13 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:13 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:13 --> Template Class Initialized
INFO - 2019-10-31 22:01:13 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:13 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:13 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:13 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:13 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:13 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:14 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:14 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:14 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:14 --> Model Class Initialized
ERROR - 2019-10-31 22:01:14 --> Could not find the language line "Sorting"
INFO - 2019-10-31 22:01:18 --> Config Class Initialized
INFO - 2019-10-31 22:01:18 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:18 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:18 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:18 --> URI Class Initialized
INFO - 2019-10-31 22:01:18 --> Router Class Initialized
INFO - 2019-10-31 22:01:18 --> Output Class Initialized
INFO - 2019-10-31 22:01:18 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:18 --> CSRF cookie sent
INFO - 2019-10-31 22:01:18 --> Input Class Initialized
INFO - 2019-10-31 22:01:18 --> Language Class Initialized
INFO - 2019-10-31 22:01:18 --> Language Class Initialized
INFO - 2019-10-31 22:01:18 --> Config Class Initialized
INFO - 2019-10-31 22:01:19 --> Loader Class Initialized
INFO - 2019-10-31 22:01:19 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:19 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:19 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:19 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:19 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:19 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:19 --> Parser Class Initialized
INFO - 2019-10-31 22:01:19 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:19 --> Model Class Initialized
INFO - 2019-10-31 22:01:19 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:19 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:19 --> Template Class Initialized
INFO - 2019-10-31 22:01:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:19 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:19 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:19 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:19 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:19 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:19 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:19 --> Model Class Initialized
ERROR - 2019-10-31 22:01:19 --> Could not find the language line "Sorting"
INFO - 2019-10-31 22:01:19 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:01:19 --> Could not find the language line "Delele"
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/index.php
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:01:19 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:01:19 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:19 --> File already loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:19 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:01:19 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:01:19 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:19 --> Total execution time: 1.0169
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:20 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:20 --> Hooks Class Initialized
INFO - 2019-10-31 22:01:20 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:20 --> UTF-8 Support Enabled
DEBUG - 2019-10-31 22:01:20 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:20 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:20 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:20 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:20 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:20 --> URI Class Initialized
INFO - 2019-10-31 22:01:20 --> URI Class Initialized
INFO - 2019-10-31 22:01:20 --> URI Class Initialized
INFO - 2019-10-31 22:01:20 --> URI Class Initialized
INFO - 2019-10-31 22:01:20 --> Router Class Initialized
INFO - 2019-10-31 22:01:20 --> Router Class Initialized
INFO - 2019-10-31 22:01:20 --> Router Class Initialized
INFO - 2019-10-31 22:01:20 --> Router Class Initialized
INFO - 2019-10-31 22:01:20 --> Output Class Initialized
INFO - 2019-10-31 22:01:20 --> Output Class Initialized
INFO - 2019-10-31 22:01:20 --> Output Class Initialized
INFO - 2019-10-31 22:01:20 --> Output Class Initialized
INFO - 2019-10-31 22:01:20 --> Security Class Initialized
INFO - 2019-10-31 22:01:20 --> Security Class Initialized
INFO - 2019-10-31 22:01:20 --> Security Class Initialized
INFO - 2019-10-31 22:01:20 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:20 --> CSRF cookie sent
INFO - 2019-10-31 22:01:20 --> CSRF cookie sent
INFO - 2019-10-31 22:01:20 --> CSRF cookie sent
INFO - 2019-10-31 22:01:20 --> CSRF cookie sent
INFO - 2019-10-31 22:01:20 --> CSRF token verified
INFO - 2019-10-31 22:01:20 --> CSRF token verified
INFO - 2019-10-31 22:01:20 --> CSRF token verified
INFO - 2019-10-31 22:01:20 --> CSRF token verified
INFO - 2019-10-31 22:01:20 --> Input Class Initialized
INFO - 2019-10-31 22:01:20 --> Input Class Initialized
INFO - 2019-10-31 22:01:20 --> Input Class Initialized
INFO - 2019-10-31 22:01:20 --> Input Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Language Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Config Class Initialized
INFO - 2019-10-31 22:01:20 --> Loader Class Initialized
INFO - 2019-10-31 22:01:20 --> Loader Class Initialized
INFO - 2019-10-31 22:01:20 --> Loader Class Initialized
INFO - 2019-10-31 22:01:20 --> Loader Class Initialized
INFO - 2019-10-31 22:01:20 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:20 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:20 --> Parser Class Initialized
INFO - 2019-10-31 22:01:20 --> Parser Class Initialized
INFO - 2019-10-31 22:01:20 --> Parser Class Initialized
INFO - 2019-10-31 22:01:20 --> Parser Class Initialized
INFO - 2019-10-31 22:01:20 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:20 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:20 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:20 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:20 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:20 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:20 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Template Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Template Class Initialized
INFO - 2019-10-31 22:01:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:20 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:20 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:20 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:20 --> Model Class Initialized
ERROR - 2019-10-31 22:01:20 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:20 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:20 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:20 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:20 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:20 --> Total execution time: 0.7103
INFO - 2019-10-31 22:01:20 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:21 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:21 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:21 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:21 --> Model Class Initialized
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:21 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:21 --> Total execution time: 0.9765
INFO - 2019-10-31 22:01:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:21 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:21 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:21 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:21 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:21 --> Model Class Initialized
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:21 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:21 --> Total execution time: 1.2537
INFO - 2019-10-31 22:01:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:21 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:21 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:21 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:21 --> category MX_Controller Initialized
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:21 --> Model Class Initialized
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "Sorting"
ERROR - 2019-10-31 22:01:21 --> Could not find the language line "View"
DEBUG - 2019-10-31 22:01:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/views/ajax/load_services_by_cate.php
INFO - 2019-10-31 22:01:21 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:21 --> Total execution time: 1.4807
INFO - 2019-10-31 22:01:46 --> Config Class Initialized
INFO - 2019-10-31 22:01:46 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:46 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:46 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:46 --> URI Class Initialized
INFO - 2019-10-31 22:01:46 --> Router Class Initialized
INFO - 2019-10-31 22:01:46 --> Output Class Initialized
INFO - 2019-10-31 22:01:46 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:46 --> CSRF cookie sent
INFO - 2019-10-31 22:01:46 --> Input Class Initialized
INFO - 2019-10-31 22:01:46 --> Language Class Initialized
INFO - 2019-10-31 22:01:46 --> Language Class Initialized
INFO - 2019-10-31 22:01:46 --> Config Class Initialized
INFO - 2019-10-31 22:01:46 --> Loader Class Initialized
INFO - 2019-10-31 22:01:46 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:46 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:46 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:46 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:46 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:46 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:46 --> Parser Class Initialized
INFO - 2019-10-31 22:01:46 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:46 --> Model Class Initialized
INFO - 2019-10-31 22:01:46 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:46 --> Template Class Initialized
INFO - 2019-10-31 22:01:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:46 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:46 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:46 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:46 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:01:46 --> Model Class Initialized
INFO - 2019-10-31 22:01:46 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:01:46 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:01:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:01:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:01:47 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:47 --> Total execution time: 0.9070
INFO - 2019-10-31 22:01:50 --> Config Class Initialized
INFO - 2019-10-31 22:01:50 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:01:50 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:01:50 --> Utf8 Class Initialized
INFO - 2019-10-31 22:01:50 --> URI Class Initialized
INFO - 2019-10-31 22:01:50 --> Router Class Initialized
INFO - 2019-10-31 22:01:50 --> Output Class Initialized
INFO - 2019-10-31 22:01:50 --> Security Class Initialized
DEBUG - 2019-10-31 22:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:01:50 --> CSRF cookie sent
INFO - 2019-10-31 22:01:50 --> Input Class Initialized
INFO - 2019-10-31 22:01:50 --> Language Class Initialized
INFO - 2019-10-31 22:01:50 --> Language Class Initialized
INFO - 2019-10-31 22:01:50 --> Config Class Initialized
INFO - 2019-10-31 22:01:50 --> Loader Class Initialized
INFO - 2019-10-31 22:01:50 --> Helper loaded: url_helper
INFO - 2019-10-31 22:01:50 --> Helper loaded: common_helper
INFO - 2019-10-31 22:01:50 --> Helper loaded: language_helper
INFO - 2019-10-31 22:01:50 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:01:50 --> Helper loaded: email_helper
INFO - 2019-10-31 22:01:50 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:01:50 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:01:50 --> Parser Class Initialized
INFO - 2019-10-31 22:01:50 --> User Agent Class Initialized
INFO - 2019-10-31 22:01:50 --> Model Class Initialized
INFO - 2019-10-31 22:01:50 --> Database Driver Class Initialized
INFO - 2019-10-31 22:01:50 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:50 --> Template Class Initialized
INFO - 2019-10-31 22:01:50 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:01:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:01:50 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:01:50 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:01:50 --> Encryption Class Initialized
INFO - 2019-10-31 22:01:50 --> Controller Class Initialized
DEBUG - 2019-10-31 22:01:50 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:01:50 --> Model Class Initialized
INFO - 2019-10-31 22:01:50 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/other.php
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:01:50 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:01:50 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:01:50 --> Model Class Initialized
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:01:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:01:50 --> Final output sent to browser
DEBUG - 2019-10-31 22:01:51 --> Total execution time: 0.8789
INFO - 2019-10-31 22:09:28 --> Config Class Initialized
INFO - 2019-10-31 22:09:28 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:09:28 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:09:28 --> Utf8 Class Initialized
INFO - 2019-10-31 22:09:28 --> URI Class Initialized
DEBUG - 2019-10-31 22:09:28 --> No URI present. Default controller set.
INFO - 2019-10-31 22:09:28 --> Router Class Initialized
INFO - 2019-10-31 22:09:28 --> Output Class Initialized
INFO - 2019-10-31 22:09:28 --> Security Class Initialized
DEBUG - 2019-10-31 22:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:09:28 --> CSRF cookie sent
INFO - 2019-10-31 22:09:28 --> Input Class Initialized
INFO - 2019-10-31 22:09:28 --> Language Class Initialized
INFO - 2019-10-31 22:09:28 --> Language Class Initialized
INFO - 2019-10-31 22:09:28 --> Config Class Initialized
INFO - 2019-10-31 22:09:28 --> Loader Class Initialized
INFO - 2019-10-31 22:09:28 --> Helper loaded: url_helper
INFO - 2019-10-31 22:09:28 --> Helper loaded: common_helper
INFO - 2019-10-31 22:09:28 --> Helper loaded: language_helper
INFO - 2019-10-31 22:09:28 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:09:28 --> Helper loaded: email_helper
INFO - 2019-10-31 22:09:28 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:09:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:09:28 --> Parser Class Initialized
INFO - 2019-10-31 22:09:29 --> User Agent Class Initialized
INFO - 2019-10-31 22:09:29 --> Model Class Initialized
INFO - 2019-10-31 22:09:29 --> Database Driver Class Initialized
INFO - 2019-10-31 22:09:29 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:29 --> Template Class Initialized
INFO - 2019-10-31 22:09:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:09:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:09:29 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:09:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:09:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:09:29 --> Encryption Class Initialized
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 22:09:29 --> Controller Class Initialized
DEBUG - 2019-10-31 22:09:29 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 22:09:29 --> Model Class Initialized
INFO - 2019-10-31 22:09:29 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 22:09:29 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 22:09:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 22:09:29 --> Final output sent to browser
DEBUG - 2019-10-31 22:09:29 --> Total execution time: 0.9560
INFO - 2019-10-31 22:09:32 --> Config Class Initialized
INFO - 2019-10-31 22:09:32 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:09:32 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:09:32 --> Utf8 Class Initialized
INFO - 2019-10-31 22:09:32 --> URI Class Initialized
INFO - 2019-10-31 22:09:32 --> Router Class Initialized
INFO - 2019-10-31 22:09:32 --> Output Class Initialized
INFO - 2019-10-31 22:09:32 --> Security Class Initialized
DEBUG - 2019-10-31 22:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:09:32 --> CSRF cookie sent
INFO - 2019-10-31 22:09:32 --> Input Class Initialized
INFO - 2019-10-31 22:09:32 --> Language Class Initialized
INFO - 2019-10-31 22:09:32 --> Language Class Initialized
INFO - 2019-10-31 22:09:32 --> Config Class Initialized
INFO - 2019-10-31 22:09:32 --> Loader Class Initialized
INFO - 2019-10-31 22:09:32 --> Helper loaded: url_helper
INFO - 2019-10-31 22:09:32 --> Helper loaded: common_helper
INFO - 2019-10-31 22:09:32 --> Helper loaded: language_helper
INFO - 2019-10-31 22:09:32 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:09:32 --> Helper loaded: email_helper
INFO - 2019-10-31 22:09:32 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:09:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:09:32 --> Parser Class Initialized
INFO - 2019-10-31 22:09:32 --> User Agent Class Initialized
INFO - 2019-10-31 22:09:32 --> Model Class Initialized
INFO - 2019-10-31 22:09:32 --> Database Driver Class Initialized
INFO - 2019-10-31 22:09:32 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:32 --> Template Class Initialized
INFO - 2019-10-31 22:09:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:09:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:09:32 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:09:32 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:09:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:09:32 --> Encryption Class Initialized
INFO - 2019-10-31 22:09:32 --> Controller Class Initialized
DEBUG - 2019-10-31 22:09:32 --> package MX_Controller Initialized
DEBUG - 2019-10-31 22:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-10-31 22:09:32 --> Model Class Initialized
INFO - 2019-10-31 22:09:32 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:09:32 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:09:32 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:09:32 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-10-31 22:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-10-31 22:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:09:33 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:09:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:09:33 --> Final output sent to browser
DEBUG - 2019-10-31 22:09:33 --> Total execution time: 1.3161
INFO - 2019-10-31 22:09:36 --> Config Class Initialized
INFO - 2019-10-31 22:09:36 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:09:36 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:09:36 --> Utf8 Class Initialized
INFO - 2019-10-31 22:09:36 --> URI Class Initialized
INFO - 2019-10-31 22:09:36 --> Router Class Initialized
INFO - 2019-10-31 22:09:36 --> Output Class Initialized
INFO - 2019-10-31 22:09:36 --> Security Class Initialized
DEBUG - 2019-10-31 22:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:09:36 --> CSRF cookie sent
INFO - 2019-10-31 22:09:36 --> CSRF token verified
INFO - 2019-10-31 22:09:36 --> Input Class Initialized
INFO - 2019-10-31 22:09:36 --> Language Class Initialized
INFO - 2019-10-31 22:09:36 --> Language Class Initialized
INFO - 2019-10-31 22:09:36 --> Config Class Initialized
INFO - 2019-10-31 22:09:36 --> Loader Class Initialized
INFO - 2019-10-31 22:09:36 --> Helper loaded: url_helper
INFO - 2019-10-31 22:09:36 --> Helper loaded: common_helper
INFO - 2019-10-31 22:09:36 --> Helper loaded: language_helper
INFO - 2019-10-31 22:09:36 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:09:36 --> Helper loaded: email_helper
INFO - 2019-10-31 22:09:36 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:09:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:09:36 --> Parser Class Initialized
INFO - 2019-10-31 22:09:36 --> User Agent Class Initialized
INFO - 2019-10-31 22:09:36 --> Model Class Initialized
INFO - 2019-10-31 22:09:36 --> Database Driver Class Initialized
INFO - 2019-10-31 22:09:36 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:36 --> Template Class Initialized
INFO - 2019-10-31 22:09:36 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:09:36 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:09:36 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:09:36 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:09:36 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:09:36 --> Encryption Class Initialized
INFO - 2019-10-31 22:09:36 --> Controller Class Initialized
DEBUG - 2019-10-31 22:09:37 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:09:37 --> Model Class Initialized
INFO - 2019-10-31 22:09:37 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:09:37 --> Could not find the language line "Cardinity"
ERROR - 2019-10-31 22:09:37 --> Could not find the language line "coinpayments"
ERROR - 2019-10-31 22:09:37 --> Could not find the language line "freekassa"
ERROR - 2019-10-31 22:09:37 --> Could not find the language line "mollie"
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:09:37 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:09:37 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:09:37 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:09:37 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:09:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:09:37 --> Final output sent to browser
DEBUG - 2019-10-31 22:09:37 --> Total execution time: 1.1282
INFO - 2019-10-31 22:09:52 --> Config Class Initialized
INFO - 2019-10-31 22:09:52 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:09:52 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:09:52 --> Utf8 Class Initialized
INFO - 2019-10-31 22:09:52 --> URI Class Initialized
INFO - 2019-10-31 22:09:52 --> Router Class Initialized
INFO - 2019-10-31 22:09:52 --> Output Class Initialized
INFO - 2019-10-31 22:09:52 --> Security Class Initialized
DEBUG - 2019-10-31 22:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:09:52 --> CSRF cookie sent
INFO - 2019-10-31 22:09:52 --> CSRF token verified
INFO - 2019-10-31 22:09:52 --> Input Class Initialized
INFO - 2019-10-31 22:09:52 --> Language Class Initialized
INFO - 2019-10-31 22:09:52 --> Language Class Initialized
INFO - 2019-10-31 22:09:52 --> Config Class Initialized
INFO - 2019-10-31 22:09:52 --> Loader Class Initialized
INFO - 2019-10-31 22:09:52 --> Helper loaded: url_helper
INFO - 2019-10-31 22:09:52 --> Helper loaded: common_helper
INFO - 2019-10-31 22:09:52 --> Helper loaded: language_helper
INFO - 2019-10-31 22:09:52 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:09:52 --> Helper loaded: email_helper
INFO - 2019-10-31 22:09:52 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:09:52 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:09:52 --> Parser Class Initialized
INFO - 2019-10-31 22:09:52 --> User Agent Class Initialized
INFO - 2019-10-31 22:09:52 --> Model Class Initialized
INFO - 2019-10-31 22:09:52 --> Database Driver Class Initialized
INFO - 2019-10-31 22:09:52 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:52 --> Template Class Initialized
INFO - 2019-10-31 22:09:52 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:09:52 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:09:52 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:09:52 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:09:52 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:09:52 --> Encryption Class Initialized
INFO - 2019-10-31 22:09:52 --> Controller Class Initialized
DEBUG - 2019-10-31 22:09:52 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:09:53 --> Model Class Initialized
INFO - 2019-10-31 22:09:53 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:09:53 --> Could not find the language line "Cardinity"
ERROR - 2019-10-31 22:09:53 --> Could not find the language line "coinpayments"
ERROR - 2019-10-31 22:09:53 --> Could not find the language line "freekassa"
ERROR - 2019-10-31 22:09:53 --> Could not find the language line "mollie"
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:09:53 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:09:53 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:09:53 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:09:53 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:09:53 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:09:53 --> Final output sent to browser
DEBUG - 2019-10-31 22:09:53 --> Total execution time: 0.9086
INFO - 2019-10-31 22:09:57 --> Config Class Initialized
INFO - 2019-10-31 22:09:57 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:09:57 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:09:57 --> Utf8 Class Initialized
INFO - 2019-10-31 22:09:57 --> URI Class Initialized
INFO - 2019-10-31 22:09:57 --> Router Class Initialized
INFO - 2019-10-31 22:09:57 --> Output Class Initialized
INFO - 2019-10-31 22:09:57 --> Security Class Initialized
DEBUG - 2019-10-31 22:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:09:57 --> CSRF cookie sent
INFO - 2019-10-31 22:09:57 --> CSRF token verified
INFO - 2019-10-31 22:09:57 --> Input Class Initialized
INFO - 2019-10-31 22:09:58 --> Language Class Initialized
INFO - 2019-10-31 22:09:58 --> Language Class Initialized
INFO - 2019-10-31 22:09:58 --> Config Class Initialized
INFO - 2019-10-31 22:09:58 --> Loader Class Initialized
INFO - 2019-10-31 22:09:58 --> Helper loaded: url_helper
INFO - 2019-10-31 22:09:58 --> Helper loaded: common_helper
INFO - 2019-10-31 22:09:58 --> Helper loaded: language_helper
INFO - 2019-10-31 22:09:58 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:09:58 --> Helper loaded: email_helper
INFO - 2019-10-31 22:09:58 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:09:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:09:58 --> Parser Class Initialized
INFO - 2019-10-31 22:09:58 --> User Agent Class Initialized
INFO - 2019-10-31 22:09:58 --> Model Class Initialized
INFO - 2019-10-31 22:09:58 --> Database Driver Class Initialized
INFO - 2019-10-31 22:09:58 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:58 --> Template Class Initialized
INFO - 2019-10-31 22:09:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:09:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:09:58 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:09:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:09:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:09:58 --> Encryption Class Initialized
INFO - 2019-10-31 22:09:58 --> Controller Class Initialized
DEBUG - 2019-10-31 22:09:58 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:09:58 --> Model Class Initialized
INFO - 2019-10-31 22:09:58 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:09:58 --> Could not find the language line "Cardinity"
ERROR - 2019-10-31 22:09:58 --> Could not find the language line "coinpayments"
ERROR - 2019-10-31 22:09:58 --> Could not find the language line "freekassa"
ERROR - 2019-10-31 22:09:58 --> Could not find the language line "mollie"
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:09:58 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:09:58 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:09:58 --> Model Class Initialized
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:09:58 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:09:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:09:58 --> Final output sent to browser
DEBUG - 2019-10-31 22:09:58 --> Total execution time: 0.8832
INFO - 2019-10-31 22:10:48 --> Config Class Initialized
INFO - 2019-10-31 22:10:48 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:10:48 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:10:48 --> Utf8 Class Initialized
INFO - 2019-10-31 22:10:48 --> URI Class Initialized
INFO - 2019-10-31 22:10:48 --> Router Class Initialized
INFO - 2019-10-31 22:10:48 --> Output Class Initialized
INFO - 2019-10-31 22:10:48 --> Security Class Initialized
DEBUG - 2019-10-31 22:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:10:48 --> CSRF cookie sent
INFO - 2019-10-31 22:10:48 --> CSRF token verified
INFO - 2019-10-31 22:10:48 --> Input Class Initialized
INFO - 2019-10-31 22:10:48 --> Language Class Initialized
INFO - 2019-10-31 22:10:48 --> Language Class Initialized
INFO - 2019-10-31 22:10:48 --> Config Class Initialized
INFO - 2019-10-31 22:10:48 --> Loader Class Initialized
INFO - 2019-10-31 22:10:48 --> Helper loaded: url_helper
INFO - 2019-10-31 22:10:48 --> Helper loaded: common_helper
INFO - 2019-10-31 22:10:48 --> Helper loaded: language_helper
INFO - 2019-10-31 22:10:48 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:10:48 --> Helper loaded: email_helper
INFO - 2019-10-31 22:10:48 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:10:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:10:48 --> Parser Class Initialized
INFO - 2019-10-31 22:10:48 --> User Agent Class Initialized
INFO - 2019-10-31 22:10:48 --> Model Class Initialized
INFO - 2019-10-31 22:10:48 --> Database Driver Class Initialized
INFO - 2019-10-31 22:10:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:10:48 --> Template Class Initialized
INFO - 2019-10-31 22:10:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:10:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:10:48 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:10:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:10:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:10:48 --> Encryption Class Initialized
INFO - 2019-10-31 22:10:48 --> Controller Class Initialized
DEBUG - 2019-10-31 22:10:48 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:10:48 --> Model Class Initialized
INFO - 2019-10-31 22:10:48 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:10:48 --> Could not find the language line "Cardinity"
ERROR - 2019-10-31 22:10:48 --> Could not find the language line "coinpayments"
ERROR - 2019-10-31 22:10:48 --> Could not find the language line "freekassa"
ERROR - 2019-10-31 22:10:48 --> Could not find the language line "mollie"
DEBUG - 2019-10-31 22:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:10:48 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:10:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:10:49 --> Model Class Initialized
DEBUG - 2019-10-31 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:10:49 --> Model Class Initialized
DEBUG - 2019-10-31 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:10:49 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:10:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:10:49 --> Final output sent to browser
DEBUG - 2019-10-31 22:10:49 --> Total execution time: 0.8967
INFO - 2019-10-31 22:12:22 --> Config Class Initialized
INFO - 2019-10-31 22:12:22 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:12:22 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:12:22 --> Utf8 Class Initialized
INFO - 2019-10-31 22:12:22 --> URI Class Initialized
INFO - 2019-10-31 22:12:22 --> Router Class Initialized
INFO - 2019-10-31 22:12:22 --> Output Class Initialized
INFO - 2019-10-31 22:12:22 --> Security Class Initialized
DEBUG - 2019-10-31 22:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:12:22 --> CSRF cookie sent
INFO - 2019-10-31 22:12:22 --> CSRF token verified
INFO - 2019-10-31 22:12:22 --> Input Class Initialized
INFO - 2019-10-31 22:12:22 --> Language Class Initialized
INFO - 2019-10-31 22:12:22 --> Language Class Initialized
INFO - 2019-10-31 22:12:22 --> Config Class Initialized
INFO - 2019-10-31 22:12:22 --> Loader Class Initialized
INFO - 2019-10-31 22:12:22 --> Helper loaded: url_helper
INFO - 2019-10-31 22:12:22 --> Helper loaded: common_helper
INFO - 2019-10-31 22:12:22 --> Helper loaded: language_helper
INFO - 2019-10-31 22:12:22 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:12:22 --> Helper loaded: email_helper
INFO - 2019-10-31 22:12:22 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:12:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:12:22 --> Parser Class Initialized
INFO - 2019-10-31 22:12:22 --> User Agent Class Initialized
INFO - 2019-10-31 22:12:22 --> Model Class Initialized
INFO - 2019-10-31 22:12:22 --> Database Driver Class Initialized
INFO - 2019-10-31 22:12:22 --> Model Class Initialized
DEBUG - 2019-10-31 22:12:22 --> Template Class Initialized
INFO - 2019-10-31 22:12:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:12:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:12:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:12:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:12:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:12:22 --> Encryption Class Initialized
INFO - 2019-10-31 22:12:22 --> Controller Class Initialized
DEBUG - 2019-10-31 22:12:22 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:12:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:12:22 --> Model Class Initialized
INFO - 2019-10-31 22:12:22 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:12:22 --> Could not find the language line "Cardinity"
ERROR - 2019-10-31 22:12:23 --> Could not find the language line "coinpayments"
ERROR - 2019-10-31 22:12:23 --> Could not find the language line "freekassa"
ERROR - 2019-10-31 22:12:23 --> Could not find the language line "mollie"
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:12:23 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:12:23 --> Model Class Initialized
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:12:23 --> Model Class Initialized
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:12:23 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:12:23 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:12:23 --> Final output sent to browser
DEBUG - 2019-10-31 22:12:23 --> Total execution time: 0.9256
INFO - 2019-10-31 22:16:21 --> Config Class Initialized
INFO - 2019-10-31 22:16:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:16:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:16:21 --> Utf8 Class Initialized
INFO - 2019-10-31 22:16:21 --> URI Class Initialized
INFO - 2019-10-31 22:16:21 --> Router Class Initialized
INFO - 2019-10-31 22:16:21 --> Output Class Initialized
INFO - 2019-10-31 22:16:21 --> Security Class Initialized
DEBUG - 2019-10-31 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:16:21 --> CSRF cookie sent
INFO - 2019-10-31 22:16:21 --> Input Class Initialized
INFO - 2019-10-31 22:16:21 --> Language Class Initialized
INFO - 2019-10-31 22:16:21 --> Language Class Initialized
INFO - 2019-10-31 22:16:21 --> Config Class Initialized
INFO - 2019-10-31 22:16:21 --> Loader Class Initialized
INFO - 2019-10-31 22:16:21 --> Helper loaded: url_helper
INFO - 2019-10-31 22:16:21 --> Helper loaded: common_helper
INFO - 2019-10-31 22:16:21 --> Helper loaded: language_helper
INFO - 2019-10-31 22:16:21 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:16:21 --> Helper loaded: email_helper
INFO - 2019-10-31 22:16:21 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:16:21 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:16:21 --> Parser Class Initialized
INFO - 2019-10-31 22:16:21 --> User Agent Class Initialized
INFO - 2019-10-31 22:16:21 --> Model Class Initialized
INFO - 2019-10-31 22:16:21 --> Database Driver Class Initialized
INFO - 2019-10-31 22:16:21 --> Model Class Initialized
DEBUG - 2019-10-31 22:16:21 --> Template Class Initialized
INFO - 2019-10-31 22:16:21 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:16:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:16:21 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:16:21 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:16:21 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:16:21 --> Encryption Class Initialized
INFO - 2019-10-31 22:16:21 --> Controller Class Initialized
DEBUG - 2019-10-31 22:16:21 --> auth MX_Controller Initialized
DEBUG - 2019-10-31 22:16:21 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/auth/models/auth_model.php
INFO - 2019-10-31 22:16:21 --> Model Class Initialized
INFO - 2019-10-31 22:16:21 --> Config Class Initialized
INFO - 2019-10-31 22:16:21 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:16:21 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:16:21 --> Utf8 Class Initialized
INFO - 2019-10-31 22:16:21 --> URI Class Initialized
INFO - 2019-10-31 22:16:21 --> Router Class Initialized
INFO - 2019-10-31 22:16:21 --> Output Class Initialized
INFO - 2019-10-31 22:16:21 --> Security Class Initialized
DEBUG - 2019-10-31 22:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:16:21 --> CSRF cookie sent
INFO - 2019-10-31 22:16:22 --> Input Class Initialized
INFO - 2019-10-31 22:16:22 --> Language Class Initialized
INFO - 2019-10-31 22:16:22 --> Language Class Initialized
INFO - 2019-10-31 22:16:22 --> Config Class Initialized
INFO - 2019-10-31 22:16:22 --> Loader Class Initialized
INFO - 2019-10-31 22:16:22 --> Helper loaded: url_helper
INFO - 2019-10-31 22:16:22 --> Helper loaded: common_helper
INFO - 2019-10-31 22:16:22 --> Helper loaded: language_helper
INFO - 2019-10-31 22:16:22 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:16:22 --> Helper loaded: email_helper
INFO - 2019-10-31 22:16:22 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:16:22 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:16:22 --> Parser Class Initialized
INFO - 2019-10-31 22:16:22 --> User Agent Class Initialized
INFO - 2019-10-31 22:16:22 --> Model Class Initialized
INFO - 2019-10-31 22:16:22 --> Database Driver Class Initialized
INFO - 2019-10-31 22:16:22 --> Model Class Initialized
DEBUG - 2019-10-31 22:16:22 --> Template Class Initialized
INFO - 2019-10-31 22:16:22 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:16:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:16:22 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:16:22 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:16:22 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:16:22 --> Encryption Class Initialized
INFO - 2019-10-31 22:16:22 --> Controller Class Initialized
DEBUG - 2019-10-31 22:16:22 --> statistics MX_Controller Initialized
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/models/statistics_model.php
INFO - 2019-10-31 22:16:22 --> Model Class Initialized
ERROR - 2019-10-31 22:16:22 --> Could not find the language line "Pending"
ERROR - 2019-10-31 22:16:22 --> Could not find the language line "Pending"
INFO - 2019-10-31 22:16:22 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 22:16:22 --> Could not find the language line "total_orders"
ERROR - 2019-10-31 22:16:22 --> Could not find the language line "total_orders"
ERROR - 2019-10-31 22:16:22 --> Could not find the language line "Pending"
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/statistics/views/index.php
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:16:22 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:16:22 --> Model Class Initialized
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:16:22 --> Model Class Initialized
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:16:22 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:16:22 --> Final output sent to browser
DEBUG - 2019-10-31 22:16:22 --> Total execution time: 1.0038
INFO - 2019-10-31 22:17:56 --> Config Class Initialized
INFO - 2019-10-31 22:17:56 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:17:56 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:17:56 --> Utf8 Class Initialized
INFO - 2019-10-31 22:17:56 --> URI Class Initialized
INFO - 2019-10-31 22:17:56 --> Router Class Initialized
INFO - 2019-10-31 22:17:56 --> Output Class Initialized
INFO - 2019-10-31 22:17:56 --> Security Class Initialized
DEBUG - 2019-10-31 22:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:17:56 --> CSRF cookie sent
INFO - 2019-10-31 22:17:56 --> Input Class Initialized
INFO - 2019-10-31 22:17:56 --> Language Class Initialized
INFO - 2019-10-31 22:17:56 --> Language Class Initialized
INFO - 2019-10-31 22:17:56 --> Config Class Initialized
INFO - 2019-10-31 22:17:56 --> Loader Class Initialized
INFO - 2019-10-31 22:17:56 --> Helper loaded: url_helper
INFO - 2019-10-31 22:17:56 --> Helper loaded: common_helper
INFO - 2019-10-31 22:17:56 --> Helper loaded: language_helper
INFO - 2019-10-31 22:17:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:17:56 --> Helper loaded: email_helper
INFO - 2019-10-31 22:17:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:17:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:17:56 --> Parser Class Initialized
INFO - 2019-10-31 22:17:56 --> User Agent Class Initialized
INFO - 2019-10-31 22:17:56 --> Model Class Initialized
INFO - 2019-10-31 22:17:56 --> Database Driver Class Initialized
INFO - 2019-10-31 22:17:56 --> Model Class Initialized
DEBUG - 2019-10-31 22:17:56 --> Template Class Initialized
INFO - 2019-10-31 22:17:56 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:17:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:17:56 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:17:56 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:17:56 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:17:56 --> Encryption Class Initialized
INFO - 2019-10-31 22:17:56 --> Controller Class Initialized
DEBUG - 2019-10-31 22:17:56 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:17:56 --> Model Class Initialized
INFO - 2019-10-31 22:17:56 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_logo.php
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:17:56 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:17:56 --> Model Class Initialized
DEBUG - 2019-10-31 22:17:56 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:17:57 --> Model Class Initialized
DEBUG - 2019-10-31 22:17:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:17:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:17:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:17:57 --> Final output sent to browser
DEBUG - 2019-10-31 22:17:57 --> Total execution time: 0.8387
INFO - 2019-10-31 22:18:02 --> Config Class Initialized
INFO - 2019-10-31 22:18:02 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:18:02 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:18:02 --> Utf8 Class Initialized
INFO - 2019-10-31 22:18:02 --> URI Class Initialized
INFO - 2019-10-31 22:18:02 --> Router Class Initialized
INFO - 2019-10-31 22:18:02 --> Output Class Initialized
INFO - 2019-10-31 22:18:02 --> Security Class Initialized
DEBUG - 2019-10-31 22:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:18:02 --> CSRF cookie sent
INFO - 2019-10-31 22:18:02 --> CSRF token verified
INFO - 2019-10-31 22:18:02 --> Input Class Initialized
INFO - 2019-10-31 22:18:02 --> Language Class Initialized
INFO - 2019-10-31 22:18:02 --> Language Class Initialized
INFO - 2019-10-31 22:18:02 --> Config Class Initialized
INFO - 2019-10-31 22:18:02 --> Loader Class Initialized
INFO - 2019-10-31 22:18:02 --> Helper loaded: url_helper
INFO - 2019-10-31 22:18:02 --> Helper loaded: common_helper
INFO - 2019-10-31 22:18:02 --> Helper loaded: language_helper
INFO - 2019-10-31 22:18:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:18:02 --> Helper loaded: email_helper
INFO - 2019-10-31 22:18:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:18:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:18:02 --> Parser Class Initialized
INFO - 2019-10-31 22:18:02 --> User Agent Class Initialized
INFO - 2019-10-31 22:18:02 --> Model Class Initialized
INFO - 2019-10-31 22:18:02 --> Database Driver Class Initialized
INFO - 2019-10-31 22:18:02 --> Model Class Initialized
DEBUG - 2019-10-31 22:18:02 --> Template Class Initialized
INFO - 2019-10-31 22:18:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:18:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:18:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:18:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:18:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:18:02 --> Encryption Class Initialized
INFO - 2019-10-31 22:18:02 --> Controller Class Initialized
DEBUG - 2019-10-31 22:18:02 --> file_manager MX_Controller Initialized
DEBUG - 2019-10-31 22:18:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/file_manager/models/file_manager_model.php
INFO - 2019-10-31 22:18:03 --> Model Class Initialized
INFO - 2019-10-31 22:18:03 --> Upload Class Initialized
ERROR - 2019-10-31 22:18:03 --> Could not find the language line "Upload_media_successfully"
INFO - 2019-10-31 22:21:39 --> Config Class Initialized
INFO - 2019-10-31 22:21:39 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:21:39 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:21:39 --> Utf8 Class Initialized
INFO - 2019-10-31 22:21:39 --> URI Class Initialized
INFO - 2019-10-31 22:21:39 --> Router Class Initialized
INFO - 2019-10-31 22:21:39 --> Output Class Initialized
INFO - 2019-10-31 22:21:39 --> Security Class Initialized
DEBUG - 2019-10-31 22:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:21:39 --> CSRF cookie sent
INFO - 2019-10-31 22:21:39 --> Input Class Initialized
INFO - 2019-10-31 22:21:39 --> Language Class Initialized
INFO - 2019-10-31 22:21:39 --> Language Class Initialized
INFO - 2019-10-31 22:21:39 --> Config Class Initialized
INFO - 2019-10-31 22:21:39 --> Loader Class Initialized
INFO - 2019-10-31 22:21:39 --> Helper loaded: url_helper
INFO - 2019-10-31 22:21:39 --> Helper loaded: common_helper
INFO - 2019-10-31 22:21:39 --> Helper loaded: language_helper
INFO - 2019-10-31 22:21:39 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:21:39 --> Helper loaded: email_helper
INFO - 2019-10-31 22:21:39 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:21:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:21:39 --> Parser Class Initialized
INFO - 2019-10-31 22:21:39 --> User Agent Class Initialized
INFO - 2019-10-31 22:21:39 --> Model Class Initialized
INFO - 2019-10-31 22:21:39 --> Database Driver Class Initialized
INFO - 2019-10-31 22:21:39 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:39 --> Template Class Initialized
INFO - 2019-10-31 22:21:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:21:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:21:39 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:21:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:21:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:21:39 --> Encryption Class Initialized
INFO - 2019-10-31 22:21:39 --> Controller Class Initialized
DEBUG - 2019-10-31 22:21:39 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:21:39 --> Model Class Initialized
INFO - 2019-10-31 22:21:39 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_logo.php
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:21:39 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:21:39 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:21:39 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:21:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:21:39 --> Final output sent to browser
DEBUG - 2019-10-31 22:21:40 --> Total execution time: 0.8810
INFO - 2019-10-31 22:21:45 --> Config Class Initialized
INFO - 2019-10-31 22:21:45 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:21:45 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:21:45 --> Utf8 Class Initialized
INFO - 2019-10-31 22:21:45 --> URI Class Initialized
INFO - 2019-10-31 22:21:45 --> Router Class Initialized
INFO - 2019-10-31 22:21:45 --> Output Class Initialized
INFO - 2019-10-31 22:21:45 --> Security Class Initialized
DEBUG - 2019-10-31 22:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:21:45 --> CSRF cookie sent
INFO - 2019-10-31 22:21:45 --> Input Class Initialized
INFO - 2019-10-31 22:21:45 --> Language Class Initialized
INFO - 2019-10-31 22:21:45 --> Language Class Initialized
INFO - 2019-10-31 22:21:45 --> Config Class Initialized
INFO - 2019-10-31 22:21:45 --> Loader Class Initialized
INFO - 2019-10-31 22:21:45 --> Helper loaded: url_helper
INFO - 2019-10-31 22:21:45 --> Helper loaded: common_helper
INFO - 2019-10-31 22:21:45 --> Helper loaded: language_helper
INFO - 2019-10-31 22:21:45 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:21:45 --> Helper loaded: email_helper
INFO - 2019-10-31 22:21:45 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:21:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:21:45 --> Parser Class Initialized
INFO - 2019-10-31 22:21:45 --> User Agent Class Initialized
INFO - 2019-10-31 22:21:45 --> Model Class Initialized
INFO - 2019-10-31 22:21:45 --> Database Driver Class Initialized
INFO - 2019-10-31 22:21:45 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:45 --> Template Class Initialized
INFO - 2019-10-31 22:21:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:21:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:21:45 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:21:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:21:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:21:45 --> Encryption Class Initialized
INFO - 2019-10-31 22:21:45 --> Controller Class Initialized
DEBUG - 2019-10-31 22:21:45 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:21:45 --> Model Class Initialized
INFO - 2019-10-31 22:21:45 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:21:45 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:21:45 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:21:45 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:21:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:21:45 --> Final output sent to browser
DEBUG - 2019-10-31 22:21:45 --> Total execution time: 0.8978
INFO - 2019-10-31 22:21:47 --> Config Class Initialized
INFO - 2019-10-31 22:21:47 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:21:47 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:21:47 --> Utf8 Class Initialized
INFO - 2019-10-31 22:21:47 --> URI Class Initialized
INFO - 2019-10-31 22:21:47 --> Router Class Initialized
INFO - 2019-10-31 22:21:47 --> Output Class Initialized
INFO - 2019-10-31 22:21:47 --> Security Class Initialized
DEBUG - 2019-10-31 22:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:21:47 --> CSRF cookie sent
INFO - 2019-10-31 22:21:47 --> Input Class Initialized
INFO - 2019-10-31 22:21:47 --> Language Class Initialized
INFO - 2019-10-31 22:21:47 --> Language Class Initialized
INFO - 2019-10-31 22:21:47 --> Config Class Initialized
INFO - 2019-10-31 22:21:47 --> Loader Class Initialized
INFO - 2019-10-31 22:21:47 --> Helper loaded: url_helper
INFO - 2019-10-31 22:21:47 --> Helper loaded: common_helper
INFO - 2019-10-31 22:21:47 --> Helper loaded: language_helper
INFO - 2019-10-31 22:21:47 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:21:47 --> Helper loaded: email_helper
INFO - 2019-10-31 22:21:47 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:21:47 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:21:48 --> Parser Class Initialized
INFO - 2019-10-31 22:21:48 --> User Agent Class Initialized
INFO - 2019-10-31 22:21:48 --> Model Class Initialized
INFO - 2019-10-31 22:21:48 --> Database Driver Class Initialized
INFO - 2019-10-31 22:21:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:48 --> Template Class Initialized
INFO - 2019-10-31 22:21:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:21:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:21:48 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:21:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:21:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:21:48 --> Encryption Class Initialized
INFO - 2019-10-31 22:21:48 --> Controller Class Initialized
DEBUG - 2019-10-31 22:21:48 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:21:48 --> Model Class Initialized
INFO - 2019-10-31 22:21:48 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_logo.php
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:21:48 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:21:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:21:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:21:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:21:48 --> Final output sent to browser
DEBUG - 2019-10-31 22:21:48 --> Total execution time: 0.8602
INFO - 2019-10-31 22:29:42 --> Config Class Initialized
INFO - 2019-10-31 22:29:42 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:29:42 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:29:42 --> Utf8 Class Initialized
INFO - 2019-10-31 22:29:42 --> URI Class Initialized
INFO - 2019-10-31 22:29:42 --> Router Class Initialized
INFO - 2019-10-31 22:29:42 --> Output Class Initialized
INFO - 2019-10-31 22:29:42 --> Security Class Initialized
DEBUG - 2019-10-31 22:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:29:42 --> CSRF cookie sent
INFO - 2019-10-31 22:29:42 --> Input Class Initialized
INFO - 2019-10-31 22:29:42 --> Language Class Initialized
INFO - 2019-10-31 22:29:42 --> Language Class Initialized
INFO - 2019-10-31 22:29:42 --> Config Class Initialized
INFO - 2019-10-31 22:29:42 --> Loader Class Initialized
INFO - 2019-10-31 22:29:42 --> Helper loaded: url_helper
INFO - 2019-10-31 22:29:42 --> Helper loaded: common_helper
INFO - 2019-10-31 22:29:42 --> Helper loaded: language_helper
INFO - 2019-10-31 22:29:42 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:29:42 --> Helper loaded: email_helper
INFO - 2019-10-31 22:29:42 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:29:42 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:29:42 --> Parser Class Initialized
INFO - 2019-10-31 22:29:42 --> User Agent Class Initialized
INFO - 2019-10-31 22:29:42 --> Model Class Initialized
INFO - 2019-10-31 22:29:42 --> Database Driver Class Initialized
INFO - 2019-10-31 22:29:42 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:42 --> Template Class Initialized
INFO - 2019-10-31 22:29:42 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:29:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:29:42 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:29:42 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:29:42 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:29:42 --> Encryption Class Initialized
INFO - 2019-10-31 22:29:42 --> Controller Class Initialized
DEBUG - 2019-10-31 22:29:42 --> language MX_Controller Initialized
DEBUG - 2019-10-31 22:29:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 22:29:42 --> Model Class Initialized
INFO - 2019-10-31 22:29:43 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/index.php
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:29:43 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:29:43 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:29:43 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:29:43 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:29:43 --> Final output sent to browser
DEBUG - 2019-10-31 22:29:43 --> Total execution time: 0.9105
INFO - 2019-10-31 22:29:46 --> Config Class Initialized
INFO - 2019-10-31 22:29:46 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:29:46 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:29:46 --> Utf8 Class Initialized
INFO - 2019-10-31 22:29:46 --> URI Class Initialized
INFO - 2019-10-31 22:29:46 --> Router Class Initialized
INFO - 2019-10-31 22:29:46 --> Output Class Initialized
INFO - 2019-10-31 22:29:46 --> Security Class Initialized
DEBUG - 2019-10-31 22:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:29:46 --> CSRF cookie sent
INFO - 2019-10-31 22:29:46 --> Input Class Initialized
INFO - 2019-10-31 22:29:46 --> Language Class Initialized
INFO - 2019-10-31 22:29:46 --> Language Class Initialized
INFO - 2019-10-31 22:29:46 --> Config Class Initialized
INFO - 2019-10-31 22:29:46 --> Loader Class Initialized
INFO - 2019-10-31 22:29:46 --> Helper loaded: url_helper
INFO - 2019-10-31 22:29:46 --> Helper loaded: common_helper
INFO - 2019-10-31 22:29:46 --> Helper loaded: language_helper
INFO - 2019-10-31 22:29:46 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:29:46 --> Helper loaded: email_helper
INFO - 2019-10-31 22:29:46 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:29:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:29:46 --> Parser Class Initialized
INFO - 2019-10-31 22:29:46 --> User Agent Class Initialized
INFO - 2019-10-31 22:29:46 --> Model Class Initialized
INFO - 2019-10-31 22:29:46 --> Database Driver Class Initialized
INFO - 2019-10-31 22:29:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:46 --> Template Class Initialized
INFO - 2019-10-31 22:29:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:29:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:29:46 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:29:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:29:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:29:46 --> Encryption Class Initialized
INFO - 2019-10-31 22:29:46 --> Controller Class Initialized
DEBUG - 2019-10-31 22:29:46 --> language MX_Controller Initialized
DEBUG - 2019-10-31 22:29:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 22:29:46 --> Model Class Initialized
INFO - 2019-10-31 22:29:48 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:29:48 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:29:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:29:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:29:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:29:48 --> Final output sent to browser
DEBUG - 2019-10-31 22:29:48 --> Total execution time: 1.9668
INFO - 2019-10-31 22:35:00 --> Config Class Initialized
INFO - 2019-10-31 22:35:00 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:35:01 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:35:01 --> Utf8 Class Initialized
INFO - 2019-10-31 22:35:01 --> URI Class Initialized
INFO - 2019-10-31 22:35:01 --> Router Class Initialized
INFO - 2019-10-31 22:35:01 --> Output Class Initialized
INFO - 2019-10-31 22:35:01 --> Security Class Initialized
DEBUG - 2019-10-31 22:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:35:01 --> CSRF cookie sent
INFO - 2019-10-31 22:35:01 --> Input Class Initialized
INFO - 2019-10-31 22:35:01 --> Language Class Initialized
INFO - 2019-10-31 22:35:01 --> Language Class Initialized
INFO - 2019-10-31 22:35:01 --> Config Class Initialized
INFO - 2019-10-31 22:35:01 --> Loader Class Initialized
INFO - 2019-10-31 22:35:01 --> Helper loaded: url_helper
INFO - 2019-10-31 22:35:01 --> Helper loaded: common_helper
INFO - 2019-10-31 22:35:01 --> Helper loaded: language_helper
INFO - 2019-10-31 22:35:01 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:35:01 --> Helper loaded: email_helper
INFO - 2019-10-31 22:35:01 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:35:01 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:35:01 --> Parser Class Initialized
INFO - 2019-10-31 22:35:01 --> User Agent Class Initialized
INFO - 2019-10-31 22:35:01 --> Model Class Initialized
INFO - 2019-10-31 22:35:01 --> Database Driver Class Initialized
INFO - 2019-10-31 22:35:01 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:01 --> Template Class Initialized
INFO - 2019-10-31 22:35:01 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:35:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:35:01 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:35:01 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:35:01 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:35:01 --> Encryption Class Initialized
INFO - 2019-10-31 22:35:01 --> Controller Class Initialized
DEBUG - 2019-10-31 22:35:01 --> language MX_Controller Initialized
DEBUG - 2019-10-31 22:35:01 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/models/language_model.php
INFO - 2019-10-31 22:35:01 --> Model Class Initialized
INFO - 2019-10-31 22:35:02 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/language/views/update.php
DEBUG - 2019-10-31 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:35:02 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:35:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:35:02 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:35:03 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:35:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:35:03 --> Final output sent to browser
DEBUG - 2019-10-31 22:35:03 --> Total execution time: 2.1701
INFO - 2019-10-31 22:35:03 --> Config Class Initialized
INFO - 2019-10-31 22:35:03 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:35:03 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:35:03 --> Utf8 Class Initialized
INFO - 2019-10-31 22:35:03 --> URI Class Initialized
INFO - 2019-10-31 22:35:03 --> Router Class Initialized
INFO - 2019-10-31 22:35:03 --> Output Class Initialized
INFO - 2019-10-31 22:35:03 --> Security Class Initialized
DEBUG - 2019-10-31 22:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:35:03 --> CSRF cookie sent
INFO - 2019-10-31 22:35:03 --> Input Class Initialized
INFO - 2019-10-31 22:35:03 --> Language Class Initialized
INFO - 2019-10-31 22:35:03 --> Language Class Initialized
INFO - 2019-10-31 22:35:03 --> Config Class Initialized
INFO - 2019-10-31 22:35:04 --> Loader Class Initialized
INFO - 2019-10-31 22:35:04 --> Helper loaded: url_helper
INFO - 2019-10-31 22:35:04 --> Helper loaded: common_helper
INFO - 2019-10-31 22:35:04 --> Helper loaded: language_helper
INFO - 2019-10-31 22:35:04 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:35:04 --> Helper loaded: email_helper
INFO - 2019-10-31 22:35:04 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:35:04 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:35:04 --> Parser Class Initialized
INFO - 2019-10-31 22:35:04 --> User Agent Class Initialized
INFO - 2019-10-31 22:35:04 --> Model Class Initialized
INFO - 2019-10-31 22:35:04 --> Database Driver Class Initialized
INFO - 2019-10-31 22:35:04 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:04 --> Template Class Initialized
INFO - 2019-10-31 22:35:04 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:35:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:35:04 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:35:04 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:35:04 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:35:04 --> Encryption Class Initialized
INFO - 2019-10-31 22:35:04 --> Controller Class Initialized
DEBUG - 2019-10-31 22:35:04 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:35:04 --> Model Class Initialized
INFO - 2019-10-31 22:35:04 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:35:04 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:35:04 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:35:04 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:35:04 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:35:04 --> Final output sent to browser
DEBUG - 2019-10-31 22:35:04 --> Total execution time: 0.9009
INFO - 2019-10-31 22:35:08 --> Config Class Initialized
INFO - 2019-10-31 22:35:08 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:35:08 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:35:08 --> Utf8 Class Initialized
INFO - 2019-10-31 22:35:08 --> URI Class Initialized
INFO - 2019-10-31 22:35:08 --> Router Class Initialized
INFO - 2019-10-31 22:35:08 --> Output Class Initialized
INFO - 2019-10-31 22:35:08 --> Security Class Initialized
DEBUG - 2019-10-31 22:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:35:08 --> CSRF cookie sent
INFO - 2019-10-31 22:35:08 --> Input Class Initialized
INFO - 2019-10-31 22:35:08 --> Language Class Initialized
INFO - 2019-10-31 22:35:08 --> Language Class Initialized
INFO - 2019-10-31 22:35:08 --> Config Class Initialized
INFO - 2019-10-31 22:35:08 --> Loader Class Initialized
INFO - 2019-10-31 22:35:08 --> Helper loaded: url_helper
INFO - 2019-10-31 22:35:08 --> Helper loaded: common_helper
INFO - 2019-10-31 22:35:08 --> Helper loaded: language_helper
INFO - 2019-10-31 22:35:08 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:35:08 --> Helper loaded: email_helper
INFO - 2019-10-31 22:35:08 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:35:08 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:35:08 --> Parser Class Initialized
INFO - 2019-10-31 22:35:08 --> User Agent Class Initialized
INFO - 2019-10-31 22:35:08 --> Model Class Initialized
INFO - 2019-10-31 22:35:08 --> Database Driver Class Initialized
INFO - 2019-10-31 22:35:08 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:08 --> Template Class Initialized
INFO - 2019-10-31 22:35:08 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:35:08 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:35:08 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:35:08 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:35:08 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:35:08 --> Encryption Class Initialized
INFO - 2019-10-31 22:35:08 --> Controller Class Initialized
DEBUG - 2019-10-31 22:35:08 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:35:08 --> Model Class Initialized
INFO - 2019-10-31 22:35:08 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:35:08 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:35:08 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:35:08 --> Model Class Initialized
DEBUG - 2019-10-31 22:35:08 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:35:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:35:09 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:35:09 --> Final output sent to browser
DEBUG - 2019-10-31 22:35:09 --> Total execution time: 0.9092
INFO - 2019-10-31 22:36:56 --> Config Class Initialized
INFO - 2019-10-31 22:36:56 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:36:56 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:36:56 --> Utf8 Class Initialized
INFO - 2019-10-31 22:36:56 --> URI Class Initialized
INFO - 2019-10-31 22:36:56 --> Router Class Initialized
INFO - 2019-10-31 22:36:56 --> Output Class Initialized
INFO - 2019-10-31 22:36:56 --> Security Class Initialized
DEBUG - 2019-10-31 22:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:36:56 --> CSRF cookie sent
INFO - 2019-10-31 22:36:56 --> Input Class Initialized
INFO - 2019-10-31 22:36:56 --> Language Class Initialized
INFO - 2019-10-31 22:36:56 --> Language Class Initialized
INFO - 2019-10-31 22:36:56 --> Config Class Initialized
INFO - 2019-10-31 22:36:56 --> Loader Class Initialized
INFO - 2019-10-31 22:36:56 --> Helper loaded: url_helper
INFO - 2019-10-31 22:36:56 --> Helper loaded: common_helper
INFO - 2019-10-31 22:36:56 --> Helper loaded: language_helper
INFO - 2019-10-31 22:36:56 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:36:56 --> Helper loaded: email_helper
INFO - 2019-10-31 22:36:56 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:36:56 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:36:56 --> Parser Class Initialized
INFO - 2019-10-31 22:36:56 --> User Agent Class Initialized
INFO - 2019-10-31 22:36:56 --> Model Class Initialized
INFO - 2019-10-31 22:36:56 --> Database Driver Class Initialized
INFO - 2019-10-31 22:36:56 --> Model Class Initialized
DEBUG - 2019-10-31 22:36:57 --> Template Class Initialized
INFO - 2019-10-31 22:36:57 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:36:57 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:36:57 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:36:57 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:36:57 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:36:57 --> Encryption Class Initialized
INFO - 2019-10-31 22:36:57 --> Controller Class Initialized
DEBUG - 2019-10-31 22:36:57 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:36:57 --> Model Class Initialized
INFO - 2019-10-31 22:36:57 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:36:57 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:36:57 --> Model Class Initialized
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:36:57 --> Model Class Initialized
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:36:57 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:36:57 --> Final output sent to browser
DEBUG - 2019-10-31 22:36:57 --> Total execution time: 0.9131
INFO - 2019-10-31 22:38:10 --> Config Class Initialized
INFO - 2019-10-31 22:38:10 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:38:10 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:38:10 --> Utf8 Class Initialized
INFO - 2019-10-31 22:38:10 --> URI Class Initialized
INFO - 2019-10-31 22:38:10 --> Router Class Initialized
INFO - 2019-10-31 22:38:10 --> Output Class Initialized
INFO - 2019-10-31 22:38:10 --> Security Class Initialized
DEBUG - 2019-10-31 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:38:10 --> CSRF cookie sent
INFO - 2019-10-31 22:38:10 --> Input Class Initialized
INFO - 2019-10-31 22:38:10 --> Language Class Initialized
INFO - 2019-10-31 22:38:10 --> Language Class Initialized
INFO - 2019-10-31 22:38:10 --> Config Class Initialized
INFO - 2019-10-31 22:38:10 --> Loader Class Initialized
INFO - 2019-10-31 22:38:10 --> Helper loaded: url_helper
INFO - 2019-10-31 22:38:10 --> Helper loaded: common_helper
INFO - 2019-10-31 22:38:10 --> Helper loaded: language_helper
INFO - 2019-10-31 22:38:10 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:38:10 --> Helper loaded: email_helper
INFO - 2019-10-31 22:38:10 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:38:10 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:38:10 --> Parser Class Initialized
INFO - 2019-10-31 22:38:10 --> User Agent Class Initialized
INFO - 2019-10-31 22:38:10 --> Model Class Initialized
INFO - 2019-10-31 22:38:10 --> Database Driver Class Initialized
INFO - 2019-10-31 22:38:10 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:10 --> Template Class Initialized
INFO - 2019-10-31 22:38:10 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:38:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:38:10 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:38:10 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:38:10 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:38:10 --> Encryption Class Initialized
INFO - 2019-10-31 22:38:10 --> Controller Class Initialized
DEBUG - 2019-10-31 22:38:10 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:38:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:38:10 --> Model Class Initialized
INFO - 2019-10-31 22:38:10 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:38:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:38:10 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:38:11 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:38:11 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:38:11 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:38:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:38:11 --> Final output sent to browser
DEBUG - 2019-10-31 22:38:11 --> Total execution time: 0.9173
INFO - 2019-10-31 22:38:31 --> Config Class Initialized
INFO - 2019-10-31 22:38:31 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:38:31 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:38:31 --> Utf8 Class Initialized
INFO - 2019-10-31 22:38:31 --> URI Class Initialized
INFO - 2019-10-31 22:38:31 --> Router Class Initialized
INFO - 2019-10-31 22:38:31 --> Output Class Initialized
INFO - 2019-10-31 22:38:31 --> Security Class Initialized
DEBUG - 2019-10-31 22:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:38:31 --> CSRF cookie sent
INFO - 2019-10-31 22:38:31 --> Input Class Initialized
INFO - 2019-10-31 22:38:31 --> Language Class Initialized
INFO - 2019-10-31 22:38:31 --> Language Class Initialized
INFO - 2019-10-31 22:38:31 --> Config Class Initialized
INFO - 2019-10-31 22:38:31 --> Loader Class Initialized
INFO - 2019-10-31 22:38:31 --> Helper loaded: url_helper
INFO - 2019-10-31 22:38:31 --> Helper loaded: common_helper
INFO - 2019-10-31 22:38:31 --> Helper loaded: language_helper
INFO - 2019-10-31 22:38:31 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:38:31 --> Helper loaded: email_helper
INFO - 2019-10-31 22:38:31 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:38:31 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:38:31 --> Parser Class Initialized
INFO - 2019-10-31 22:38:31 --> User Agent Class Initialized
INFO - 2019-10-31 22:38:31 --> Model Class Initialized
INFO - 2019-10-31 22:38:31 --> Database Driver Class Initialized
INFO - 2019-10-31 22:38:31 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:31 --> Template Class Initialized
INFO - 2019-10-31 22:38:31 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:38:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:38:31 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:38:31 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:38:32 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:38:32 --> Encryption Class Initialized
INFO - 2019-10-31 22:38:32 --> Controller Class Initialized
DEBUG - 2019-10-31 22:38:32 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:38:32 --> Model Class Initialized
INFO - 2019-10-31 22:38:32 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:38:32 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:38:32 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:38:32 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:38:32 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:38:32 --> Final output sent to browser
DEBUG - 2019-10-31 22:38:32 --> Total execution time: 0.8627
INFO - 2019-10-31 22:38:36 --> Config Class Initialized
INFO - 2019-10-31 22:38:36 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:38:36 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:38:36 --> Utf8 Class Initialized
INFO - 2019-10-31 22:38:36 --> URI Class Initialized
INFO - 2019-10-31 22:38:36 --> Router Class Initialized
INFO - 2019-10-31 22:38:36 --> Output Class Initialized
INFO - 2019-10-31 22:38:36 --> Security Class Initialized
DEBUG - 2019-10-31 22:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:38:36 --> CSRF cookie sent
INFO - 2019-10-31 22:38:36 --> Input Class Initialized
INFO - 2019-10-31 22:38:36 --> Language Class Initialized
INFO - 2019-10-31 22:38:36 --> Language Class Initialized
INFO - 2019-10-31 22:38:36 --> Config Class Initialized
INFO - 2019-10-31 22:38:36 --> Loader Class Initialized
INFO - 2019-10-31 22:38:36 --> Helper loaded: url_helper
INFO - 2019-10-31 22:38:36 --> Helper loaded: common_helper
INFO - 2019-10-31 22:38:36 --> Helper loaded: language_helper
INFO - 2019-10-31 22:38:36 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:38:36 --> Helper loaded: email_helper
INFO - 2019-10-31 22:38:36 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:38:36 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:38:36 --> Parser Class Initialized
INFO - 2019-10-31 22:38:36 --> User Agent Class Initialized
INFO - 2019-10-31 22:38:37 --> Model Class Initialized
INFO - 2019-10-31 22:38:37 --> Database Driver Class Initialized
INFO - 2019-10-31 22:38:37 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:37 --> Template Class Initialized
INFO - 2019-10-31 22:38:37 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:38:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:38:37 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:38:37 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:38:37 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:38:37 --> Encryption Class Initialized
INFO - 2019-10-31 22:38:37 --> Controller Class Initialized
DEBUG - 2019-10-31 22:38:37 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:38:37 --> Model Class Initialized
INFO - 2019-10-31 22:38:37 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
ERROR - 2019-10-31 22:38:37 --> Could not find the language line "coinpayments_integration"
ERROR - 2019-10-31 22:38:37 --> Could not find the language line "coin_acceptance_settings"
ERROR - 2019-10-31 22:38:37 --> Could not find the language line "make_sure_the_list_of_coins_have_the_enabled_status_in"
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinpayments.php
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:38:37 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:38:37 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:38:37 --> Model Class Initialized
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:38:37 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:38:37 --> Final output sent to browser
DEBUG - 2019-10-31 22:38:37 --> Total execution time: 1.0118
INFO - 2019-10-31 22:39:14 --> Config Class Initialized
INFO - 2019-10-31 22:39:14 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:39:14 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:39:14 --> Utf8 Class Initialized
INFO - 2019-10-31 22:39:14 --> URI Class Initialized
INFO - 2019-10-31 22:39:14 --> Router Class Initialized
INFO - 2019-10-31 22:39:14 --> Output Class Initialized
INFO - 2019-10-31 22:39:14 --> Security Class Initialized
DEBUG - 2019-10-31 22:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:39:14 --> CSRF cookie sent
INFO - 2019-10-31 22:39:14 --> Input Class Initialized
INFO - 2019-10-31 22:39:14 --> Language Class Initialized
INFO - 2019-10-31 22:39:14 --> Language Class Initialized
INFO - 2019-10-31 22:39:15 --> Config Class Initialized
INFO - 2019-10-31 22:39:15 --> Loader Class Initialized
INFO - 2019-10-31 22:39:15 --> Helper loaded: url_helper
INFO - 2019-10-31 22:39:15 --> Helper loaded: common_helper
INFO - 2019-10-31 22:39:15 --> Helper loaded: language_helper
INFO - 2019-10-31 22:39:15 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:39:15 --> Helper loaded: email_helper
INFO - 2019-10-31 22:39:15 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:39:15 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:39:15 --> Parser Class Initialized
INFO - 2019-10-31 22:39:15 --> User Agent Class Initialized
INFO - 2019-10-31 22:39:15 --> Model Class Initialized
INFO - 2019-10-31 22:39:15 --> Database Driver Class Initialized
INFO - 2019-10-31 22:39:15 --> Model Class Initialized
DEBUG - 2019-10-31 22:39:15 --> Template Class Initialized
INFO - 2019-10-31 22:39:15 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:39:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:39:15 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:39:15 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:39:15 --> Encryption Class Initialized
INFO - 2019-10-31 22:39:15 --> Controller Class Initialized
DEBUG - 2019-10-31 22:39:15 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:39:15 --> Model Class Initialized
INFO - 2019-10-31 22:39:15 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/integrations/coinbase.php
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:39:15 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:39:15 --> Model Class Initialized
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:39:15 --> Model Class Initialized
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:39:15 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:39:15 --> Final output sent to browser
DEBUG - 2019-10-31 22:39:15 --> Total execution time: 0.8660
INFO - 2019-10-31 22:40:39 --> Config Class Initialized
INFO - 2019-10-31 22:40:39 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:40:39 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:40:39 --> Utf8 Class Initialized
INFO - 2019-10-31 22:40:39 --> URI Class Initialized
INFO - 2019-10-31 22:40:39 --> Router Class Initialized
INFO - 2019-10-31 22:40:39 --> Output Class Initialized
INFO - 2019-10-31 22:40:39 --> Security Class Initialized
DEBUG - 2019-10-31 22:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:40:39 --> CSRF cookie sent
INFO - 2019-10-31 22:40:39 --> CSRF token verified
INFO - 2019-10-31 22:40:39 --> Input Class Initialized
INFO - 2019-10-31 22:40:39 --> Language Class Initialized
INFO - 2019-10-31 22:40:39 --> Language Class Initialized
INFO - 2019-10-31 22:40:39 --> Config Class Initialized
INFO - 2019-10-31 22:40:39 --> Loader Class Initialized
INFO - 2019-10-31 22:40:39 --> Helper loaded: url_helper
INFO - 2019-10-31 22:40:39 --> Helper loaded: common_helper
INFO - 2019-10-31 22:40:39 --> Helper loaded: language_helper
INFO - 2019-10-31 22:40:39 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:40:39 --> Helper loaded: email_helper
INFO - 2019-10-31 22:40:39 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:40:39 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:40:39 --> Parser Class Initialized
INFO - 2019-10-31 22:40:39 --> User Agent Class Initialized
INFO - 2019-10-31 22:40:39 --> Model Class Initialized
INFO - 2019-10-31 22:40:39 --> Database Driver Class Initialized
INFO - 2019-10-31 22:40:39 --> Model Class Initialized
DEBUG - 2019-10-31 22:40:39 --> Template Class Initialized
INFO - 2019-10-31 22:40:39 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:40:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:40:39 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:40:39 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:40:39 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:40:39 --> Encryption Class Initialized
INFO - 2019-10-31 22:40:39 --> Controller Class Initialized
DEBUG - 2019-10-31 22:40:39 --> setting MX_Controller Initialized
DEBUG - 2019-10-31 22:40:39 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:40:39 --> Model Class Initialized
INFO - 2019-10-31 22:40:44 --> Config Class Initialized
INFO - 2019-10-31 22:40:44 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:40:44 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:40:44 --> Utf8 Class Initialized
INFO - 2019-10-31 22:40:44 --> URI Class Initialized
INFO - 2019-10-31 22:40:44 --> Router Class Initialized
INFO - 2019-10-31 22:40:44 --> Output Class Initialized
INFO - 2019-10-31 22:40:44 --> Security Class Initialized
DEBUG - 2019-10-31 22:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:40:44 --> CSRF cookie sent
INFO - 2019-10-31 22:40:44 --> Input Class Initialized
INFO - 2019-10-31 22:40:44 --> Language Class Initialized
INFO - 2019-10-31 22:40:44 --> Language Class Initialized
INFO - 2019-10-31 22:40:44 --> Config Class Initialized
INFO - 2019-10-31 22:40:44 --> Loader Class Initialized
INFO - 2019-10-31 22:40:44 --> Helper loaded: url_helper
INFO - 2019-10-31 22:40:44 --> Helper loaded: common_helper
INFO - 2019-10-31 22:40:44 --> Helper loaded: language_helper
INFO - 2019-10-31 22:40:44 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:40:44 --> Helper loaded: email_helper
INFO - 2019-10-31 22:40:44 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:40:45 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:40:45 --> Parser Class Initialized
INFO - 2019-10-31 22:40:45 --> User Agent Class Initialized
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Database Driver Class Initialized
INFO - 2019-10-31 22:40:45 --> Config Class Initialized
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Template Class Initialized
DEBUG - 2019-10-31 22:40:45 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:40:45 --> Utf8 Class Initialized
INFO - 2019-10-31 22:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:40:45 --> Pagination Class Initialized
INFO - 2019-10-31 22:40:45 --> URI Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:40:45 --> Router Class Initialized
INFO - 2019-10-31 22:40:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:40:45 --> Output Class Initialized
INFO - 2019-10-31 22:40:45 --> Encryption Class Initialized
INFO - 2019-10-31 22:40:45 --> Security Class Initialized
INFO - 2019-10-31 22:40:45 --> Controller Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-10-31 22:40:45 --> setting MX_Controller Initialized
INFO - 2019-10-31 22:40:45 --> CSRF cookie sent
INFO - 2019-10-31 22:40:45 --> CSRF token verified
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/models/setting_model.php
INFO - 2019-10-31 22:40:45 --> Input Class Initialized
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Language Class Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: inflector_helper
INFO - 2019-10-31 22:40:45 --> Language Class Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/sidebar.php
INFO - 2019-10-31 22:40:45 --> Config Class Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/website_setting.php
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/setting/views/index.php
INFO - 2019-10-31 22:40:45 --> Loader Class Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: url_helper
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:40:45 --> blocks MX_Controller Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: common_helper
INFO - 2019-10-31 22:40:45 --> Helper loaded: language_helper
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: cookie_helper
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:40:45 --> Helper loaded: email_helper
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:40:45 --> Language file loaded: language/english/common_lang.php
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
INFO - 2019-10-31 22:40:45 --> Parser Class Initialized
INFO - 2019-10-31 22:40:45 --> User Agent Class Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Final output sent to browser
INFO - 2019-10-31 22:40:45 --> Database Driver Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Total execution time: 0.9485
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Template Class Initialized
INFO - 2019-10-31 22:40:45 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:40:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:40:45 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:40:45 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:40:45 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:40:45 --> Encryption Class Initialized
INFO - 2019-10-31 22:40:45 --> Controller Class Initialized
DEBUG - 2019-10-31 22:40:45 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
INFO - 2019-10-31 22:40:45 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:40:45 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:40:45 --> Model Class Initialized
DEBUG - 2019-10-31 22:40:45 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:40:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:40:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:40:46 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:40:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:40:46 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:40:46 --> Final output sent to browser
DEBUG - 2019-10-31 22:40:46 --> Total execution time: 1.0159
INFO - 2019-10-31 22:40:47 --> Config Class Initialized
INFO - 2019-10-31 22:40:47 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:40:47 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:40:47 --> Utf8 Class Initialized
INFO - 2019-10-31 22:40:47 --> URI Class Initialized
INFO - 2019-10-31 22:40:47 --> Router Class Initialized
INFO - 2019-10-31 22:40:47 --> Output Class Initialized
INFO - 2019-10-31 22:40:47 --> Security Class Initialized
DEBUG - 2019-10-31 22:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:40:47 --> CSRF cookie sent
INFO - 2019-10-31 22:40:47 --> Input Class Initialized
INFO - 2019-10-31 22:40:48 --> Language Class Initialized
INFO - 2019-10-31 22:40:48 --> Language Class Initialized
INFO - 2019-10-31 22:40:48 --> Config Class Initialized
INFO - 2019-10-31 22:40:48 --> Loader Class Initialized
INFO - 2019-10-31 22:40:48 --> Helper loaded: url_helper
INFO - 2019-10-31 22:40:48 --> Helper loaded: common_helper
INFO - 2019-10-31 22:40:48 --> Helper loaded: language_helper
INFO - 2019-10-31 22:40:48 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:40:48 --> Helper loaded: email_helper
INFO - 2019-10-31 22:40:48 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:40:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:40:48 --> Parser Class Initialized
INFO - 2019-10-31 22:40:48 --> User Agent Class Initialized
INFO - 2019-10-31 22:40:48 --> Model Class Initialized
INFO - 2019-10-31 22:40:48 --> Database Driver Class Initialized
INFO - 2019-10-31 22:40:48 --> Model Class Initialized
DEBUG - 2019-10-31 22:40:48 --> Template Class Initialized
INFO - 2019-10-31 22:40:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:40:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:40:48 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:40:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:40:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:40:48 --> Encryption Class Initialized
INFO - 2019-10-31 22:40:48 --> Controller Class Initialized
DEBUG - 2019-10-31 22:40:48 --> custom_page MX_Controller Initialized
DEBUG - 2019-10-31 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/models/custom_page_model.php
INFO - 2019-10-31 22:40:48 --> Model Class Initialized
INFO - 2019-10-31 22:40:48 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/custom_page/views/404.php
DEBUG - 2019-10-31 22:40:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/404.php
INFO - 2019-10-31 22:40:48 --> Final output sent to browser
DEBUG - 2019-10-31 22:40:48 --> Total execution time: 0.7410
INFO - 2019-10-31 22:50:46 --> Config Class Initialized
INFO - 2019-10-31 22:50:46 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:50:46 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:50:46 --> Utf8 Class Initialized
INFO - 2019-10-31 22:50:46 --> URI Class Initialized
INFO - 2019-10-31 22:50:46 --> Router Class Initialized
INFO - 2019-10-31 22:50:46 --> Output Class Initialized
INFO - 2019-10-31 22:50:46 --> Security Class Initialized
DEBUG - 2019-10-31 22:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:50:46 --> CSRF cookie sent
INFO - 2019-10-31 22:50:46 --> CSRF token verified
INFO - 2019-10-31 22:50:46 --> Input Class Initialized
INFO - 2019-10-31 22:50:46 --> Language Class Initialized
INFO - 2019-10-31 22:50:46 --> Language Class Initialized
INFO - 2019-10-31 22:50:46 --> Config Class Initialized
INFO - 2019-10-31 22:50:46 --> Loader Class Initialized
INFO - 2019-10-31 22:50:46 --> Helper loaded: url_helper
INFO - 2019-10-31 22:50:46 --> Helper loaded: common_helper
INFO - 2019-10-31 22:50:46 --> Helper loaded: language_helper
INFO - 2019-10-31 22:50:46 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:50:46 --> Helper loaded: email_helper
INFO - 2019-10-31 22:50:46 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:50:46 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:50:46 --> Parser Class Initialized
INFO - 2019-10-31 22:50:46 --> User Agent Class Initialized
INFO - 2019-10-31 22:50:46 --> Model Class Initialized
INFO - 2019-10-31 22:50:46 --> Database Driver Class Initialized
INFO - 2019-10-31 22:50:46 --> Model Class Initialized
DEBUG - 2019-10-31 22:50:46 --> Template Class Initialized
INFO - 2019-10-31 22:50:46 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:50:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:50:46 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:50:46 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:50:46 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:50:46 --> Encryption Class Initialized
INFO - 2019-10-31 22:50:46 --> Controller Class Initialized
DEBUG - 2019-10-31 22:50:46 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:50:47 --> Model Class Initialized
INFO - 2019-10-31 22:50:47 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:50:47 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:50:47 --> Model Class Initialized
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:50:47 --> Model Class Initialized
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:50:47 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:50:47 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:50:47 --> Final output sent to browser
DEBUG - 2019-10-31 22:50:47 --> Total execution time: 1.1592
INFO - 2019-10-31 22:55:37 --> Config Class Initialized
INFO - 2019-10-31 22:55:37 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:55:37 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:55:38 --> Utf8 Class Initialized
INFO - 2019-10-31 22:55:38 --> URI Class Initialized
INFO - 2019-10-31 22:55:38 --> Router Class Initialized
INFO - 2019-10-31 22:55:38 --> Output Class Initialized
INFO - 2019-10-31 22:55:38 --> Security Class Initialized
DEBUG - 2019-10-31 22:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:55:38 --> CSRF cookie sent
INFO - 2019-10-31 22:55:38 --> CSRF token verified
INFO - 2019-10-31 22:55:38 --> Input Class Initialized
INFO - 2019-10-31 22:55:38 --> Language Class Initialized
INFO - 2019-10-31 22:55:38 --> Language Class Initialized
INFO - 2019-10-31 22:55:38 --> Config Class Initialized
INFO - 2019-10-31 22:55:38 --> Loader Class Initialized
INFO - 2019-10-31 22:55:38 --> Helper loaded: url_helper
INFO - 2019-10-31 22:55:38 --> Helper loaded: common_helper
INFO - 2019-10-31 22:55:38 --> Helper loaded: language_helper
INFO - 2019-10-31 22:55:38 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:55:38 --> Helper loaded: email_helper
INFO - 2019-10-31 22:55:38 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:55:38 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:55:38 --> Parser Class Initialized
INFO - 2019-10-31 22:55:38 --> User Agent Class Initialized
INFO - 2019-10-31 22:55:38 --> Model Class Initialized
INFO - 2019-10-31 22:55:38 --> Database Driver Class Initialized
INFO - 2019-10-31 22:55:38 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:38 --> Template Class Initialized
INFO - 2019-10-31 22:55:38 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:55:38 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:55:38 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:55:38 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:55:38 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:55:38 --> Encryption Class Initialized
INFO - 2019-10-31 22:55:38 --> Controller Class Initialized
DEBUG - 2019-10-31 22:55:38 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:55:38 --> Model Class Initialized
INFO - 2019-10-31 22:55:38 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:55:38 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:55:38 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:55:38 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:55:38 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:55:38 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:55:38 --> Final output sent to browser
DEBUG - 2019-10-31 22:55:38 --> Total execution time: 0.9823
INFO - 2019-10-31 22:55:40 --> Config Class Initialized
INFO - 2019-10-31 22:55:40 --> Hooks Class Initialized
DEBUG - 2019-10-31 22:55:40 --> UTF-8 Support Enabled
INFO - 2019-10-31 22:55:40 --> Utf8 Class Initialized
INFO - 2019-10-31 22:55:40 --> URI Class Initialized
INFO - 2019-10-31 22:55:40 --> Router Class Initialized
INFO - 2019-10-31 22:55:40 --> Output Class Initialized
INFO - 2019-10-31 22:55:40 --> Security Class Initialized
DEBUG - 2019-10-31 22:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 22:55:40 --> CSRF cookie sent
INFO - 2019-10-31 22:55:40 --> CSRF token verified
INFO - 2019-10-31 22:55:40 --> Input Class Initialized
INFO - 2019-10-31 22:55:40 --> Language Class Initialized
INFO - 2019-10-31 22:55:40 --> Language Class Initialized
INFO - 2019-10-31 22:55:40 --> Config Class Initialized
INFO - 2019-10-31 22:55:40 --> Loader Class Initialized
INFO - 2019-10-31 22:55:41 --> Helper loaded: url_helper
INFO - 2019-10-31 22:55:41 --> Helper loaded: common_helper
INFO - 2019-10-31 22:55:41 --> Helper loaded: language_helper
INFO - 2019-10-31 22:55:41 --> Helper loaded: cookie_helper
INFO - 2019-10-31 22:55:41 --> Helper loaded: email_helper
INFO - 2019-10-31 22:55:41 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 22:55:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 22:55:41 --> Parser Class Initialized
INFO - 2019-10-31 22:55:41 --> User Agent Class Initialized
INFO - 2019-10-31 22:55:41 --> Model Class Initialized
INFO - 2019-10-31 22:55:41 --> Database Driver Class Initialized
INFO - 2019-10-31 22:55:41 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:41 --> Template Class Initialized
INFO - 2019-10-31 22:55:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 22:55:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 22:55:41 --> Pagination Class Initialized
DEBUG - 2019-10-31 22:55:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 22:55:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 22:55:41 --> Encryption Class Initialized
INFO - 2019-10-31 22:55:41 --> Controller Class Initialized
DEBUG - 2019-10-31 22:55:41 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 22:55:41 --> Model Class Initialized
INFO - 2019-10-31 22:55:41 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 22:55:41 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 22:55:41 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 22:55:41 --> Model Class Initialized
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 22:55:41 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 22:55:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 22:55:41 --> Final output sent to browser
DEBUG - 2019-10-31 22:55:41 --> Total execution time: 0.9771
INFO - 2019-10-31 23:15:40 --> Config Class Initialized
INFO - 2019-10-31 23:15:40 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:15:40 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:15:40 --> Utf8 Class Initialized
INFO - 2019-10-31 23:15:40 --> URI Class Initialized
INFO - 2019-10-31 23:15:40 --> Router Class Initialized
INFO - 2019-10-31 23:15:40 --> Output Class Initialized
INFO - 2019-10-31 23:15:40 --> Security Class Initialized
DEBUG - 2019-10-31 23:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:15:40 --> CSRF cookie sent
INFO - 2019-10-31 23:15:40 --> CSRF token verified
INFO - 2019-10-31 23:15:40 --> Input Class Initialized
INFO - 2019-10-31 23:15:40 --> Language Class Initialized
INFO - 2019-10-31 23:15:40 --> Language Class Initialized
INFO - 2019-10-31 23:15:40 --> Config Class Initialized
INFO - 2019-10-31 23:15:40 --> Loader Class Initialized
INFO - 2019-10-31 23:15:40 --> Helper loaded: url_helper
INFO - 2019-10-31 23:15:40 --> Helper loaded: common_helper
INFO - 2019-10-31 23:15:40 --> Helper loaded: language_helper
INFO - 2019-10-31 23:15:40 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:15:40 --> Helper loaded: email_helper
INFO - 2019-10-31 23:15:40 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:15:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:15:40 --> Parser Class Initialized
INFO - 2019-10-31 23:15:40 --> User Agent Class Initialized
INFO - 2019-10-31 23:15:40 --> Model Class Initialized
INFO - 2019-10-31 23:15:40 --> Database Driver Class Initialized
INFO - 2019-10-31 23:15:40 --> Model Class Initialized
DEBUG - 2019-10-31 23:15:40 --> Template Class Initialized
INFO - 2019-10-31 23:15:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:15:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:15:40 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:15:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:15:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:15:40 --> Encryption Class Initialized
INFO - 2019-10-31 23:15:41 --> Controller Class Initialized
DEBUG - 2019-10-31 23:15:41 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:15:41 --> Model Class Initialized
INFO - 2019-10-31 23:15:41 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:15:41 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:15:41 --> Model Class Initialized
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:15:41 --> Model Class Initialized
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 23:15:41 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 23:15:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 23:15:41 --> Final output sent to browser
DEBUG - 2019-10-31 23:15:41 --> Total execution time: 1.0226
INFO - 2019-10-31 23:15:54 --> Config Class Initialized
INFO - 2019-10-31 23:15:55 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:15:55 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:15:55 --> Utf8 Class Initialized
INFO - 2019-10-31 23:15:55 --> URI Class Initialized
INFO - 2019-10-31 23:15:55 --> Router Class Initialized
INFO - 2019-10-31 23:15:55 --> Output Class Initialized
INFO - 2019-10-31 23:15:55 --> Security Class Initialized
DEBUG - 2019-10-31 23:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:15:55 --> CSRF cookie sent
INFO - 2019-10-31 23:15:55 --> CSRF token verified
INFO - 2019-10-31 23:15:55 --> Input Class Initialized
INFO - 2019-10-31 23:15:55 --> Language Class Initialized
INFO - 2019-10-31 23:15:55 --> Language Class Initialized
INFO - 2019-10-31 23:15:55 --> Config Class Initialized
INFO - 2019-10-31 23:15:55 --> Loader Class Initialized
INFO - 2019-10-31 23:15:55 --> Helper loaded: url_helper
INFO - 2019-10-31 23:15:55 --> Helper loaded: common_helper
INFO - 2019-10-31 23:15:55 --> Helper loaded: language_helper
INFO - 2019-10-31 23:15:55 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:15:55 --> Helper loaded: email_helper
INFO - 2019-10-31 23:15:55 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:15:55 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:15:55 --> Parser Class Initialized
INFO - 2019-10-31 23:15:55 --> User Agent Class Initialized
INFO - 2019-10-31 23:15:55 --> Model Class Initialized
INFO - 2019-10-31 23:15:55 --> Database Driver Class Initialized
INFO - 2019-10-31 23:15:55 --> Model Class Initialized
DEBUG - 2019-10-31 23:15:55 --> Template Class Initialized
INFO - 2019-10-31 23:15:55 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:15:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:15:55 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:15:55 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:15:55 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:15:55 --> Encryption Class Initialized
INFO - 2019-10-31 23:15:55 --> Controller Class Initialized
DEBUG - 2019-10-31 23:15:55 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:15:55 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:15:55 --> Model Class Initialized
INFO - 2019-10-31 23:17:19 --> Config Class Initialized
INFO - 2019-10-31 23:17:19 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:17:19 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:17:19 --> Utf8 Class Initialized
INFO - 2019-10-31 23:17:19 --> URI Class Initialized
INFO - 2019-10-31 23:17:19 --> Router Class Initialized
INFO - 2019-10-31 23:17:19 --> Output Class Initialized
INFO - 2019-10-31 23:17:19 --> Security Class Initialized
DEBUG - 2019-10-31 23:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:17:19 --> CSRF cookie sent
INFO - 2019-10-31 23:17:19 --> CSRF token verified
INFO - 2019-10-31 23:17:19 --> Input Class Initialized
INFO - 2019-10-31 23:17:19 --> Language Class Initialized
INFO - 2019-10-31 23:17:19 --> Language Class Initialized
INFO - 2019-10-31 23:17:19 --> Config Class Initialized
INFO - 2019-10-31 23:17:19 --> Loader Class Initialized
INFO - 2019-10-31 23:17:19 --> Helper loaded: url_helper
INFO - 2019-10-31 23:17:19 --> Helper loaded: common_helper
INFO - 2019-10-31 23:17:19 --> Helper loaded: language_helper
INFO - 2019-10-31 23:17:19 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:17:19 --> Helper loaded: email_helper
INFO - 2019-10-31 23:17:19 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:17:19 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:17:19 --> Parser Class Initialized
INFO - 2019-10-31 23:17:19 --> User Agent Class Initialized
INFO - 2019-10-31 23:17:19 --> Model Class Initialized
INFO - 2019-10-31 23:17:19 --> Database Driver Class Initialized
INFO - 2019-10-31 23:17:19 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:19 --> Template Class Initialized
INFO - 2019-10-31 23:17:19 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:17:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:17:20 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:17:20 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:17:20 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:17:20 --> Encryption Class Initialized
INFO - 2019-10-31 23:17:20 --> Controller Class Initialized
DEBUG - 2019-10-31 23:17:20 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:17:20 --> Model Class Initialized
INFO - 2019-10-31 23:17:20 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:17:20 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:17:20 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:17:20 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 23:17:20 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 23:17:20 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 23:17:20 --> Final output sent to browser
DEBUG - 2019-10-31 23:17:20 --> Total execution time: 1.0188
INFO - 2019-10-31 23:17:28 --> Config Class Initialized
INFO - 2019-10-31 23:17:28 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:17:28 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:17:28 --> Utf8 Class Initialized
INFO - 2019-10-31 23:17:28 --> URI Class Initialized
INFO - 2019-10-31 23:17:28 --> Router Class Initialized
INFO - 2019-10-31 23:17:28 --> Output Class Initialized
INFO - 2019-10-31 23:17:28 --> Security Class Initialized
DEBUG - 2019-10-31 23:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:17:28 --> CSRF cookie sent
INFO - 2019-10-31 23:17:28 --> CSRF token verified
INFO - 2019-10-31 23:17:28 --> Input Class Initialized
INFO - 2019-10-31 23:17:28 --> Language Class Initialized
INFO - 2019-10-31 23:17:28 --> Language Class Initialized
INFO - 2019-10-31 23:17:28 --> Config Class Initialized
INFO - 2019-10-31 23:17:28 --> Loader Class Initialized
INFO - 2019-10-31 23:17:28 --> Helper loaded: url_helper
INFO - 2019-10-31 23:17:28 --> Helper loaded: common_helper
INFO - 2019-10-31 23:17:28 --> Helper loaded: language_helper
INFO - 2019-10-31 23:17:28 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:17:28 --> Helper loaded: email_helper
INFO - 2019-10-31 23:17:28 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:17:28 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:17:28 --> Parser Class Initialized
INFO - 2019-10-31 23:17:28 --> User Agent Class Initialized
INFO - 2019-10-31 23:17:28 --> Model Class Initialized
INFO - 2019-10-31 23:17:28 --> Database Driver Class Initialized
INFO - 2019-10-31 23:17:28 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:28 --> Template Class Initialized
INFO - 2019-10-31 23:17:28 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:17:29 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:17:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:17:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:17:29 --> Encryption Class Initialized
INFO - 2019-10-31 23:17:29 --> Controller Class Initialized
DEBUG - 2019-10-31 23:17:29 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:17:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:17:29 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:29 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-10-31 23:17:29 --> Final output sent to browser
DEBUG - 2019-10-31 23:17:29 --> Total execution time: 0.7296
INFO - 2019-10-31 23:17:29 --> Config Class Initialized
INFO - 2019-10-31 23:17:29 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:17:29 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:17:29 --> Utf8 Class Initialized
INFO - 2019-10-31 23:17:29 --> URI Class Initialized
INFO - 2019-10-31 23:17:29 --> Router Class Initialized
INFO - 2019-10-31 23:17:29 --> Output Class Initialized
INFO - 2019-10-31 23:17:29 --> Security Class Initialized
DEBUG - 2019-10-31 23:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:17:29 --> Input Class Initialized
INFO - 2019-10-31 23:17:29 --> Language Class Initialized
INFO - 2019-10-31 23:17:29 --> Language Class Initialized
INFO - 2019-10-31 23:17:29 --> Config Class Initialized
INFO - 2019-10-31 23:17:29 --> Loader Class Initialized
INFO - 2019-10-31 23:17:29 --> Helper loaded: url_helper
INFO - 2019-10-31 23:17:29 --> Helper loaded: common_helper
INFO - 2019-10-31 23:17:29 --> Helper loaded: language_helper
INFO - 2019-10-31 23:17:29 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:17:29 --> Helper loaded: email_helper
INFO - 2019-10-31 23:17:29 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:17:29 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:17:29 --> Parser Class Initialized
INFO - 2019-10-31 23:17:29 --> User Agent Class Initialized
INFO - 2019-10-31 23:17:29 --> Model Class Initialized
INFO - 2019-10-31 23:17:29 --> Database Driver Class Initialized
INFO - 2019-10-31 23:17:29 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:29 --> Template Class Initialized
INFO - 2019-10-31 23:17:29 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:17:29 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:17:29 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:17:29 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:17:29 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:17:29 --> Encryption Class Initialized
INFO - 2019-10-31 23:17:29 --> Controller Class Initialized
DEBUG - 2019-10-31 23:17:29 --> coinbase MX_Controller Initialized
DEBUG - 2019-10-31 23:17:30 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
INFO - 2019-10-31 23:17:30 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:32 --> orders MX_Controller Initialized
ERROR - 2019-10-31 23:17:32 --> Severity: Notice --> Undefined property: stdClass::$data D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules\checkout\controllers\coinbase.php 81
INFO - 2019-10-31 23:17:32 --> Config Class Initialized
INFO - 2019-10-31 23:17:32 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:17:32 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:17:32 --> Utf8 Class Initialized
INFO - 2019-10-31 23:17:32 --> URI Class Initialized
DEBUG - 2019-10-31 23:17:32 --> No URI present. Default controller set.
INFO - 2019-10-31 23:17:32 --> Router Class Initialized
INFO - 2019-10-31 23:17:32 --> Output Class Initialized
INFO - 2019-10-31 23:17:32 --> Security Class Initialized
DEBUG - 2019-10-31 23:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:17:32 --> CSRF cookie sent
INFO - 2019-10-31 23:17:32 --> Input Class Initialized
INFO - 2019-10-31 23:17:32 --> Language Class Initialized
INFO - 2019-10-31 23:17:32 --> Language Class Initialized
INFO - 2019-10-31 23:17:32 --> Config Class Initialized
INFO - 2019-10-31 23:17:32 --> Loader Class Initialized
INFO - 2019-10-31 23:17:32 --> Helper loaded: url_helper
INFO - 2019-10-31 23:17:32 --> Helper loaded: common_helper
INFO - 2019-10-31 23:17:32 --> Helper loaded: language_helper
INFO - 2019-10-31 23:17:32 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:17:32 --> Helper loaded: email_helper
INFO - 2019-10-31 23:17:32 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:17:32 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:17:32 --> Parser Class Initialized
INFO - 2019-10-31 23:17:32 --> User Agent Class Initialized
INFO - 2019-10-31 23:17:32 --> Model Class Initialized
INFO - 2019-10-31 23:17:32 --> Database Driver Class Initialized
INFO - 2019-10-31 23:17:32 --> Model Class Initialized
DEBUG - 2019-10-31 23:17:32 --> Template Class Initialized
INFO - 2019-10-31 23:17:32 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:17:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:17:32 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:17:33 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:17:33 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:17:33 --> Encryption Class Initialized
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/language/english/regular_lang.php
INFO - 2019-10-31 23:17:33 --> Controller Class Initialized
DEBUG - 2019-10-31 23:17:33 --> regular MX_Controller Initialized
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/config/autoload.php
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/models/regular_model.php
INFO - 2019-10-31 23:17:33 --> Model Class Initialized
INFO - 2019-10-31 23:17:33 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/header.php
ERROR - 2019-10-31 23:17:33 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/blocks/footer.php
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\themes/regular/views/index.php
DEBUG - 2019-10-31 23:17:33 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/blank_page.php
INFO - 2019-10-31 23:17:33 --> Final output sent to browser
DEBUG - 2019-10-31 23:17:33 --> Total execution time: 0.9641
INFO - 2019-10-31 23:18:40 --> Config Class Initialized
INFO - 2019-10-31 23:18:40 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:18:40 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:18:40 --> Utf8 Class Initialized
INFO - 2019-10-31 23:18:41 --> URI Class Initialized
INFO - 2019-10-31 23:18:41 --> Router Class Initialized
INFO - 2019-10-31 23:18:41 --> Output Class Initialized
INFO - 2019-10-31 23:18:41 --> Security Class Initialized
DEBUG - 2019-10-31 23:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:18:41 --> CSRF cookie sent
INFO - 2019-10-31 23:18:41 --> Input Class Initialized
INFO - 2019-10-31 23:18:41 --> Language Class Initialized
INFO - 2019-10-31 23:18:41 --> Language Class Initialized
INFO - 2019-10-31 23:18:41 --> Config Class Initialized
INFO - 2019-10-31 23:18:41 --> Loader Class Initialized
INFO - 2019-10-31 23:18:41 --> Helper loaded: url_helper
INFO - 2019-10-31 23:18:41 --> Helper loaded: common_helper
INFO - 2019-10-31 23:18:41 --> Helper loaded: language_helper
INFO - 2019-10-31 23:18:41 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:18:41 --> Helper loaded: email_helper
INFO - 2019-10-31 23:18:41 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:18:41 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:18:41 --> Parser Class Initialized
INFO - 2019-10-31 23:18:41 --> User Agent Class Initialized
INFO - 2019-10-31 23:18:41 --> Model Class Initialized
INFO - 2019-10-31 23:18:41 --> Database Driver Class Initialized
INFO - 2019-10-31 23:18:41 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:41 --> Template Class Initialized
INFO - 2019-10-31 23:18:41 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:18:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:18:41 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:18:41 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:18:41 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:18:41 --> Encryption Class Initialized
INFO - 2019-10-31 23:18:41 --> Controller Class Initialized
DEBUG - 2019-10-31 23:18:41 --> order MX_Controller Initialized
DEBUG - 2019-10-31 23:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 23:18:41 --> Model Class Initialized
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "order_id"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "order_id"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 23:18:41 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Pending"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Pending"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:18:41 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 23:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 23:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:18:41 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:18:41 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:18:41 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:18:42 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 23:18:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 23:18:42 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 23:18:42 --> Final output sent to browser
DEBUG - 2019-10-31 23:18:42 --> Total execution time: 1.2328
INFO - 2019-10-31 23:18:47 --> Config Class Initialized
INFO - 2019-10-31 23:18:47 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:18:47 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:18:47 --> Utf8 Class Initialized
INFO - 2019-10-31 23:18:47 --> URI Class Initialized
INFO - 2019-10-31 23:18:47 --> Router Class Initialized
INFO - 2019-10-31 23:18:47 --> Output Class Initialized
INFO - 2019-10-31 23:18:47 --> Security Class Initialized
DEBUG - 2019-10-31 23:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:18:47 --> CSRF cookie sent
INFO - 2019-10-31 23:18:47 --> Input Class Initialized
INFO - 2019-10-31 23:18:47 --> Language Class Initialized
INFO - 2019-10-31 23:18:47 --> Language Class Initialized
INFO - 2019-10-31 23:18:47 --> Config Class Initialized
INFO - 2019-10-31 23:18:47 --> Loader Class Initialized
INFO - 2019-10-31 23:18:47 --> Helper loaded: url_helper
INFO - 2019-10-31 23:18:47 --> Helper loaded: common_helper
INFO - 2019-10-31 23:18:47 --> Helper loaded: language_helper
INFO - 2019-10-31 23:18:47 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:18:47 --> Helper loaded: email_helper
INFO - 2019-10-31 23:18:48 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:18:48 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:18:48 --> Parser Class Initialized
INFO - 2019-10-31 23:18:48 --> User Agent Class Initialized
INFO - 2019-10-31 23:18:48 --> Model Class Initialized
INFO - 2019-10-31 23:18:48 --> Database Driver Class Initialized
INFO - 2019-10-31 23:18:48 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:48 --> Template Class Initialized
INFO - 2019-10-31 23:18:48 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:18:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:18:48 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:18:48 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:18:48 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:18:48 --> Encryption Class Initialized
INFO - 2019-10-31 23:18:48 --> Controller Class Initialized
DEBUG - 2019-10-31 23:18:48 --> transactions MX_Controller Initialized
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-10-31 23:18:48 --> Model Class Initialized
ERROR - 2019-10-31 23:18:48 --> Could not find the language line "order_id"
INFO - 2019-10-31 23:18:48 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:18:48 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:18:48 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:18:48 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 23:18:48 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 23:18:48 --> Final output sent to browser
DEBUG - 2019-10-31 23:18:48 --> Total execution time: 1.1184
INFO - 2019-10-31 23:18:58 --> Config Class Initialized
INFO - 2019-10-31 23:18:58 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:18:58 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:18:58 --> Utf8 Class Initialized
INFO - 2019-10-31 23:18:58 --> URI Class Initialized
INFO - 2019-10-31 23:18:58 --> Router Class Initialized
INFO - 2019-10-31 23:18:58 --> Output Class Initialized
INFO - 2019-10-31 23:18:58 --> Security Class Initialized
DEBUG - 2019-10-31 23:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:18:58 --> CSRF cookie sent
INFO - 2019-10-31 23:18:58 --> Input Class Initialized
INFO - 2019-10-31 23:18:58 --> Language Class Initialized
INFO - 2019-10-31 23:18:58 --> Language Class Initialized
INFO - 2019-10-31 23:18:58 --> Config Class Initialized
INFO - 2019-10-31 23:18:58 --> Loader Class Initialized
INFO - 2019-10-31 23:18:58 --> Helper loaded: url_helper
INFO - 2019-10-31 23:18:58 --> Helper loaded: common_helper
INFO - 2019-10-31 23:18:58 --> Helper loaded: language_helper
INFO - 2019-10-31 23:18:58 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:18:58 --> Helper loaded: email_helper
INFO - 2019-10-31 23:18:58 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:18:58 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:18:58 --> Parser Class Initialized
INFO - 2019-10-31 23:18:58 --> User Agent Class Initialized
INFO - 2019-10-31 23:18:58 --> Model Class Initialized
INFO - 2019-10-31 23:18:58 --> Database Driver Class Initialized
INFO - 2019-10-31 23:18:58 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:58 --> Template Class Initialized
INFO - 2019-10-31 23:18:58 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:18:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:18:58 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:18:58 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:18:58 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:18:58 --> Encryption Class Initialized
INFO - 2019-10-31 23:18:58 --> Controller Class Initialized
DEBUG - 2019-10-31 23:18:58 --> package MX_Controller Initialized
DEBUG - 2019-10-31 23:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/models/package_model.php
INFO - 2019-10-31 23:18:58 --> Model Class Initialized
INFO - 2019-10-31 23:18:58 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:18:58 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:18:58 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:18:59 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:18:59 --> Model Class Initialized
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header_top.php
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/package/views/index.php
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 23:18:59 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 23:18:59 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 23:18:59 --> Final output sent to browser
DEBUG - 2019-10-31 23:18:59 --> Total execution time: 1.3590
INFO - 2019-10-31 23:19:02 --> Config Class Initialized
INFO - 2019-10-31 23:19:02 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:19:02 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:19:02 --> Utf8 Class Initialized
INFO - 2019-10-31 23:19:02 --> URI Class Initialized
INFO - 2019-10-31 23:19:02 --> Router Class Initialized
INFO - 2019-10-31 23:19:02 --> Output Class Initialized
INFO - 2019-10-31 23:19:02 --> Security Class Initialized
DEBUG - 2019-10-31 23:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:19:02 --> CSRF cookie sent
INFO - 2019-10-31 23:19:02 --> CSRF token verified
INFO - 2019-10-31 23:19:02 --> Input Class Initialized
INFO - 2019-10-31 23:19:02 --> Language Class Initialized
INFO - 2019-10-31 23:19:02 --> Language Class Initialized
INFO - 2019-10-31 23:19:02 --> Config Class Initialized
INFO - 2019-10-31 23:19:02 --> Loader Class Initialized
INFO - 2019-10-31 23:19:02 --> Helper loaded: url_helper
INFO - 2019-10-31 23:19:02 --> Helper loaded: common_helper
INFO - 2019-10-31 23:19:02 --> Helper loaded: language_helper
INFO - 2019-10-31 23:19:02 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:19:02 --> Helper loaded: email_helper
INFO - 2019-10-31 23:19:02 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:19:02 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:19:02 --> Parser Class Initialized
INFO - 2019-10-31 23:19:02 --> User Agent Class Initialized
INFO - 2019-10-31 23:19:02 --> Model Class Initialized
INFO - 2019-10-31 23:19:02 --> Database Driver Class Initialized
INFO - 2019-10-31 23:19:02 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:02 --> Template Class Initialized
INFO - 2019-10-31 23:19:02 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:19:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:19:02 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:19:02 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:19:02 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:19:02 --> Encryption Class Initialized
INFO - 2019-10-31 23:19:02 --> Controller Class Initialized
DEBUG - 2019-10-31 23:19:02 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:19:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:19:02 --> Model Class Initialized
INFO - 2019-10-31 23:19:02 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:19:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/index.php
DEBUG - 2019-10-31 23:19:02 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:19:02 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:19:03 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:19:03 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/user/header.php
ERROR - 2019-10-31 23:19:03 --> Could not find the language line "FAQs"
DEBUG - 2019-10-31 23:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/footer.php
DEBUG - 2019-10-31 23:19:03 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/user.php
INFO - 2019-10-31 23:19:03 --> Final output sent to browser
DEBUG - 2019-10-31 23:19:03 --> Total execution time: 1.1462
INFO - 2019-10-31 23:19:11 --> Config Class Initialized
INFO - 2019-10-31 23:19:11 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:19:11 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:19:11 --> Utf8 Class Initialized
INFO - 2019-10-31 23:19:11 --> URI Class Initialized
INFO - 2019-10-31 23:19:11 --> Router Class Initialized
INFO - 2019-10-31 23:19:11 --> Output Class Initialized
INFO - 2019-10-31 23:19:11 --> Security Class Initialized
DEBUG - 2019-10-31 23:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:19:11 --> CSRF cookie sent
INFO - 2019-10-31 23:19:11 --> CSRF token verified
INFO - 2019-10-31 23:19:11 --> Input Class Initialized
INFO - 2019-10-31 23:19:11 --> Language Class Initialized
INFO - 2019-10-31 23:19:11 --> Language Class Initialized
INFO - 2019-10-31 23:19:11 --> Config Class Initialized
INFO - 2019-10-31 23:19:11 --> Loader Class Initialized
INFO - 2019-10-31 23:19:11 --> Helper loaded: url_helper
INFO - 2019-10-31 23:19:11 --> Helper loaded: common_helper
INFO - 2019-10-31 23:19:11 --> Helper loaded: language_helper
INFO - 2019-10-31 23:19:11 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:19:11 --> Helper loaded: email_helper
INFO - 2019-10-31 23:19:11 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:19:11 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:19:11 --> Parser Class Initialized
INFO - 2019-10-31 23:19:11 --> User Agent Class Initialized
INFO - 2019-10-31 23:19:11 --> Model Class Initialized
INFO - 2019-10-31 23:19:11 --> Database Driver Class Initialized
INFO - 2019-10-31 23:19:11 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:11 --> Template Class Initialized
INFO - 2019-10-31 23:19:11 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:19:11 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:19:11 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:19:11 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:19:11 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:19:11 --> Encryption Class Initialized
INFO - 2019-10-31 23:19:11 --> Controller Class Initialized
DEBUG - 2019-10-31 23:19:11 --> checkout MX_Controller Initialized
DEBUG - 2019-10-31 23:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/models/checkout_model.php
INFO - 2019-10-31 23:19:11 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:11 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/views/coinbase/index.php
INFO - 2019-10-31 23:19:11 --> Final output sent to browser
DEBUG - 2019-10-31 23:19:11 --> Total execution time: 0.7432
INFO - 2019-10-31 23:19:11 --> Config Class Initialized
INFO - 2019-10-31 23:19:11 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:19:12 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:19:12 --> Utf8 Class Initialized
INFO - 2019-10-31 23:19:12 --> URI Class Initialized
INFO - 2019-10-31 23:19:12 --> Router Class Initialized
INFO - 2019-10-31 23:19:12 --> Output Class Initialized
INFO - 2019-10-31 23:19:12 --> Security Class Initialized
DEBUG - 2019-10-31 23:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:19:12 --> Input Class Initialized
INFO - 2019-10-31 23:19:12 --> Language Class Initialized
INFO - 2019-10-31 23:19:12 --> Language Class Initialized
INFO - 2019-10-31 23:19:12 --> Config Class Initialized
INFO - 2019-10-31 23:19:12 --> Loader Class Initialized
INFO - 2019-10-31 23:19:12 --> Helper loaded: url_helper
INFO - 2019-10-31 23:19:12 --> Helper loaded: common_helper
INFO - 2019-10-31 23:19:12 --> Helper loaded: language_helper
INFO - 2019-10-31 23:19:12 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:19:12 --> Helper loaded: email_helper
INFO - 2019-10-31 23:19:12 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:19:12 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:19:12 --> Parser Class Initialized
INFO - 2019-10-31 23:19:12 --> User Agent Class Initialized
INFO - 2019-10-31 23:19:12 --> Model Class Initialized
INFO - 2019-10-31 23:19:12 --> Database Driver Class Initialized
INFO - 2019-10-31 23:19:12 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:12 --> Template Class Initialized
INFO - 2019-10-31 23:19:12 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:19:12 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:19:12 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:19:12 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:19:12 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:19:12 --> Encryption Class Initialized
INFO - 2019-10-31 23:19:12 --> Controller Class Initialized
DEBUG - 2019-10-31 23:19:12 --> coinbase MX_Controller Initialized
DEBUG - 2019-10-31 23:19:12 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/checkout/libraries/coinbase_api.php
INFO - 2019-10-31 23:19:12 --> Model Class Initialized
DEBUG - 2019-10-31 23:19:13 --> orders MX_Controller Initialized
INFO - 2019-10-31 23:20:39 --> Config Class Initialized
INFO - 2019-10-31 23:20:39 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:20:39 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:20:39 --> Utf8 Class Initialized
INFO - 2019-10-31 23:20:39 --> URI Class Initialized
INFO - 2019-10-31 23:20:39 --> Router Class Initialized
INFO - 2019-10-31 23:20:39 --> Output Class Initialized
INFO - 2019-10-31 23:20:39 --> Security Class Initialized
DEBUG - 2019-10-31 23:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:20:39 --> CSRF cookie sent
INFO - 2019-10-31 23:20:39 --> Input Class Initialized
INFO - 2019-10-31 23:20:39 --> Language Class Initialized
INFO - 2019-10-31 23:20:39 --> Language Class Initialized
INFO - 2019-10-31 23:20:39 --> Config Class Initialized
INFO - 2019-10-31 23:20:39 --> Loader Class Initialized
INFO - 2019-10-31 23:20:39 --> Helper loaded: url_helper
INFO - 2019-10-31 23:20:39 --> Helper loaded: common_helper
INFO - 2019-10-31 23:20:39 --> Helper loaded: language_helper
INFO - 2019-10-31 23:20:39 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:20:39 --> Helper loaded: email_helper
INFO - 2019-10-31 23:20:40 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:20:40 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:20:40 --> Parser Class Initialized
INFO - 2019-10-31 23:20:40 --> User Agent Class Initialized
INFO - 2019-10-31 23:20:40 --> Model Class Initialized
INFO - 2019-10-31 23:20:40 --> Database Driver Class Initialized
INFO - 2019-10-31 23:20:40 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:40 --> Template Class Initialized
INFO - 2019-10-31 23:20:40 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:20:40 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:20:40 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:20:40 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:20:40 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:20:40 --> Encryption Class Initialized
INFO - 2019-10-31 23:20:40 --> Controller Class Initialized
DEBUG - 2019-10-31 23:20:40 --> transactions MX_Controller Initialized
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/models/transactions_model.php
INFO - 2019-10-31 23:20:40 --> Model Class Initialized
ERROR - 2019-10-31 23:20:40 --> Could not find the language line "order_id"
INFO - 2019-10-31 23:20:40 --> Helper loaded: inflector_helper
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/transactions/views/index.php
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:20:40 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:20:40 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:20:40 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 23:20:40 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 23:20:40 --> Final output sent to browser
DEBUG - 2019-10-31 23:20:40 --> Total execution time: 1.1755
INFO - 2019-10-31 23:20:49 --> Config Class Initialized
INFO - 2019-10-31 23:20:49 --> Hooks Class Initialized
DEBUG - 2019-10-31 23:20:49 --> UTF-8 Support Enabled
INFO - 2019-10-31 23:20:49 --> Utf8 Class Initialized
INFO - 2019-10-31 23:20:49 --> URI Class Initialized
INFO - 2019-10-31 23:20:49 --> Router Class Initialized
INFO - 2019-10-31 23:20:49 --> Output Class Initialized
INFO - 2019-10-31 23:20:49 --> Security Class Initialized
DEBUG - 2019-10-31 23:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-10-31 23:20:49 --> CSRF cookie sent
INFO - 2019-10-31 23:20:49 --> Input Class Initialized
INFO - 2019-10-31 23:20:49 --> Language Class Initialized
INFO - 2019-10-31 23:20:49 --> Language Class Initialized
INFO - 2019-10-31 23:20:49 --> Config Class Initialized
INFO - 2019-10-31 23:20:49 --> Loader Class Initialized
INFO - 2019-10-31 23:20:49 --> Helper loaded: url_helper
INFO - 2019-10-31 23:20:49 --> Helper loaded: common_helper
INFO - 2019-10-31 23:20:49 --> Helper loaded: language_helper
INFO - 2019-10-31 23:20:49 --> Helper loaded: cookie_helper
INFO - 2019-10-31 23:20:49 --> Helper loaded: email_helper
INFO - 2019-10-31 23:20:49 --> Helper loaded: file_manager_helper
INFO - 2019-10-31 23:20:49 --> Language file loaded: language/english/common_lang.php
INFO - 2019-10-31 23:20:49 --> Parser Class Initialized
INFO - 2019-10-31 23:20:49 --> User Agent Class Initialized
INFO - 2019-10-31 23:20:49 --> Model Class Initialized
INFO - 2019-10-31 23:20:49 --> Database Driver Class Initialized
INFO - 2019-10-31 23:20:49 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:49 --> Template Class Initialized
INFO - 2019-10-31 23:20:49 --> Session: Class initialized using 'database' driver.
INFO - 2019-10-31 23:20:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-10-31 23:20:49 --> Pagination Class Initialized
DEBUG - 2019-10-31 23:20:49 --> Encryption: Auto-configured driver 'openssl'.
INFO - 2019-10-31 23:20:49 --> Encryption: OpenSSL initialized with method AES-128-CBC.
INFO - 2019-10-31 23:20:49 --> Encryption Class Initialized
INFO - 2019-10-31 23:20:49 --> Controller Class Initialized
DEBUG - 2019-10-31 23:20:49 --> order MX_Controller Initialized
DEBUG - 2019-10-31 23:20:49 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/models/order_model.php
INFO - 2019-10-31 23:20:49 --> Model Class Initialized
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "order_id"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "order_basic_details"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "order_id"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "order_basic_details"
INFO - 2019-10-31 23:20:49 --> Helper loaded: inflector_helper
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "Pending"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:20:49 --> Could not find the language line "Pending"
ERROR - 2019-10-31 23:20:50 --> Could not find the language line "Awaiting"
ERROR - 2019-10-31 23:20:50 --> Could not find the language line "Awaiting"
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/order/views/logs/logs.php
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\controllers/../modules/blocks/controllers/blocks.php
DEBUG - 2019-10-31 23:20:50 --> blocks MX_Controller Initialized
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/services/models/services_model.php
INFO - 2019-10-31 23:20:50 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/category/models/category_model.php
INFO - 2019-10-31 23:20:50 --> Model Class Initialized
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/header_vertical.php
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\modules/blocks/views/sidebar.php
DEBUG - 2019-10-31 23:20:50 --> File loaded: D:\xampp\htdocs\projects\tuyen\smm_store\code\app\views/layouts/template.php
INFO - 2019-10-31 23:20:50 --> Final output sent to browser
DEBUG - 2019-10-31 23:20:50 --> Total execution time: 1.1650
