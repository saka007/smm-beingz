<section class="header-top d-none d-lg-block">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <ul class="mini-menu list-inline mb-0">
          <li class="list-inline-item"><a href="<?php echo strip_tags($first_link->link); ?>"><i class="fe fe-home"></i> <?php echo strip_tags($first_link->name); ?></a></li>
          <li class="active list-inline-item"><a href="<?php echo strip_tags($second_link->link); ?>"><?php echo strip_tags($second_link->name); ?></a></li>
        </ul>
      </div>
    </div>
  </div>
</section>